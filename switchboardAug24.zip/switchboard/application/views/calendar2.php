

<div class="container">


	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-2 hidden-phone hidden-tablet">
			
		<h4 class="external-header">Specialists</h4>
			<div id="external-events">
				<?php
				foreach($specialist as $spe){
					echo '<div class="external-event badge"><img class="icons pull-left drag" src="'.base_url().'assets/images/icons/drag.png"/>'.$spe['shortname'].'</div>';
					
				}
				?>
				<p>
				<img src="<?php echo base_url(); ?>assets/images/trashcan.png" id="trash" alt="">
				</p>
			</div>
		</div>
		<div class="col-lg-10">
			<div id="calendar"></div>	
		</div>	
	</div>
				
</div>
<div id="fullCalModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                <h4 id="modalTitle" class="modal-title"></h4>
            </div>
            <div id="modalBody" class="modal-body"></div>
        </div>
    </div>
</div>

<script src='https://code.jquery.com/ui/1.11.2/jquery-ui.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js'></script>
<script>

	var buttonHTML ='<button class="btn btn-primary" onClick="';
		buttonHTML += "putCalendar(document.getElementById('ddl1'),document.getElementById('ddl2'),document.getElementById('copiedDetails')";
		buttonHTML += ')" data-dismiss="modal">File</button>';
	var copiedDetails;

	function configureDropDownLists(ddl1,ddl2) {
		var shift = new Array('ASIA', 'EMEA', 'NALA');
	    var leaves = new Array('Sick Leave', 'Vacation Leave');

	    switch (ddl1.value) {
	        case 'DM':
	            ddl2.options.length = 0;
	            for (i = 0; i < shift.length; i++) {
	                createOption(ddl2, shift[i], shift[i]);
	            }
	            $('#ddLabel').show().html('Shift:');
	            break;
	        case 'Leave':
	        	$('#ddLabel').hide();
	            ddl2.options.length = 0; 
	            for (i = 0; i < leaves.length; i++) {
	                createOption(ddl2, leaves[i], leaves[i]);
	                }
	            break;
	    }
	    $('#fileButton').html(buttonHTML);
	    $("#dependentDropdown").show();
	}

	function createOption(ddl, text, value) {
	    var opt = document.createElement('option');
	    opt.value = value;
	    opt.text = text;
	    ddl.options.add(opt);
	}

	function putCalendar(ddl1,ddl2){

		if(ddl1.value == 'DM')
			copiedDetails.className = 'label-dm';
		else if (ddl2.value == 'Sick Leave')
			copiedDetails.className = 'label-danger';
		else
			copiedDetails.className = 'label-primary';
		
		//append the value of second option to title variable
		// copiedDetails.title += " - "+ddl1.value+" ("+ddl2.value+")";

		$('#calendar').fullCalendar('renderEvent', copiedDetails, true);
		console.log(copiedDetails);
	}
	$(document).ready(function(){
		
		var zone = "8:00";  //Change this to your timezone
		
		$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
			type: 'POST', // Send post data
			data: 'type=fetch',
			async: false,
			success: function(s){
				json_events = s;
			}
		});
		
		var currentMousePos = {
			x: -1,
			y: -1
		};
			jQuery(document).on("mousemove", function (event) {
			currentMousePos.x = event.pageX;
			currentMousePos.y = event.pageY;
		});
		
		$('#external-events div.external-event').each(function() {

			// store data so the calendar knows to render an event upon drop
			// $(this).data('event', {
				// title: $.trim($(this).text()), // use the element's text as the event title
				// stick: true // maintain when user navigates (see docs on the renderEvent method)
			// });
		
			// it doesn't need to have a start or end
			var eventObject = {
				title: $(this).text() // use the element's text as the event title
			};
			
			// store the Event Object in the DOM element so we can get to it later
			$(this).data('eventObject', eventObject);
			
			// make the event draggable using jQuery UI
			$(this).draggable({
				zIndex: 999,
				revert: true,      // will cause the event to go back to its
				revertDuration: 0  //  original position after the drag
			});
			
		});
		
		var date = new Date();
		var d = date.getDate();
		var m = date.getMonth();
		var y = date.getFullYear();
			
		$('#calendar').fullCalendar({
			events: JSON.parse(json_events),
			// events: [{"id":"1","title":"New Event","start":"2016-08-14T00:01:00+05:30","end":"2016-08-17T00:01:00+05:30","allDay":true}],
			// eventColor: '#01a982',
			utc: true,
			firstDay:1,
			height: 650,
			header: {
				left: 'title',
				right: 'prev,next'
			},
			editable: true,
			droppable: true, // this allows things to be dropped onto the calendar !!!
			
			drop: function(date, allDay) { // this function is called when something is dropped
				
				var originalEventObject = $(this).data('eventObject');
				var copiedEventObject = $.extend({}, originalEventObject);

				copiedEventObject.start = date;
				copiedEventObject.end = date;
				copiedEventObject.allDay = allDay;
				copiedEventObject.className = '';

				//saves to global variable copiedDetails for rendering later
				copiedDetails = copiedEventObject;
				
				//we have to break this down since html breaks down when using the document.getElementById('ddl2'). it has to be '' 
				var content = 'Type:<br><fieldset class="form-group"><select class="form-control full-width" id="ddl1" onChange="';

				content += "configureDropDownLists(this,document.getElementById('ddl2'))";

				content += '"><option disabled selected value> -- select a type -- </option><option>DM</option><option>Leave</option></select></fieldset><fieldset id="dependentDropdown" class="form-group"><div id="ddLabel"></div><select id="ddl2" class="form-control full-width"></select></fieldset><div id="fileButton" text-align="right"></div>';

				$('#modalTitle').html('Filing for ' + copiedEventObject.title + ' on ' + date.format("MMMM DD, YYYY"));
	            $('#modalBody').html(content);
	            $("#dependentDropdown").hide();
	            $('#fileButton').html('<button id="fileButton" class="btn btn-primary disabled">File</button>');
				$('#fullCalModal').modal();
			},
			slotDuration: '00:30:00',
			eventReceive: function(event){
				var title = event.title;
				var start = event.start.format("YYYY-MM-DD[T]HH:mm:SS");
				$.ajax({
		    		url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
		    		data: 'type=new&title='+title+'&startdate='+start+'&zone='+zone,
		    		type: 'POST',
		    		dataType: 'json',
		    		success: function(response){
		    			event.id = response.eventid;
		    			$('#calendar').fullCalendar('updateEvent',event);
		    		},
		    		error: function(e){
		    			console.log(e.responseText);

		    		}
		    	});
				$('#calendar').fullCalendar('updateEvent',event);
				console.log(event);
			},
			
			eventDrop: function(event, delta, revertFunc) {
		        var title = event.title;
		        var start = event.start.format();
		        var end = (event.end == null) ? start : event.end.format();
		        $.ajax({
					url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
					data: 'type=resetdate&title='+title+'&start='+start+'&end='+end+'&eventid='+event.id,
					type: 'POST',
					dataType: 'json',
					success: function(response){
						if(response.status != 'success')		    				
						revertFunc();
					},
					error: function(e){		    			
						revertFunc();
						alert('Error processing your request: '+e.responseText);
					}
				});
		    },
			
			eventClick: function(event, jsEvent, view) {
		    	console.log(event.id);
		          var title = prompt('Event Title:', event.title, { buttons: { Ok: true, Cancel: false} });
		          if (title){
		              event.title = title;
		              console.log('type=changetitle&title='+title+'&eventid='+event.id);
		              $.ajax({
				    		url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
				    		data: 'type=changetitle&title='+title+'&eventid='+event.id,
				    		type: 'POST',
				    		dataType: 'json',
				    		success: function(response){	
				    			if(response.status == 'success')			    			
		              				$('#calendar').fullCalendar('updateEvent',event);
				    		},
				    		error: function(e){
				    			alert('Error processing your request: '+e.responseText);
				    		}
				    	});
		          }
			},
			
			eventResize: function(event, delta, revertFunc) {
				console.log(event);
				var title = event.title;
				var end = event.end.format();
				var start = event.start.format();
		        $.ajax({
					url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
					data: 'type=resetdate&title='+title+'&start='+start+'&end='+end+'&eventid='+event.id,
					type: 'POST',
					dataType: 'json',
					success: function(response){
						if(response.status != 'success')		    				
						revertFunc();
					},
					error: function(e){		    			
						revertFunc();
						alert('Error processing your request: '+e.responseText);
					}
				});
		    },
			eventDragStop: function (event, jsEvent, ui, view) {
			    if (isElemOverDiv()) {
			    	var con = confirm('Are you sure to delete this event permanently?');
			    	if(con == true) {
						$.ajax({
				    		url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
				    		data: 'type=remove&eventid='+event.id,
				    		type: 'POST',
				    		dataType: 'json',
				    		success: function(response){
				    			console.log(response);
				    			if(response.status == 'success'){
				    				$('#calendar').fullCalendar('removeEvents');
            						getFreshEvents();
            					}
				    		},
				    		error: function(e){	
				    			alert('Error processing your request: '+e.responseText);
				    		}
			    		});
					}   
				}
			},
	 		columnFormat: {
	        	month: 'ddd'
			}

		});
		
		function getFreshEvents(){
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
				type: 'POST', // Send post data
				data: 'type=fetch',
				async: false,
				success: function(s){
					freshevents = s;
				}
			});
			$('#calendar').fullCalendar('addEventSource', JSON.parse(freshevents));
		}
		
		function isElemOverDiv() {
			var trashEl = jQuery('#trash');

			var ofs = trashEl.offset();

			var x1 = ofs.left;
			var x2 = ofs.left + trashEl.outerWidth(true);
			var y1 = ofs.top;
			var y2 = ofs.top + trashEl.outerHeight(true);

			if (currentMousePos.x >= x1 && currentMousePos.x <= x2 &&
				currentMousePos.y >= y1 && currentMousePos.y <= y2) {
				return true;
			}
			return false;
		}
		
		
	});


</script>

<script>
	
	

</script>