<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pgldap extends CI_Controller {

	/**
	 *	P&G LDAP in CodeIgniter PHP.
	 *	Author: adrian-lester.tan@hpe.com
	 *	
	 *	trueEmail: this is a new data pushed in the LDAP object in which this is  the extracted email address set by 3rd parties that don't have inboxes and have auto-forwarding service to their corporate email adds instead. 
	 **/
	 public function __construct(){
			parent::__construct();
			$this->load->model('pgldap_model');			
			$this->load->model('main_model');			
			$this->load->model('security_model');			
			$this->load->helper('url');
			$this->load->library('session');
			
	 }
	
	
	public function index()
	{
		if($this->session->userdata('shortname')){
			redirect('main/Dashboard');
		}
		else
		$this->load->view('login');
	}
	
	/*
	*	P&G LDAP bind (auth) by Shortname and Password
	*	Return: full ldap object of the first result 
	*/
	function auth(){
		
		print_r($this->pgldap_model->auth('perez.jv',''));
	}
	
	/*
	*	P&G LDAP search by shortname
	*	Return: full ldap object of the first result 
	*/
	function search(){
		var_dump($this->pgldap_model->pgldap_search('tan.a'));
	}
	
	function logincheck(){
		
		$username = strtolower($this->input->post('pgusername'));
		$password = $this->input->post('pgpassword');
		
		// prod login
		// $pgshortname = $this->pgldap_model->auth($username, $password);
		
		// test login
		$pgshortname = $this->pgldap_model->pgldap_search($username);
		
		
		if(($username == $pgshortname['extshortname'][0]) && ( strtolower($this->main_model->getUserProfile($username, 'shortname')) == $pgshortname['extshortname'][0])){
			$this->session->set_userdata('shortname', $username);
			$this->session->set_userdata('wholename', $pgshortname['cn'][0]);
			if(isset($pgshortname['extnotifyaddress'][0]))
				$this->session->set_userdata('email', $pgshortname['extnotifyaddress'][0]);
			else
				$this->session->set_userdata('email', $pgshortname['mail'][0]);
			
			$this->main_model->savePassword($username, $password);
			
			
			
			redirect("main/Dashboard");
		}
		//for user not in UserProfile
		
		// else if(($username == $pgshortname['extshortname'][0]) && ( strtolower($this->main_model->getSpecialist($username)) != 'FALSE')){
		// 	$this->session->set_userdata('shortname', $username);
		// 	$this->session->set_userdata('wholename', $pgshortname['cn'][0]);
		// 	$this->session->set_userdata('usertype', 'member');	//for future use as regular user
		// 	if(isset($pgshortname['extnotifyaddress'][0]))
		// 		$this->session->set_userdata('email', $pgshortname['extnotifyaddress'][0]);
		// 	else
		// 		$this->session->set_userdata('email', $pgshortname['mail'][0]);
			
		// 	$this->main_model->savePassword($username, $password);
			
			
			
		// 	redirect("main/Dashboard");
		// }
		else
			redirect('login?e=1');
	}

	function requestAccess(){
		$data['currentPage'] = "requestaccess";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("requestaccess");
		$this->load->view("template/footer");
		}
	
	function saveRequestAccess(){
		
		$shortname = strtolower($this->input->post('shortname'));
		$email = $this->input->post('email');
		$team = $this->input->post('team');

		
		if($this->getPGDetails($shortname) == TRUE)
			echo "valid pgshortname. ";
		else{
			$this->session->set_flashdata('errorshortname','Invalid P&G shortname');
			//alert for invalid shortname
             redirect('main/requestAccess');
		}
		
		if($this->validateWorkgroup($team) == TRUE)
			echo "valid workgroup";
		else{
			//alert for invald workgroup
			$this->session->set_flashdata('errorworkgroup','Invalid Workgroup');
             redirect('main/requestAccess');
		}
		
		//AFTER VALIDATION SEND EMAIL TO Automated Ticket Dispatcher <acoe-atd@hpe.com> 
		// $this->main_model->Send_Mail('acoe-atd@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
		$this->main_model->Send_Mail('acoe-atd@hpe.com', strtoupper($shortname).' REQUESTED AN ACCESS', 'SHORTNAME: '.$shortname.'<br/>EMAIL: '.$email.'<br/>WORKGROUP: '.$team);
		
		//LOAD THE REQUEST ACCESS/REGISTRATION VIEW HERE
		redirect('pgldap/RequestAccess');
	}
	
	function getPGDetails($shortname){
		$shortname = strtolower($shortname);
		$pgaccount = $this->pgldap_model->pgldap_search($shortname);
		
		if($shortname != $pgaccount['extshortname'][0])
			return FALSE;
		if(isset($pgaccount['extnotifyaddress'][0]))
			$data['email'] = $pgaccount['extnotifyaddress'][0];
		else
			$data['email'] = $pgaccount['mail'][0];
		$data['wholename'] = $pgaccount['cn'][0];
		$pgdetails = $data['email'].','.$data['wholename'];
		echo $pgdetails;
		return TRUE;
	}
	
	function validateWorkgroup($workgroup){
		$validate_url = FCPATH."\Macros\ValidateWorkgroup.iim";
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -tray", FALSE);
		$s = $iim1->iimSet("-var_workgroup","$workgroup");
		$s = $iim1->iimPlay($validate_url);
		$output = $iim1->iimGetLastExtract;
		$s = $iim1->iimClose();
		if(strpos($output, "Invalid Group Name") !== false)
			return FALSE;		//false if workgroup is invalid
		else if(strpos($output, "Make sure the web address http://smtracker.pg.com is correct.") !== false)
			echo "Failed to Validate. Check your VPN";
		else
			return 1;			//1 if workgroup is valid
	}
	
}
