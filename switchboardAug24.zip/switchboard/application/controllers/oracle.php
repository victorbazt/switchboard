<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class oracle extends CI_Controller {

	/**
	 *	Connecting PHP to Oracle
	 *	Author: adrian-lester.tan@hpe.com
	 *	
	 *	Sample codes and my experiences are in this skeleton controller-model.
	 *	Bulk of the work is to import OCI8 module that is compatible to the Oracle DB
	 *	you are connecting to. Usually, OCI8 module works in a vast majority of Oracle version.
	 *	
	 *	There are just some weird things I noted here such as not putting ; on your Oracle queries.
	 *
	 *	I am documenting this already to save you the trouble.
	 **/
	 public function __construct(){
			parent::__construct();
			
			$this->load->model('oracle_model');
			
	 }
	
	function heartbeat(){
		print_r($this->oracle_model->heartbeat());
	}
	
}
