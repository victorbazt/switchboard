<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct(){
			parent::__construct();
			ini_set('max_execution_time', 3000000);
			date_default_timezone_set("Asia/Singapore");
			$this->load->helper('url');
			$this->load->library('session');
			$this->load->model('main_model');
			$this->load->model('pgldap_model');
			date_default_timezone_set('Asia/Hong_Kong');
			$this->load->model('security_model');
			$this->security_model->is_logged_in();
	 }
	 
	 /*
	 Dashboard()
	 myTeam()
	 requestAccess()
	 saveRequestAccess()
	 userSetup()
	 saveUserSetup()
	 validateWorkgroup($workgroup)
	 getPGDetails($shortname)
	 donutIMFR()
	 donutROGUE()
	 calendar()
	 settings()
	 logout()
	 ticketlog()
	 openTickets($team)
	 getOpenIM($team)
	 stopAssign($team)
	 startAssign($team)
	 assignTicket($tnum, $specialist, $priority, $type, $row, $titlesearch, $category)
	 flush_buffers()
	 RegionSelector($team)
	 CheckDMAvailability($team)
	 getRowApp($team)
	 minCriticalTicket($team)
	 minIMTicket($team, $rowapp)
	 minFRTicket($team)
	 minRogueTicket($team)
	 checkStart($team)
	 sortdm($team)
	 getCalendarShift($team, $status)
	 updateDM($team)
	 smLogin()
	 
	 
	 
	 
	 */
	 
	 
	public function index()
	{

		redirect('Dashboard');
	}
	function getTicketCount(){
		var_dump($this->main_model->getTicketCount('G.AACOE', 'IM', '3 - Multiple Users'));
	}
	
	function Dashboard(){
		$data['currentPage'] = "home";
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$this->session->set_userdata('team', $team);		//set current team to session
		$data['startrun'] = $this->main_model->getStartRun($team);
		$data['dmoftheday'] = $this->main_model->getDM($team, 0);
		$data['regions'] = $this->main_model->getRegions($team);

		if($this->main_model->getUserProfile($this->session->userdata('shortname'), 'ftuser') == TRUE){
			
			// $this->userSetup();
			// echo "this is first time user setup page";
			$data['hidemenu'] = TRUE;
			$this->load->view("template/header", $data);
			$this->load->view("setupwizard");
			$this->load->view("template/footer");
		}
		else
		{
			// echo "this is the dashboard";
			$this->load->view("template/header", $data);
			$this->load->view("home");
			$this->load->view("template/footer");
		}
	}
	
	function myTeam(){
		$data['currentPage'] = "myteam";
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$data['allspecialist'] = $this->main_model->getAllSpecialist($team);
		$this->load->view("template/header", $data);
		$this->load->view("specialist", $data);
		$this->load->view("template/footer");
	}
	
	// function assignTicket(){
		//ACTUAL ASSIGNMENT OF TICKET HERE
		
		
		//SEND EMAIL AFTER ASSIGNING OF TICKET
		// $this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'SAMPLE TICKET TITLE', $this->main_model->emailtemplate('PEREZ.JV', 'IM0123456', 'IM', 'SAMPLE TICKET TITLE', 'High', '07-22-16', 'OPEN', 'Sample Ticket Description'));
		
	// }
	
	function requestAccess(){
		$data['currentPage'] = "requestaccess";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("requestaccess");
		$this->load->view("template/footer");
		}
	
	function saveRequestAccess(){
		
		$shortname = strtolower($this->input->post('shortname'));
		$email = $this->input->post('email');
		$team = $this->input->post('team');

		
		if($this->getPGDetails($shortname) == TRUE)
			echo "valid pgshortname. ";
		else{
			$this->session->set_flashdata('errorshortname','Invalid P&G shortname');
             redirect('main/requestAccess');
		}
		
		if($this->validateWorkgroup($team) == TRUE)
			echo "valid workgroup";
		else{
			$this->session->set_flashdata('errorworkgroup','Invalid Workgroup');
             redirect('main/requestAccess');
		}
		//LOAD THE REQUEST ACCESS/REGISTRATION VIEW HERE
		echo "request access page";
		
		//AFTER VALIDATION SEND EMAIL TO Automated Ticket Dispatcher <acoe-atd@hpe.com> 
		// $this->main_model->Send_Mail('acoe-atd@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
		$this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
	}
	
	function userSetup(){
		$data['currentPage'] = "home";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("setup");
		$this->load->view("template/footer");
		
	}
	
	function saveUserSetup(){
		
		/*
		*Creation of atleast 1 specialist
		
		$newshortname = $this->input->post('shortname');		//shortname of newly added specialist
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');  //dm can only add specialist under his/her own team only
		$region = $this->input->post('region');
		$pgdetails = $this->getPGDetails('perez.jv');	// $pgdetails['email'] && $pgdetails['wholename']
		$row = $this->input->post('row');
		$type = "L1";
		$role = "";

		$this->main_model->addSpecialist($newshortname, $team, $region, $pgdetails['email'], $pgdetails['wholename'], $row, $type, $role);
		*/
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$timeout = $this->input->post('timeout');
		$titlesearch = $this->input->post('titlesearch');
		$regionsearch = $this->input->post('regionsearch');
		$noregionassignee = $this->input->post('noregionassignee');
		
		$this->main_model->updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee);
	}
	
	function validateWorkgroup($workgroup){
		$validate_url = FCPATH."\Macros\ValidateWorkgroup.iim";
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -tray", FALSE);
		$s = $iim1->iimSet("-var_workgroup","$workgroup");
		$s = $iim1->iimPlay($validate_url);
		$output = $iim1->iimGetLastExtract;
		$s = $iim1->iimClose();
		if(strpos($output, "Invalid Group Name") !== false)
			return FALSE;		//false if workgroup is invalid
		else if(strpos($output, "Make sure the web address http://smtracker.pg.com is correct.") !== false)
			echo "Failed to Validate. Check your VPN";
		else
			return 1;			//1 if workgroup is valid
	}
	
	function getPGDetails($shortname){
		$shortname = strtolower($shortname);
		$pgaccount = $this->pgldap_model->pgldap_search($shortname);
		
		if($shortname != $pgaccount['extshortname'][0])
			return FALSE;
		if(isset($pgaccount['extnotifyaddress'][0]))
			$data['email'] = $pgaccount['extnotifyaddress'][0];
		else
			$data['email'] = $pgaccount['mail'][0];
		$data['wholename'] = $pgaccount['cn'][0];
		$pgdetails = $data['email'].','.$data['wholename'];
		echo $pgdetails;
		return TRUE;
	}
	
	function donutIMFR(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$category = 'IM';
		$priority = ' 1 - Enterprise ';
		$donut = $this->main_model->getTicketCount($team, $category, $priority);
		var_dump($donut);
		
	}
	
	function donutROGUE(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
	}
	
	function calendar(){
		$team = $this->session->userdata('team');
		$data['currentPage'] = "calendar";	
		//for calendar
		$data['calendar'] = $this->fetchCalendar();
		$data['specialist'] = $this->main_model->getAllSpecialist($team);
		$data['shift'] = $this->main_model->getRegions($team);
		$this->load->view('template/header',$data);
		$this->load->view('calendar');
		$this->load->view('template/footer');
	}
	
	function settings(){
		$data['currentPage'] = "settings";
		$this->load->view('template/header',$data);
		$this->load->view('settings');
		$this->load->view('template/footer');
	}
	
	function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}
	
	function ticketlog(){
		$data['currentPage'] = "ticketlog";
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		// $data['allticket'] = $this->main_model->getAllTickets($team);
		$this->load->view("template/header", $data);
		$this->load->view("ticketlog");
		$this->load->view("template/footer");
	}

	function getAllTickets(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$tickets = $this->main_model->getAllTickets($team);
		foreach($tickets as $key => $value){
			if($tickets[$key]['priority'] == '1 - Enterprise'){
				$tickets[$key]['priority'] = '<span class="label label-critical">1 - Enterprise</span>';
			}
			else if($tickets[$key]['priority'] == '2 - Site/Dept'){
				$tickets[$key]['priority'] = '<span class="label label-high">2 - Site/Dept</span>';
			}
			else if($tickets[$key]['priority'] == '3 - Multiple Users'){
				$tickets[$key]['priority'] = '<span class="label label-average">3 - Multiple Users</span>';
			}
			else if($tickets[$key]['priority'] == '4 - User'){
				$tickets[$key]['priority'] = '<span class="label label-low">4 - Users</span>';
			}
			// else{
			// 	$tickets[$key]['priority'] = '<span class="label label-danger">1 - Enterprise</span>';
			// }
		}
		echo json_encode($tickets);
	}

	
	
	 
	 
	 
	 
	 function flush_buffers(){ 
		ob_end_flush(); 
		flush(); 
		ob_start(); 
	}
	
	
	function RegionSelector($team){
		$current_region = $this->main_model->RegionSelector($team);
		return $current_region;
	}
	
	function CheckDMAvailability($team){
		$allregions = $this->main_model->getRegions($team);
		if($allregions == FALSE){
			echo 'Set atleast 1 Region for your Workgroup.';
			exit;
		}
		foreach($allregions as $region){
			$assigned = $this->main_model->CheckDMAvailability($team, $region['region']);
			if($assigned == FALSE){
				echo 'Set atleast one available Duty Manager to '.$region['region'].'.<br/>';
				echo 'SWITCHBOARD STOPPED AT EXACTLY '.date('h:i:sA');
				exit;
			}
		}
	}
	
	function getRowApp($team){
		if($this->main_model->getRowApp($team) == FALSE){
			echo "Set atleast 1 keyword in the Settings.";
			exit;
		}
		return $this->main_model->getRowApp($team);
	}
	
	function getKeyword(){
		$team = $this->session->userdata('team');
		$keywords = $this->main_model->getRowApp($team);
		$keyword = '';
		foreach($keywords as $key => $value){
			$keyword = $keyword.','.$keywords[$key]['rows'];
		}
		echo $keyword;
	}
	
	function minCriticalTicket($team, $rowapp){
		return $this->main_model->minCriticalTicket($team, $rowapp);
		
	}
	
	function minIMTicket($team, $rowapp, $region){
		return $this->main_model->minIMTicket($team, $rowapp, $region);
		
	}
	
	function minFRTicket($team, $rowapp){
		return $this->main_model->minFRTicket($team, $rowapp);
		
	}
	
	function minRogueTicket($team, $rowapp){
		return $this->main_model->minRogueTicket($team, $rowapp);
		
	}
	
	function checkStart($team){
		$start = $this->main_model->setting("start", $team);
		if($start == 0){
			echo '<b>STOPPED AT EXACTLY '.date('h:i:sA').'.</b>';
		return FALSE;
		}
		return TRUE;
	}
	
	function sortdm($team){
		function cmp($a, $b){
			return $a['role'] - $b['role'];
		}
		
		$dms = $this->main_model->getDM($team);
		usort($dms, "cmp");
		var_dump($dms);
	}
	
	function getCalendarShift($team, $status){
		$dmshift = $this->main_model->getCalendar($team, $status);
		var_dump($dmshift);
	}
	
	function updateDM($team){
		$this->main_model->updateDM($team);
	}
	
	function smLogin(){
		$username = $this->session->userdata('shortname');
		$password = $this->main_model->getUserProfile($username, 'password');
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -kioskmode", true);
		$s = $iim1->iimSet("-var_username","$username");
		$s = $iim1->iimSet("-var_password","$password");
		$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGIN.iim");
	}
	
	function smLogOut(){
		$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGOUT.iim");
		$s = $iim1->iimClose();
	}
	
	function getDM($team, $region){
		$dms = $this->main_model->getDM($team, $region);
		return $dms[0]['shortname'];
	}
	
	function getCurrentRegion($team){
		$regions = $this->main_model->getRegions($team);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$currentRegion = '';
		foreach($regions as $region){
			if($region['start'] <= $date && $region['end'] >= $date){
				$currentRegion = $region['region'];
			}
		}
		return $currentRegion;
	}
	
	function updateCalendar(){
		$team = $this->session->userdata('team');
		// $shortname = $this->session->userdata('shortname');
		$type = $_POST['type'];

		if($type == 'new')
		{
			$status = $_POST['status'];
			$type = $_POST['ctype'];
			$shortname = $_POST['title'];
			$startdate = $_POST['startdate'];
			$startdate = strtotime($startdate);
			$startdate = date('Y-m-d', $startdate);
			$enddate = $startdate;
			$eventid = $_POST['eventid'];
			
			//ADD 1 Day to enddate
			// $enddate = strtotime($enddate);
			// $enddate = strtotime('+1 day', $enddate);
			// $enddate = date('Y-m-d H:i:s', $enddate);
			$shortname = $_POST['title'];
			$eventdetails = $this->main_model->newCalendar($shortname, $startdate, $enddate, $status, $type, $eventid);
			$eventid = $eventdetails['eventid'];
			echo json_encode($eventdetails);
		}

		if($type == 'changetitle')
		{
			$eventid = $_POST['eventid'];
			$status = $_POST['status'];
			$type = $_POST['ctype'];
			$this->main_model->changeStatusCalendar($status, $type, $eventid);
		}

		if($type == 'resetdate')
		{
			// $shortname = $_POST['title'];
			$startdate = $_POST['start'];
			$enddate = $_POST['end'];
			$eventid = $_POST['eventid'];
			$this->main_model->resetDateCalendar($startdate, $enddate, $eventid);
		}

		if($type == 'remove')
		{
			$eventid = $_POST['eventid'];
			$this->main_model->deleteCalendar($eventid);
		}

		if($type == 'fetch')
		{
			$events = array();
			$events = $this->main_model->fetchCalendar($team);
			foreach($events as $key => $value){
				if($events[$key]['status'] == 'DM'){
					$e = array("className" => 'label-dm');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Sick Leave'){
					$e = array("className" => 'label-danger');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Vacation Leave'){
					$e = array("className" => 'label-primary');
					$events[$key] = array_merge($events[$key], $e);
				}
				else{
					$e = array("className" => 'label-default');
					$events[$key] = array_merge($events[$key], $e);
				}
			}
			// $query = mysqli_query($con, "SELECT * FROM calendar");
			// while($fetch = mysqli_fetch_array($query,MYSQLI_ASSOC))
			// {
			// $e = array();
			// $e['id'] = $fetch['id'];
			// $e['title'] = $fetch['title'];
			// $e['start'] = $fetch['startdate'];
			// $e['end'] = $fetch['enddate'];

			// $allday = ($fetch['allDay'] == "true") ? true : false;
			// $e['allDay'] = $allday;

			// array_push($events, $e);
			// }
			
			echo json_encode($events);
		}

		$type = $_POST['type'];
		if($type != 'fetch' && $type != 'remove'){
			$type = $_POST['ctype'];	
			$dm = $this->main_model->getCalendar($team, $eventid);
			if($dm[0]['cstatus'] == 'DM'){

				if($dm[0]['sdate'] <= date("Y-m-d") && $dm[0]['edate'] > date("Y-m-d")){
					$data = array(
						'role' => '1'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('shortname');
					$this->db->from('specialist');
					$this->db->where('shortname', $dm[0]['shortname']);
					$this->db->update('specialist', $data);
				}
				else{
					$data = array(
						'role' => ''
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('shortname');
					$this->db->from('specialist');
					$this->db->where('shortname', $dm[0]['shortname']);
					$this->db->update('specialist', $data);
				}
			}

		}
		
		
		
		
	}
	function xx(){
		var_dump($this->main_model->getCalendar('G.AACOE','26'));
	}
	
	function changeStatusCalendar($status, $id){
		$this->main_model->changeStatusCalendar($status, $id);
	}
	
	function deleteCalendar($id){
		$this->main_model->deleteCalendar($id);
	}
	
	function fetchCalendar(){
		$team = $this->session->userdata('team');
		$schedule = $this->main_model->fetchCalendar($team);
		foreach($schedule as $key => $value){
			if($schedule[$key]['title'] == 'DM'){
				$e = array("backgroundColor" => '#cccccc');
				$schedule[$key] = array_merge($schedule[$key], $e);
			}
		}
		
		return json_encode($schedule);
	}
	
	function updateAllSettings(){
		$team = $this->session->userdata('team');
		$settings = $_POST['setting'];
		
		if($settings == 'getsetting'){
			$allsettings = $this->main_model->getSettings($team, 'allsettings');
			$timeout = $allsettings[0]['timeout'];
			$titlesearch = ($allsettings[0]['titlesearch'] == '1') ? 'true' : 'false';
			$regionsearch = ($allsettings[0]['regionsearch'] == '1') ? 'true' : 'false';
			$noregionassignee = $allsettings[0]['noregionassignee'];
			$allsettings = $timeout.','.$titlesearch.','.$regionsearch.','.$noregionassignee;
			echo $allsettings;
		}
		
		if($settings == 'getworkgroup'){
			echo $this->main_model->getWorkgroup($team);
		}
		
		if($settings == 'getkeyword'){
			$keywords = $this->main_model->getRowApp($team);
			foreach($keywords as $keyword){
				echo $keyword['rows'].',';
			}
		}
			if($settings == ''){
				$timeout = $_POST['timeout'];
				$titlesearch = $_POST['titlesearch'];
				$regionsearch = $_POST['regionsearch'];
				$noregionassignee = $_POST['noregionassignee'];
				$workgroups = $_POST['workgroups'];
				$workgroups = strtoupper($workgroups);
				$keywords = $_POST['keywords'];
				$keywords = strtoupper($keywords);
				$keywords = explode(",", $keywords);
				
				if($this->main_model->updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE..';
				}
				
				if($this->main_model->updateWorkgroup($team, $workgroups) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE..';
				}
				

				if($this->main_model->insertRowApp($team, $keywords) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE KEYWORDS..';
				}
				echo $message;
			}
		
		
	}
	
	function updateRegion(){
		$team = $this->session->userdata('team');
		$type = $_POST['type'];
		
		if($type == 'new'){
			$region = $_POST['region'];
			$start = $_POST['start'];
			$end = $_POST['end'];

			if(strtotime($start) > strtotime($end)){
				$start = '1000-01-01 '.$start;
				$end = '1000-01-02 '.$end;
			}
			else{
				$start = '1000-01-02 '.$start;
				$end = '1000-01-02 '.$end;
			}
			$this->main_model->addRegion($team, $region, $start, $end);	
			echo 'Successfully Added';
		}
		
		if($type == 'fetch'){
			$regions = $this->main_model->getRegions($team);	
			foreach($regions as $key => $value){
				$allregion[$key] = $regions[$key]['region'].','.$regions[$key]['start'].','.$regions[$key]['end'];
			}
			$allregions = '';
			foreach($allregion as $region){
				$allregions = $allregions.$region.'*';
			}
			echo $allregions;
		}
		
		
	}
	
	function updateSpecialist(){
		$team = $this->session->userdata('team');
		$shortname = strtoupper($_POST['shortname']);
		$region = $_POST['shift'];
		$keywords = $_POST['keywordnew'];
		$wholename = $_POST['wholename'];
		$email = $_POST['email'];
		$type = $_POST['type'];
		
		$rowapp = '';
		if($keywords != ''){
			$keywords = explode(',', $keywords);
			foreach($keywords as $key => $values){
				if($keywords[$key] != '')
					$rowapp = $rowapp.'['.$keywords[$key].']';
			}			
		}
		
		$this->main_model->updateSpecialist($team, $shortname, $wholename, $email, $region, $rowapp, '', '', $type);
		
	}

	function deleteSpecialist(){
		$specialistid = $_POST['specialistid'];
		$this->main_model->deleteSpecialist($specialistid);
	}
	
	function getSettings($team, $column){
		print_r($this->main_model->getSettings($team, $column));
	}
	
	function getMyTeam(){
		$team = $this->session->userdata('team');
		$myteam = $this->main_model->getMyTeam($team);
		foreach($myteam as $key => $value){
			$e = array("edit" => '<button type="button" class="btn-edit asia center fa fa-pencil" id="updateSpecialist" onclick="updateSpecialist(&#39;'.$myteam[$key]["shortname"].'&#39;);" value="" /></button><button type="button" class="btn-edit label-critical center fa fa-times" id="deleteSpecialist" onclick="deleteSpecialist(&#39;'.$myteam[$key]["id"].'&#39;);" value="" /></button>');
			$myteam[$key] = array_merge($myteam[$key], $e);
			$myteam[$key]['row'] = str_replace('[', '&nbsp;&nbsp;<span class="label-gray">&nbsp;&nbsp;', $myteam[$key]['row']);
			$myteam[$key]['row'] = str_replace(']', '&nbsp;&nbsp;</span>', $myteam[$key]['row']);
		}
		echo json_encode($myteam);
	}
	
	function getTicketlog(){
		$shortname = $this->session->userdata('shortname');
		$tickets = $this->main_model->getTickets($shortname);
		foreach($tickets as $key => $value){
			if($tickets[$key]['priority'] == '1 - Enterprise'){
				$tickets[$key]['priority'] = '<span class="label label-critical">1 - Enterprise</span>';
			}
			else if($tickets[$key]['priority'] == '2 - Site/Dept'){
				$tickets[$key]['priority'] = '<span class="label label-high">2 - Site/Dept</span>';
			}
			else if($tickets[$key]['priority'] == '3 - Multiple Users'){
				$tickets[$key]['priority'] = '<span class="label label-average">3 - Multiple Users</span>';
			}
			else if($tickets[$key]['priority'] == '4 - User'){
				$tickets[$key]['priority'] = '<span class="label label-low">4 - Users</span>';
			}
			// else{
			// 	$tickets[$key]['priority'] = '<span class="label label-danger">1 - Enterprise</span>';
			// }
		}
		echo json_encode($tickets);
	}
	
	function addSpecialist($team, $shortname, $wholename, $email, $region, $keyword){
		$this->main_model->updateSpecialist($team, $shortname, $wholename, $email, $region, $keyword, '', '', '');
	}
	
	function getRegions(){
		$team = $this->session->userdata('team');
		$regions = $this->main_model->getRegions($team);
		$data = '';
		foreach($regions as $key => $value){
			$data = $data.','.$regions[$key]['region'];
		}
		echo $data;
	}
	
	function getSpecialist($shortname){
		
		$specialist = $this->main_model->getSpecialist($shortname);
		echo $specialist[0]['region'].'*'.$specialist[0]['row'];
	}
	
	function deleteShift(){
		$shift = $_POST['shift'];
		$team = $this->session->userdata('team');
		$this->main_model->deleteShift($shift, $team);
		echo 'Successfully Deleted.';
	}

	function getTicketCountSpecialist(){
		$team = $this->session->userdata('team');
		echo json_encode($this->main_model->getTicketCountSpecialist($team), JSON_NUMERIC_CHECK);
	}

	function getTicketCountIM(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$ticketcountim = $this->main_model->getTicketCount($team, 'IM', 'ALL');
		foreach($ticketcountim as $key => $value){
				if($ticketcountim[$key]['name'] == '1 - Enterprise'){
					$e = array("color" => '#f04953');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
				else if($ticketcountim[$key]['name'] == '2 - Site/Dept'){
					$e = array("color" => '#f09144');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
				else if($ticketcountim[$key]['name'] == '3 - Multiple Users'){
					$e = array("color" => '#ffd144');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
				else{
					$e = array("color" => '#2AD2C9');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
			}
		echo json_encode($ticketcountim, JSON_NUMERIC_CHECK);
	}

	function getTicketCountFR(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$ticketcountfr = $this->main_model->getTicketCount($team, 'FR', 'ALL');
		foreach($ticketcountfr as $key => $value){
				if($ticketcountfr[$key]['name'] == '1 - Enterprise'){
					$e = array("color" => '#f04953');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
				else if($ticketcountfr[$key]['name'] == '2 - Site/Dept'){
					$e = array("color" => '#f09144');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
				else if($ticketcountfr[$key]['name'] == '3 - Multiple Users'){
					$e = array("color" => '#ffd144');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
				else{
					$e = array("color" => '#2AD2C9');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
			}
		echo json_encode($ticketcountfr, JSON_NUMERIC_CHECK);
	}

	
	function getAllRogue(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$tickets = $this->main_model->getAllRogue($team);

		foreach($tickets as $key => $value){
				if($tickets[$key]['name'] == 'IM'){
					$e = array("color" => '#94ABA8');
					$tickets[$key] = array_merge($tickets[$key], $e);
				}
				else{
					$e = array("color" => '#8c6694');
					$tickets[$key] = array_merge($tickets[$key], $e);
				}
		}

		echo json_encode($tickets, JSON_NUMERIC_CHECK);
	}

	function sendmail(){
		$this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'sample', 'sample');
	}
	
}
