<?php
class Security_model extends CI_Model{

	public function __construct(){
			parent::__construct();
			$this->load->database();
	 }
	 
    public function is_logged_in(){
        if($this->session->userdata('shortname')){
			return true;
       }
        else{
             $this->session->set_flashdata('feedback','Please login!');
             redirect('login');
       }
      }
	  
	  public function is_teamlead(){
		  $this->db->select('shortname');
		  $this->db->from('userprofile');
		  $this->db->where('shortname', $shortname);
		  $query = $this->db->get();
		  if($query->num_rows() > 0)
			  return TRUE;
		  else
			  redirect('main/userDashboard');
    }
}
	
?>