<?php
	
	class Main_model extends CI_model{
		
		public function __construct(){
			parent::__construct();
			$this->load->database();
			
		/** 
		 getUserProfile($shortname, $column)
		 getDM($team)
		 getRegions($team)
		 addRegion($team, $region, $start, $end)
		 getCalendar($team, $status)
		 updateUserProfile($shortname, $column)
		 addSpecialist($shortname, $team, $region, $email, $wholename, $row, $type, $role)
		 addTickets($tnum, $team, $category, $title, $priority, $specialist, $targetdate, $status, $type)
		 updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee)
		 getSettings($team, $column)
		 getTicketCount($team, $category, $priority)
		 getTicketCountSpecialist($team)
		 getAllSpecialist($team)
		 getAllTickets($team)
		 Send_Mail($recepient,$subject,$body)
		 emailtemplate($shortname, $tnum, $category, $title, $priority, $targetdate, $status, $description)
		 
		 getWorkgroup($team)
		 setting($option, $team)
		 saveLogs($log, $workgroup)
		 startAssign($team)
		 stopAssign($team)
		 RegionSelector($team)
		 CheckDMAvailability($team, $region)
		 getRowApp($team)
		 minCriticalTicket($team)
		 minIMTicket($team, $rowapp)
		 minFRTicket($team)
		 minRogueTicket($team)
		 
		
		
		
		
		
		
		
		
		**/
	 }
		
		function getUserProfile($shortname, $column){
			$this->db->select($column);
			$this->db->from('userprofile');
			$this->db->where('shortname', $shortname);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$result = $query->row()->$column;
				return $result;
			}else{
				return NULL;
			}
		}

		function getStartRun($team){
			$this->db->from('userprofile');
			$this->db->where('team', $team);
			$this->db->where('startrun', '1');
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->row()->shortname;
			}
			else{
				return 0;
			}
		}
		
		function getDM($team, $region = ' '){
			$this->db->select('*');
			$this->db->from('specialist');
			if($region != ' ')
				$this->db->where('region', $region);
			$this->db->where('team', $team);
			$this->db->where('status', 'Available');
			$this->db->where('role !=', '');
			// $this->db->or_where('role', '1');
			// $this->db->or_where('role', '2');
			// $this->db->or_where('role', '3');
			// $this->db->or_where('role', '4');
			// $this->db->or_where('role', '5');
			// $this->db->order_by('region', 'asc');
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return NULL;
			}
		}
		
		function getRegions($team){
			$this->db->select('region, start, end');
			$this->db->from('region');
			$this->db->where('team', $team);
			$this->db->order_by('region', 'asc');
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return NULL;
			}
		}
		
		function addRegion($team, $region, $start, $end){
			$data = array(
					'team' => $team,
					'region' => $region,
					'start' => $start,
					'end' => $end
			);
			$this->db->from('region');
			$this->db->where('team', $team);
			$this->db->where('region', $region);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->where('region', $region);
				$this->db->update('region', $data);
			}
			else{
				$this->db->insert('region', $data);
			}
			
		}
		
		function getCalendar($team, $status){
			$currenttime = time();
			$this->db->select('c.status as `cstatus`, s.wholename, c.sdate, c.edate, s.region, s.team, s.shortname');
			$this->db->from('calendar as c');
			$this->db->join('specialist as s', 'c.shortname = s.shortname');
			if($status == 'ooo'){
				$this->db->where('s.team', $team);
				$this->db->where('c.edate >', date("Y-m-d H:i:s"));
				// $this->db->where('c.sdate <', date("Y-m-d H:i:s"));
				$this->db->where('c.status', 'VL');
				$this->db->or_where('c.status', 'SL');
				$this->db->or_where('c.status', 'TRAINING');
				$this->db->or_where('c.status', 'EL');
				// $this->db->group_by('s.shortname');	//newly added
			}
			else if($status == 'shift'){
				// $this->db->where('c.status', 'DM');
				$this->db->where('s.team', $team);
				$this->db->like('c.status', 'DM');
				// $this->db->or_where('c.status', 'DM2');
				// $this->db->or_where('c.status', 'DM3');
				// $this->db->or_where('c.status', 'DM4');
				// $this->db->or_where('c.status', 'DM5');
			}
			else{
				$this->db->where('c.id', $status);
			}
			
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return 'NULL';
			}
			
		}
		
		function updateUserProfile($shortname, $column){
			$this->db->select($column);
			$this->db->from('userprofile');
			$this->db->where('shortname', $shortname);
			
			$data = array(
			'ftuser' => "0"
			);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('shortname', $shortname);
				$this->db->update('userprofile', $data);
				// echo 'Successfully Saved.';
				redirect("main/Dashboard");
			}else{
				return NULL;
			}
		}
		
		function addSpecialist($shortname, $team, $region, $email, $wholename, $row, $type, $role){
			$data = array(
			'shortname' => $shortname,
			'team' => $team,
			'region' => $region,
			'email' => $email,
			'wholename' => $wholename,
			'row' => $row,
			'type' => $type,
			'role' => $role
			);
			
			$this->db->select('shortname');
			$this->db->from('specialist');
			$this->db->where('shortname', $shortname);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				echo 'Specialist already exist.';
			}
			else{
				$this->db->insert('specialist', $data);
				echo 'Successfully Added.';
			}
		}
		
		function addTickets($tnum, $team, $category, $title, $priority, $specialist, $targetdate, $status, $type){
			$data = array(
			'tnum' => $tnum,
			'team' => $team,
			'category' => $category,
			'title' => $title,
			'priority' => $priority,
			'specialist' => $specialist,
			'targetdate' => $targetdate,
			'status' => $status,
			'type' => $type
			);

			$this->db->insert('tickets', $data);
			// echo 'Successfully Added.';
			return true;
		}
		
		function updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee){
			$data = array(
			'timeout' => $timeout,
			'titlesearch' => $titlesearch,
			'regionsearch' => $regionsearch,
			'noregionassignee' => $noregionassignee
			);
			
			$this->db->select('team');
			$this->db->from('settings');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->update('settings', $data);
				// echo 'Successfully Saved.';
				return TRUE;
				// $this->updateUserProfile($this->session->userdata('shortname'), 'ftuser');
			}
			else{
				return FALSE;
				echo 'Team does not exist.';
			}
		}
		
		function updateSpecialist($team, $shortname, $wholename, $email, $region, $keyword, $status, $role, $type){
			$data = array(
				'team' => $team,
				'shortname' => $shortname,
				'wholename' => $wholename,
				'email' => $email,
				'region' => $region,
				'row' => $keyword
			);
			if($type == 'UPDATE'){
				$this->db->select('shortname');
				$this->db->from('specialist');
				$this->db->where('shortname', $shortname);
				$query = $this->db->get();
				if($query->num_rows() > 0){
					$this->db->where('shortname', $shortname);
					$this->db->update('specialist', $data);
					echo "Specialist has been Updated.";
					return TRUE;
				}
			}
			else if($type == 'STATUS'){
				$statusarray = array(
							'status' => $status
					);
				$this->db->select('shortname');
				$this->db->from('specialist');
				$this->db->where('shortname', $shortname);
				$query = $this->db->get();
				if($query->num_rows() > 0){
					$this->db->where('shortname', $shortname);
					$this->db->update('specialist', $statusarray);
					return TRUE;
				}
			}
			else if($type == 'ROLE'){
				$rolearray = array(
							'role' => $role
					);
				$this->db->select('shortname');
				$this->db->from('specialist');
				$this->db->where('shortname', $shortname);
				$query = $this->db->get();
				if($query->num_rows() > 0){
					$this->db->where('shortname', $shortname);
					$this->db->update('specialist', $rolearray);
					return TRUE;
				}
			}
			else{
				$this->db->select('shortname');
				$this->db->from('specialist');
				$this->db->where('shortname', $shortname);
				$query = $this->db->get();
				if($query->num_rows() > 0){
					echo 'P&G shortname already exist.';
					return FALSE;
				}
				else{
					$this->db->insert('specialist', $data);
					echo "Specialist has been Added.";	
				}
			}
		}

		function deleteSpecialist($id){
			$this->db->where('id', $id);
			$this->db->delete('specialist');
			
			echo json_encode(array('status'=>'success'));
		}
		
		function getSettings($team, $column){
		if($column == 'allsettings'){
			$this->db->select('timeout, titlesearch, regionsearch, noregionassignee');
			$this->db->from('settings');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return FALSE;
			}
		}
			$this->db->select($column);
			$this->db->from('settings');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$result = $query->row()->$column;
				return $result;
			}
			else{
				return FALSE;
			}
		}
		
		function getTicketCount($team, $category, $priority){
			$tomorrow = strtotime(date(("Y-m-d")));
			$tomorrow = strtotime('+1 day', $tomorrow);
			$tomorrow = date("Y-m-d", $tomorrow);
			$this->db->select('priority as name, count(priority) as y');
			$this->db->from('ticket_per_priority_vw');
			$this->db->where('team', $team);
			$this->db->where('category', $category);
			if($priority != 'ALL')
				$this->db->where('priority', $priority);
			$this->db->where('date >=', date("Y-m-d"));
			$this->db->where('date <', $tomorrow);
			$this->db->group_by('priority', 'asc');
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getTicketCountSpecialist($team){
			$tomorrow = strtotime(date(("Y-m-d")));
			$tomorrow = strtotime('+1 day', $tomorrow);
			$tomorrow = date("Y-m-d H:i:s", $tomorrow);
			$this->db->select('specialist as name, count(tnum) as value, count(tnum) as colorValue');
			$this->db->from('tickets');
			$this->db->where('team', $team);
			$this->db->where('date >=', date("Y-m-d"));
			$this->db->where('date <', $tomorrow);
			$this->db->group_by('specialist');
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getAllSpecialist($team){
			$this->db->select('*');
			$this->db->from('specialist');
			$this->db->where('team', $team);
			$this->db->order_by('region', asc);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getSpecialist($shortname){
			$this->db->select('*');
			$this->db->from('specialist');
			$this->db->where('shortname', $shortname);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
			else
				return FALSE;
		}
		
		function getMyTeam($team){
			$this->db->select('id, shortname, wholename, email, region, row, status');
			$this->db->from('specialist');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getAllTickets($team){
			$this->db->select('tnum, title, specialist, priority, type, date, status');
			$this->db->from('tickets');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getAllRogue($team){
			$this->db->select('category as name, count(category) as y');
			$this->db->from('tickets');
			$this->db->where('team', $team);
			$this->db->where('type', 'Rogue');
			$this->db->group_by('category', 'desc');
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getTickets($shortname){
			$this->db->select('tnum, title, priority');
			$this->db->from('tickets');
			$this->db->where('specialist', $shortname);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
			else
				return FALSE;
		}
		
		
		function Send_Mail($recepient,$subject,$body){
			$this->load->library('email');
			$this->load->model('pgldap_model');
			
			if(ENVIRONMENT == 'development'){ //If Dev: We use HP SMTP
				$config['protocol'] = 'smtp';
				$config['mailpath'] = '/usr/sbin/sendmail';
				$config['smtp_host'] = 'smtp3.hpe.com';
				$config['smtp_port'] = 25;
				$config['charset'] = 'iso-8859-1';
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				
				$sender = 'noreply-switchboard@hp.com';
			}
			else{                                                                                                      // IF Prod: We use P&G SMTP
				$config['protocol'] = 'smtp';
				$config['mailpath'] = '/usr/sbin/sendmail';
				$config['smtp_host'] = 'smtpgw.pg.com';
				$config['charset'] = 'iso-8859-1';
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				
				$sender = 'noreply-switchboard@pg.com';
			}
			$this->email->from($sender, 'SWITCHBOARD');
			$this->email->to($recepient);
			$this->email->subject($subject);
			$this->email->message($body);
			
			$this->email->send();

			echo $this->email->print_debugger();


		}
		
		
		function emailtemplate($shortname, $tnum, $category, $title, $priority, $targetdate, $status, $description){
			
			

			$emailtemplate = $shortname.$tnum.$category.$title.$priority.$targetdate.$status.$description;
			
			return $emailtemplate;
		}
		
	function getWorkgroup($team){
	
		$this->db->select("workgroup");
		$this->db->from("teams");
		$this->db->where("name", $team);
		$query = $this->db->get();
		
		if($query->num_rows() > 0 )
			return $query->row()->workgroup;
		else
			return FALSE;
	}
	
	function updateWorkgroup($team, $workgroup){
		$data = array (
			'workgroup' => $workgroup,
			'name' => $team
		);
		
		$this->db->select('name');
		$this->db->from('teams');
		$this->db->where('name', $team);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$this->db->where('name', $team);
			$this->db->update('teams', $data);
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function setting($option, $team){
		
		$this->db->select($option);
		$this->db->from("settings");
		$this->db->where("team", $team);
		$query = $this->db->get();
		
		if($query->num_rows() > 0 )
			return $query->row()->$option;
		else{
			echo "Invalid Team Name.";
			return FALSE;
			
		}
		
	}
	
	function saveLogs($log, $workgroup){
		$data = array(
				'log' => $log,
				'workgroup' => $workgroup
				);
		
		if($this->db->insert("logs", $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function startAssign($team){
		$data = array(
			'start' => '1',
			'stop' => '0'
			);
		$this->db->select('*');
		$this->db->from('settings');
		$this->db->where('team', $team);
		$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->update('settings', $data);
				// echo 'Successfully Saved.';
			}
			else{
				echo 'Cannot Start, Team does not exist.';
			}
		
	}
	
	function stopAssign($team){
		$data = array(
			'start' => '0',
			'stop' => '0'
			);
		$this->db->select('*');
		$this->db->from('settings');
		$this->db->where('team', $team);
		$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->update('settings', $data);
				// echo 'Successfully Saved.';
			}
			else{
				echo 'Cannot Stop, Team does not exist.';
			}
		
	}
	
	function RegionSelector($team){
		$this->db->select('region');
		$this->db->from('region');
		$this->db->where('team', $team);
		$this->db->where('start <=', date('H:i:s'));
		$this->db->where('end >=', date('H:i:s'));
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$result = $query->row()->region;
			return $result;
		}
		return FALSE;
		
	}
	
	function CheckDMAvailability($team, $region){
		$this->db->select('shortname');
		$this->db->from('specialist');
		$this->db->where('team', $team);
		$this->db->where('region', $region);
		$this->db->where('role !=', '');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function getRowApp($team){
		$this->db->select('rows');
		$this->db->from('rowapp');
		$this->db->where('team', $team);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result_array();
		}
		else{
			return FALSE;
		}
		
	}
	
	function insertRowApp($team, $keywords){
		foreach($keywords as $keyword){
			$data[] = array(
				"rows" => $keyword,
				"team" => $team
			);
		}
		$this->db->where('team', $team);
		$this->db->delete('rowapp');
		$this->db->insert_batch('rowapp', $data);
		return TRUE;
	}
	
	function minCriticalTicket($team, $rowapp = ' '){
		$rowapp = "[".$rowapp."]";
		$this->db->select('sum(tkt_count) as tkt_count, shortname, team, region');
		$this->db->from('all_specialist_critical_view');
		if($rowapp != ' ')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		$this->db->group_by('shortname', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->shortname;
		}
		else{
			return FALSE;
		}
		
	}
	
	function minIMTicket($team, $rowapp, $region = ' '){
		$rowapp = strtoupper("[".$rowapp."]");
		$this->db->select('sum(tkt_count) as tkt_count, shortname, team, region, row');
		$this->db->from('all_specialist_imticket_view');
		if($rowapp != '[]')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		if($region != ' ')
			$this->db->where('region', $region);
		$this->db->group_by('shortname', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->shortname;
		}
		else{
			return FALSE;
		}
		
	}
	
	function minFRTicket($team, $rowapp = ' '){
		$rowapp = "[".$rowapp."]";
		$this->db->select('sum(tkt_count) as tkt_count, shortname, team, region');
		$this->db->from('all_specialist_frticket_view');
		if($rowapp != ' ')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		$this->db->group_by('shortname', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->shortname;
		}
		else{
			return FALSE;
		}
		
	}
	
	function minRogueTicket($team, $rowapp = ' '){
		$rowapp = "[".$rowapp."]";
		$this->db->select('sum(tkt_count) as tkt_count, shortname, team, region');
		$this->db->from('all_specialist_ticket_view');
		if($rowapp != ' ')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		$this->db->group_by('shortname', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->shortname;
		}
		else{
			return FALSE;
		}
		
	}
	
	function savePassword($shortname, $password){
		$data = array (
			'shortname' => $shortname,
			'password' => $password
		);
		
		$this->db->select('shortname');
		$this->db->from('userprofile');
		$this->db->where('shortname', $shortname);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$this->db->where('shortname', $shortname);
			$this->db->update('userprofile', $data);
		}
	}
	
	function updateDM($team){
		$resetrole = array(
				'role' => ''
			);
		$this->db->from('specialist');
		$this->db->where('team', $team);
		$this->db->update('specialist', $resetrole);
		$dmshift = $this->getCalendar($team, 'shift');
		foreach($dmshift as $dm){
			// if($dm['sdate'] <= date("Y-m-d H:i:s") && $dm['edate'] >= date("Y-m-d H:i:s")){ if time will be implemented
			if($dm['sdate'] <= date("Y-m-d") && $dm['edate'] >= date("Y-m-d")){
				$data = array(
					'shortname' => $dm['shortname'],
					'role' => '1'
					// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
				);
				$this->db->select('shortname');
				$this->db->from('specialist');
				$this->db->where('team', $team);
				$this->db->where('shortname', $dm['shortname']);
				$this->db->update('specialist', $data);
				
			}
		}
	}
	
	function newCalendar($shortname, $startdate, $enddate, $status, $type, $eventid){
		// $this->db->select("*");
		// $this->db->from('calendar');
		$data = array(
			'status' => $status,
			'type' => $type,
			'sdate' => $startdate,
			'edate' => $enddate,
			'shortname' => $shortname
		
		);
		
		$this->db->from('calendar');
		$this->db->where('id', $eventid);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$data = array(
				'status' => $status,
				'type' => $type,
				'sdate' => $startdate,
				'shortname' => $shortname
			);
			$this->db->where('id', $eventid);
			$this->db->update('calendar', $data);
		$id = $eventid;
		}
		else{	
		$this->db->insert('calendar', $data);
		$id = $this->db->insert_id();
		}
		return array('status'=>'success','eventid'=>$id);
		
	}
	
	function changeStatusCalendar($status, $type, $id){
		$data = array (
				'status' => $status,
				'type' => $type
		);
		
		$this->db->from('calendar');
		$this->db->where('id', $id);
		$this->db->update('calendar', $data);
		
		echo json_encode(array('status'=>'success'));
		
	}
	
	function resetDateCalendar($startdate, $enddate, $id){
		$data = array (
				'sdate' => $startdate,
				'edate' => $enddate
		);
		$this->db->from('calendar');
		$this->db->where('id', $id);
		$this->db->update('calendar', $data);
		
		echo json_encode(array('status'=>'success'));
	}
	
	function deleteCalendar($id){
		$this->db->where('id', $id);
		$this->db->delete('calendar');
		
		echo json_encode(array('status'=>'success'));
		
	}
	
	function fetchCalendar($team){
		$this->db->select('c.id, c.shortname as title, c.sdate as start, c.edate as end, c.allday as allDay, c.status as status, c.type as type');
		$this->db->from('calendar as c');
		$this->db->join('specialist as s', 'c.shortname = s.shortname');
		$this->db->where('s.team', $team);
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function deleteShift($shift, $team){
		$this->db->where('team', $team);
		$this->db->where('region', $shift);
		$this->db->delete('region');
	}
	
		
		
		
		
		
		
		

		
	}

?>