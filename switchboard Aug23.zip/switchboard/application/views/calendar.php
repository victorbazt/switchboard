

<div class="container">


	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-2 hidden-phone hidden-tablet">
			
		<h4 class="external-header">Specialists</h4>
			<div id="external-events">
				<?php
				if(isset($specialist))foreach($specialist as $spe){
					echo '<div class="external-event badge"><img class="icons pull-left drag" src="'.base_url().'assets/images/icons/drag.png"/>'.$spe['shortname'].'</div>';
					
				}
				?>
				
			</div>
			<button id="trash" class="btn btn-danger pull-right login"><img class="icons" src="<?php echo base_url();?>assets/images/icons/delete.png"/></button>
		</div>
		<div class="col-lg-10">
			<div id="calendar"></div>	
		</div>	
	</div>
	
	
				
</div>
<div id="fullCalModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                <h4 id="modalTitle" class="modal-title"></h4>
            </div>
            <div id="modalBody" class="modal-body"></div>
        </div>
    </div>
</div>

<script src='https://code.jquery.com/ui/1.11.2/jquery-ui.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js'></script>
<script>

	var buttonHTML ='<button class="btn btn-primary" onClick="';
		buttonHTML += "putCalendar(document.getElementById('ddl1'),document.getElementById('ddl2'),document.getElementById('copiedDetails')";
		buttonHTML += ')" data-dismiss="modal">File</button>';
	var copiedDetails;

	function configureDropDownLists(ddl1,ddl2) {
		
		var shift = new Array('ASIA', 'EMEA', 'NALA');
	    var leaves = new Array('Sick Leave', 'Vacation Leave');

		if(ddl1 == 'DM' || ddl1 == 'Leave'){
			console.log(1);
			var type = ddl2;
			ddl2 = document.getElementById('ddl2');
			switch (ddl1) {
				case 'DM':
				console.log(2);
					ddl2.options.length = 0;
					for (i = 0; i < shift.length; i++) {
						createOption(ddl2, shift[i], shift[i]);
					}
					$('#ddLabel').show().html('Shift:');
					break;
				case 'Leave':
				console.log(3);
					$('#ddLabel').hide();
					ddl2.options.length = 0; 
					for (i = 0; i < leaves.length; i++) {
						createOption(ddl2, leaves[i], leaves[i]);
						}
					break;
			}
			$('#fileButton').html(buttonHTML);
			$("#dependentDropdown").show();
		}else{
			switch (ddl1.value) {
				case 'DM':
				console.log(2);
					ddl2.options.length = 0;
					for (i = 0; i < shift.length; i++) {
						createOption(ddl2, shift[i], shift[i]);
					}
					$('#ddLabel').show().html('Shift:');
					break;
				case 'Leave':
				console.log(3);
					$('#ddLabel').hide();
					ddl2.options.length = 0; 
					for (i = 0; i < leaves.length; i++) {
						createOption(ddl2, leaves[i], leaves[i]);
						}
					break;
			}
			$('#fileButton').html(buttonHTML);
			$("#dependentDropdown").show();
		}
	
	    
	}

	function createOption(ddl, text, value) {
	    var opt = document.createElement('option');
	    opt.value = value;
	    opt.text = text;
	    ddl.options.add(opt);
	}

	function putCalendar(ddl1,ddl2){
		var status = '';
		var ctype = '';
		if(ddl1.value == 'DM')
		{
			copiedDetails.className = 'label-dm';
			status = ddl1.value;
		}
		else 
		{
			status = ddl1.value;
			
			if (ddl2.value == 'Sick Leave'){
				copiedDetails.className = 'label-danger';
				
			}
			else{
				copiedDetails.className = 'label-primary';
			}
		}
		ctype = ddl2.value;
		
		//append the value of second option to title variable
		//copiedDetails.title += "----"+ddl2.value;

		$('#calendar').fullCalendar('renderEvent', copiedDetails, true);
		//console.log(copiedDetails);
		
		
		console.log('event id: ',copiedDetails.id);
		var start = copiedDetails.start.format("YYYY-MM-DD HH:mm:SS");
		var end = start;
		copiedDetails.start = start;
		copiedDetails.type = ctype;
		copiedDetails.status = status;
		$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
			data: 'type=new&title='+copiedDetails.title+'&startdate='+start+'&enddate='+end+'&eventid='+copiedDetails.id+'&status='+status+'&ctype='+ctype,
			type: 'POST',
			dataType: 'json',
			success: function(response){
				console.log(response);
				copiedDetails.id = response.eventid;
				$('#calendar').fullCalendar('updateEvent',copiedDetails, true);
				// element.find('.fc-title').append("[" + copiedDetails.status + "] - " + copiedDetails.type);
				// getFreshEvents();
			},
			error: function(e){
				console.log(e.responseText);

			}
		});
		// $('#calendar').fullCalendar('removeEvents');
        // getFreshEvents();
		// $('#calendar').fullCalendar('eventRender');
		
	}
	
	function getFreshEvents(){
		$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
	        type: 'POST', // Send post data
	        data: 'type=fetch',
	        async: false,
	        success: function(s){
	        	freshevents = s;
	        }
		});
		$('#calendar').fullCalendar('addEventSource', JSON.parse(freshevents));
	}


	$(document).ready(function() {

		var zone = "05:30";  //Change this to your timezone

	$.ajax({
		url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
        type: 'POST', // Send post data
        data: 'type=fetch',
        async: false,
        success: function(s){
        	json_events = s;
        }
	});

	var currentMousePos = {
	    x: -1,
	    y: -1
	};
		jQuery(document).on("mousemove", function (event) {
        currentMousePos.x = event.pageX;
        currentMousePos.y = event.pageY;
    });

		/* initialize the external events
		-----------------------------------------------------------------*/

		$('#external-events .external-event').each(function() {

			// store data so the calendar knows to render an event upon drop
			$(this).data('event', {
				title: $.trim($(this).text()), // use the element's text as the event title
				stick: true // maintain when user navigates (see docs on the renderEvent method)
			});

			// make the event draggable using jQuery UI
			$(this).draggable({
				zIndex: 999,
				revert: true,      // will cause the event to go back to its
				revertDuration: 0  //  original position after the drag
			});

		});
		

		/* initialize the calendar
		-----------------------------------------------------------------*/

		$('#calendar').fullCalendar({
			events: JSON.parse(json_events),
			eventRender: function(event, element, view) {
			if(event.status != undefined)
				element.find('.fc-title').append("[" + event.status + "] - " + event.type);
			},
			// $('#calendar').fullCalendar('renderEvent'),
			//events: [{"id":"14","title":"New Event","start":"2015-01-24T16:00:00+04:00","allDay":false}],
			//eventColor : '#01a982',
			firstDay:1,
			utc: true,
			header: {
				left: 'title',
				right: 'prev,today,next'
			},
			editable: true,
			droppable: true, 
			slotDuration: '00:30:00',
			eventReceive: function(event){
				// var title = event.title;
				var start = event.start.format("YYYY-MM-DD HH:mm:SS");
				// var end = (event.end == null) ? start : event.end.format();
				var end = start;
				event.className = '';
				// event.title = title;
				
				copiedDetails = event;
				
				var content = 'Type:<br><fieldset class="form-group"><select class="form-control full-width" id="ddl1" onChange="';

				content += "configureDropDownLists(this,document.getElementById('ddl2'))";

				content += '"><option disabled selected value> -- select a type -- </option><option>DM</option><option>Leave</option></select></fieldset><fieldset id="dependentDropdown" class="form-group"><div id="ddLabel"></div><select id="ddl2" class="form-control full-width"></select></fieldset><div id="fileButton" text-align="right"></div>';
				start = event.start.format("YYYY-MM-DD");
				$('#modalTitle').html('Filing for ' + event.title + ' on ' + start);
	            $('#modalBody').html(content);
	            $("#dependentDropdown").hide();
	            $('#fileButton').html('<button id="fileButton" class="btn btn-primary disabled">File</button>');
				$('#fullCalModal').modal();
				
			},
			eventDrop: function(event, delta, revertFunc) {
		        var start = event.start.format();
		        var end = (event.end == null) ? start : event.end.format();
				
				// console.log("EVENTDROP",status);
		        $.ajax({
					url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
					data: 'type=resetdate&title='+event.title+'&start='+start+'&end='+end+'&status='+event.status+'&eventid='+event.id,
					type: 'POST',
					dataType: 'json',
					success: function(response){
						if(response.status != 'success')		    				
						revertFunc();
					},
					error: function(e){		    			
						revertFunc();
						alert('Error processing your request: '+e.responseText);
					}
				});
		    },
		    eventClick: function(event, jsEvent, view) {
		    	// console.log(event.id);
				// var title = event.title;
				copiedDetails = event;
				var start = event.start.format("YYYY-MM-DD");
				var content = 'Type:<br><fieldset class="form-group"><select class="form-control full-width" id="ddl1" onChange="';

				content += "configureDropDownLists(this,document.getElementById('ddl2'))";

				content += '">';
				content += (event.status == "DM") ? '<option selected>DM</option><option>Leave</option>' : '<option>DM</option><option selected>Leave</option>';
				content += '</select></fieldset><fieldset id="dependentDropdown" class="form-group"><div id="ddLabel"></div><select id="ddl2" class="form-control full-width"></select></fieldset><div id="fileButton" text-align="right"></div>';
				
				$('#modalTitle').html('Filing for ' + event.title + ' on ' + start);
	            $('#modalBody').html(content);
	            // $("#dependentDropdown").hide();
	            $('#fileButton').html('<button id="fileButton" class="btn btn-primary disabled">File</button>');
				$('#fullCalModal').modal();
				configureDropDownLists(event.status, event.type);
		          // var title = $('#fullCalModal').modal();
		          // if (event.title){
		              // // event.title = title;
		              // console.log('type='+event.type+'status='+event.status+'title&title='+event.title+'&eventid='+event.id);
		              // $.ajax({
				    		// url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
				    		// data: 'type=changetitle&title='+event.title+'&status='+event.status+'&ctype='+event.type+'&eventid='+event.id,
				    		// type: 'POST',
				    		// dataType: 'json',
				    		// success: function(response){	
				    			// if(response.status == 'success')			    			
		              				// $('#calendar').fullCalendar('updateEvent',event);
				    		// },
				    		// error: function(e){
				    			// alert('Error processing your request: '+e.responseText);
				    		// }
				    	// });
		          // }
			},
			eventResize: function(event, delta, revertFunc) {
				var end = event.end.format();
				var start = event.start.format();
		        $.ajax({
					url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
					data: 'type=resetdate&title='+event.title+'&start='+start+'&end='+end+'&status='+event.status+'&eventid='+event.id,
					type: 'POST',
					dataType: 'json',
					success: function(response){
						if(response.status != 'success')		    				
						revertFunc();
					},
					error: function(e){		    			
						revertFunc();
						alert('Error processing your request: '+e.responseText);
					}
				});
		    },
			eventDragStop: function (event, jsEvent, ui, view) {
			    if (isElemOverDiv()) {
			    	var con = confirm('Are you sure to delete this event permanently?');
			    	if(con == true) {
						$.ajax({
				    		url: '<?php echo base_url(); ?>index.php/main/updateCalendar',
				    		data: 'type=remove&eventid='+event.id,
				    		type: 'POST',
				    		dataType: 'json',
				    		success: function(response){
				    			console.log(response);
				    			if(response.status == 'success'){
				    				$('#calendar').fullCalendar('removeEvents');
            						getFreshEvents();
            					}
				    		},
				    		error: function(e){	
				    			alert('Error processing your request: '+e.responseText);
				    		}
			    		});
					}   
				}
			}
			
		});
		
	


	


	function isElemOverDiv() {
        var trashEl = jQuery('#trash');

        var ofs = trashEl.offset();

        var x1 = ofs.left;
        var x2 = ofs.left + trashEl.outerWidth(true);
        var y1 = ofs.top;
        var y2 = ofs.top + trashEl.outerHeight(true);

        if (currentMousePos.x >= x1 && currentMousePos.x <= x2 &&
            currentMousePos.y >= y1 && currentMousePos.y <= y2) {
            return true;
        }
        return false;
    }

	});


</script>

<script>
	
	

</script>