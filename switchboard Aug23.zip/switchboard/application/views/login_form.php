<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>SWITCHBOARD</title>
    
    
    
    <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto">

        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/login.css">
		<link rel="icon" type="image/png" href="<?php echo base_url(); ?>/images/favicon.ico" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/animate.css">

    
    
    
  </head>

  <body>

    <div class="login-form animated bounceInDown">
	<div class="logo"></div>
     <h2>SWITCHBOARD</h2>
     <div class="form-group">
	 <form action="<?php echo base_url();?>index.php/pgldap/logincheck" autocomplete="off" method="post">
	 <input name="username" style="display: none;" type="text" />
       <input type="text" class="form-control login" placeholder="P&G Username" name="pgusername" required/>
	   
       <i class="fa fa-user"></i>
     </div>
     <div class="form-group log-status">
       <input type="password" class="form-control" placeholder="Password" name="pgpassword" required/>
	   <input name="foilautofill" style="display: none;" type="password" />
       <i class="fa fa-lock"></i>
     </div>
	 <?php 
	 $error = 0;
	 if(isset($_GET['e']))
		 $error = $_GET['e'];
	 if($error == 1)
		 echo '<span class="alert">Invalid Credentials</span>'; ?>
      <br/>
     <button type="submit" class="log-btn" >LOG IN</button>
	 </form>
     
    
   </div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>


    
    
    
  </body>
</html>
