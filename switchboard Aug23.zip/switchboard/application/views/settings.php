<div class="container">
	<div class="row">		
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div class="panel">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/settings.png"/>Settings</div></div>
				<div class="panel-body">

					
					
					
					
					
					
					<form action="<?php echo base_url();?>index.php/main/saveUserSetup" autocomplete="off" method="post">
		
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<p>Dispatcher Refresh Interval</p>
				<p>Assign based on Ticket Title</p>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<input type="number" name="timeout" class="form-control" value="10" step="5" />
				<div class="onoffswitch">
					<input type="checkbox" name="titlesearch" class="onoffswitch-checkbox" id="titlesearch" checked>
					<label class="onoffswitch-label" for="titlesearch">
						<span class="onoffswitch-inner"></span>
						<span class="onoffswitch-switch"></span>
					</label>
				</div>
			</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>Assign based on Region</p>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<div class="onoffswitch">
					<input type="checkbox" name="regionsearch" class="onoffswitch-checkbox" id="regionsearch" checked>
					<label class="onoffswitch-label" for="regionsearch">
						<span class="onoffswitch-inner"></span>
						<span class="onoffswitch-switch"></span>
					</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>If no Region Match</p>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<div class="styled-select">
					<select name="noregionassignee">
					  <option value="specialist" >ASSIGN TO NEXT AVAILABLE</option>
					  <option value="dm" >TAG AS ROGUE</option>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
		</div>
		<div class="row text-center">
			<a href="<?php echo base_url() ?>index.php/main/userSetup"><button type="submit" class="btn btn-primary center">SAVE</button></a>
		</div>
					
					
					
					
					
					
					
					
				</div>
			</div>
		</div>
	</div>
</div>