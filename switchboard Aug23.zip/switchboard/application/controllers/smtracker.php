<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class smtracker extends CI_Controller {

	
	 public function __construct(){
			ini_set('max_execution_time', 3000000);
			date_default_timezone_set("Asia/Singapore");
			parent::__construct();
			$this->load->helper('url');
			$this->load->model('smtracker_model');
			
			
	 }
	 
	 function myFunction($myParameter){
		 echo $myParameter;
	 }
	 
	 
	 
	 function openTickets($team, $username){
		 echo "<style type='text/css'>  body { font-family: lucida console; color: #eeeeee; font-size: 11px;	 overflow-x: hidden !important; }  </style>";
		 echo "<script> function pageScroll(){window.scrollBy(0,10); scrolldelay = setTimeout('pageScroll()',1350); }pageScroll(); </script>";
		 if($this->smtracker_model->getSettings($team, 'start') == '1'){
		 	echo '<script> window.top.location.reload(); </script>';
		 	exit;
		 }
		$this->startAssign($team);
		$this->startRun($username);
		$start = $this->smtracker_model->setting("start", $team);
		
		//function for USORT
		function cmp($a, $b){
			return $a[2] - $b[2];
		}
		
		while($start == 1){
			$this->flush_buffers();
			 $workgroup = $this->smtracker_model->getWorkgroup($team);
			 $stop = $this->smtracker_model->setting("stop", $team);
			 $smloggedin = 0;		//placehlder if switchboard is already logged in/logged out.
			 
			 if($workgroup == FALSE){
				 echo "Team/Workgroup does not exist in the system.";
				 $this->stopAssign();
				 echo '<b>['.date('h:i:s A').']<br/>SWITCHBOARD WILL NOT RUN.</b>';
				 return FALSE;	
			 }
			 $workgroups = explode(",", $workgroup);		//workgroups should be separated by comma without space
			 
			 if(($stop == 0) && ($start == 1)){	//stop means pausing the current run; start == 0 terminating the run
				 
				 //copy this for FR Tickets
				 foreach($workgroups as $groups){
					$stop = $this->smtracker_model->setting("stop", $team);
					$iimtickets = array();
					unset($iimtickets);
					$type = '';		//Rogue or not
					
					echo '['.date('h:i:sA').']<br/>';
					echo 'Switchboard running. . .<br/><br/>	';
					echo 'extracting IM tickets<br/>Please Wait. . .<br/><br/>	';
					
					$this->flush_buffers();
					
					$imtickets = $this->getOpenIM($groups);				//get IM Tickets
					// var_dump($imtickets);
					// $imtickets = array(
							// array('IM', 'TITLE', 'PRIORITY', 'STATUS', 'TARGET DATE', 'SPECIALIST'),
							// array('IM012345', 'AR TEST TICKET DO NOT DELETE', ' 1 - Enterprise ', 'Open', '', ' N/A '),
							// array('IM012345', 'AS TEST TICKET DO NOT DELETE', ' 4 - User ', 'Open', '', ' N/A ')
					// );
					
					if($this->checkStart($team) == FALSE){
						return FALSE;
					}
					// var_dump($imtickets);
					
					if($imtickets == FALSE){
						return FALSE;
					}
					
					usort($imtickets, "cmp");								//sort tickets to 1 - Enterprise > 4 - User
					
					$openIMoccurance = array_column($imtickets, 3);			//Open Occurance in smtracker
					$naIMoccurance = array_column($imtickets, 5);			//N/A Occurance in smtracker
					$numOpenIM = array_count_values($openIMoccurance);		
					$numNAIM = array_count_values($naIMoccurance);
					
					if(!isset($numOpenIM['Misrouted ']))
						$numOpenIM['Misrouted '] = 0;
					
					if(!isset($numNAIM['N/A ']))
						$numNAIM['N/A '] = 0;
					
					$totalOpen = $numNAIM['N/A ']-$numOpenIM['Misrouted '];
					echo '['.date('h:i:sA').']<br/> Extracted a total of '.$totalOpen.'  Open IM ticket/s.<br/><br/>';
					
					$this->flush_buffers();
					
					if($totalOpen > 0){
						// $this->smLogin($username);
						echo '<br/>Logging-in to SM...<br/><br/>';
						$this->flush_buffers();
						if($smloggedin == 0){
							$password = $this->smtracker_model->getUserProfile($username, 'password');
							$iim1 = new COM("imacros");
							$s = $iim1->iimInit("-runner -kioskmode", true);
							$s = $iim1->iimSet("-var_username","$username");
							$s = $iim1->iimSet("-var_password","$password");
							$loginiim = '"'.FCPATH.'Macros\SM LOGIN.iim"';
							$s = $iim1->iimPlay($loginiim);
							if($s > 0)
								$smloggedin = 1;
							else{
								echo $iim1->iimGetLastError;
								$s = $iim1->iimClose();
								return FALSE;
							}
						}
					
					
						for($a=1;$a<count($imtickets);$a++){
							
							$category = 'IM';
							$tnum = trim($imtickets[$a][0], " ");
							$title = ' '.$imtickets[$a][1];
							$rtitle = ' '.preg_replace('/[^A-Za-z0-9]/', ' ', $title);
							$priority = trim($imtickets[$a][2], " ");
							$status = trim($imtickets[$a][3], " ");
							$targetdate = $imtickets[$a][4];
							$specialist = trim($imtickets[$a][5], " ");
							$titlesearch = $this->smtracker_model->getSettings($team, 'titlesearch');
							$regionsearch = $this->smtracker_model->getSettings($team, 'regionsearch');
							$noregionassignee = $this->smtracker_model->getSettings($team, 'noregionassignee');
							$rowapp = $this->getRowApp($team);
							$allregion = $this->smtracker_model->getRegions($team);
							$regionPresent = 0;
							$keywordPresent = 0;
							$currentRegion = $this->getCurrentRegion($team);
							
							if($status == "Open" && $specialist == "N/A"){				//change this for team specs
								//Processing ticket should begin here
								echo 'Processing the Tickets...<br/><br/>';
								$this->flush_buffers();
								if($this->smtracker_model->updateDM($team) == FALSE){
									echo '<br/>Failed to Update the current DMs.<br/>';
								}
								$current_region = $this->RegionSelector($team);	//remove this if region tagging is turned off
								if($titlesearch == 1 || $regionsearch == 1){
										if($this->CheckDMAvailability($team) == FALSE){				//check if Duty Manager is available per Region if Regionsearch is ON
											$logoutiim = '"'.FCPATH.'Macros\SM LOGOUT.iim"';
											$s = $iim1->iimPlay($logoutiim);
											$s = $iim1->iimClose();
											return FALSE;
										}
								}
								$type = '';
								
								//CHECK TITLE FOR REGION TAG
								$temp_regionpos = 200;
								$region = '';
								foreach($allregion as $allregions)
								{
									$regionlen = strlen($allregions['region']);
									$regionpos = stripos('  '.$rtitle, ' '.$allregions['region'].' ', 1);
									if($regionpos < $temp_regionpos && $regionpos != '')
									{
										$temp_regionpos = $regionpos;
										$region = $allregions['region'];
										$regionPresent = 1;
									}
								}
								//CHECK TITLE FOR KEYWORD TAGS
								$temp = '';
								$temp_rpos = 200; //title length
								$temp_rowapp = '%^&*(';
								foreach($rowapp as $rowapps)
								{
									$rlen = strlen($rowapps['rows']);
									$rpos = stripos($rtitle, ' '.$rowapps['rows'].' ', 1);
									if($rpos < $temp_rpos && $rpos != '')
									{
										$temp_rpos = $rpos;
										$temp_rowapp = $rowapps['rows'];
										$keywordPresent = 1;
									}
								}
								$rowapps = $temp_rowapp;	//change to keyword that's present in title
								$con = 0;
								if($titlesearch == 1){				//SEARCH TITLE FOR KEYWORD SETTING
									
									if($priority == '1 - Enterprise' && $keywordPresent == 1){
										$specialist = $this->minCriticalTicket($team, $rowapps);
										$con = 1;
									}
									else if($priority == '1 - Enterprise' && $keywordPresent == 0){
										$specialist = $this->getDM($team, $currentRegion);
										$type = 'Rogue';
										$con = 2;
									}
									else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 1 && $regionPresent == 1){
										$specialist = $this->minIMTicket($team, $rowapps, $region);
										$con = 3;
									}
									else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 1 && $regionPresent == 0 && $noregionassignee == 'dm'){
										$specialist = $this->getDM($team, $currentRegion);
										$type = 'Rogue';
										$con = 4;
									}
									else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 1 && $regionPresent == 0 && $noregionassignee == 'specialist'){
										$specialist = $this->minIMTicket($team, $rowapps);
										$con = 5;
									}
									else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 0){
										$specialist = $this->minIMTicket($team, $rowapps);
										$con = 6;
									}
									else if($priority != '1 - Enterprise' && $keywordPresent == 0 && $regionsearch == 1 && $regionPresent == 1){
										$specialist = $this->getDM($team, $region);
										$type = 'Rogue';
										$con = 7;
									}
									else if($priority != '1 - Enterprise' && $keywordPresent == 0 && $regionsearch == 1 && $regionPresent == 0){
										$specialist = $this->getDM($team, $currentRegion);
										$type = 'Rogue';
										$con = 8;
									}
									else{
										$specialist = $this->getDM($team, $currentRegion);
										$type = 'Rogue';
										$con = 9;

									}
									if($specialist == ''){
										$specialist = $this->getDM($team, $currentRegion);
										$type = 'Rogue';
										$con = 10;
									}
									
							
								}
								else{
									if($priority == '1 - Enterprise'){
										$specialist = $this->minCriticalTicket($team, '');
									}
									else{
										$specialist = $this->minIMTicket($team, '');
									}
								}
								//ASSIGN TICKET TO SM9
								$status = 'Accepted';
								$update = "Assigned to ".$specialist.". [Switchboard]";
								 if ($category == "IM")
								{
									// $iim1 = new COM("imacros");
									// $s = $iim1->iimOpen("-runner", FALSE);
									// $s = $iim1->iimOpen('-cr -runner -crUserDataDir "C:\Users\perjohnv\AppData\Local\Google\Chrome\User Data\G.AACOE"', FALSE);
									// $s = $iim1->iimPlayCode($iimassignTicket);
									$s = $iim1->iimSet("-var_ticketnum","$tnum");
									$s = $iim1->iimSet("-var_status","$status");
									$s = $iim1->iimSet("-var_assignee","$specialist");
									$s = $iim1->iimSet("-var_update","$update");
									$assigniim = '"'.FCPATH.'Macros\ASSIGN TICKET.iim"';
									$s = $iim1->iimPlay($assigniim);
								}
								else if ($category == "FR")
								{
									$s = $iim1->iimSet("-var_ticketnum","$tnum");
									$s = $iim1->iimSet("-var_status","$status");
									$s = $iim1->iimSet("-var_assignee","$specialist");
									$s = $iim1->iimSet("-var_update","$update");
									$assigniim = '"'.FCPATH.'Macros\ASSIGN FR TICKET.iim"';
									$s = $iim1->iimPlay($assigniim);
								}
								//END ASSIGNMENT

								echo $tnum.' has been assigned to '.$specialist.'<br/>';
								$this->smtracker_model->addTickets($tnum, $team, $category, $title, $priority, $specialist, $targetdate, 'Accepted', $type);
								$this->smtracker_model->saveLogs($title, $team);
								
								$this->flush_buffers();
							}

							if($this->checkStart($team) == FALSE){
								$logoutiim = '"'.FCPATH.'Macros\SM LOGOUT.iim"';
								$s = $iim1->iimPlay($logoutiim);
								if($s > 0)
									$smloggedin = 0;
								else{
									echo $iim1->iimGetLastError;
								}
								$s = $iim1->iimClose();
								exit();
							}
						}
					
					
					}
				 }
				 // $this->smLogOut();
				if($smloggedin == 1){
					$logoutiim = '"'.FCPATH.'Macros\SM LOGOUT.iim"';
					$s = $iim1->iimPlay($logoutiim);
					if($s > 0)
						$smloggedin = 0;
					else
						echo $iim1->iimGetLastError;
					 $s = $iim1->iimClose();
					 
				}
				 
				 $timeout = $this->smtracker_model->setting("timeout", $team);
				 
				 $nextdispatch = strtotime(date("Y-m-d H:i:s"));
				 $nextdispatch = $nextdispatch+$timeout;
				 $nextdispatch = date("h:i:sA", $nextdispatch);
				 echo '<br/><br/>Next Dispatch at '.$nextdispatch.'<br/><br/><br/>';
				 
				 $this->flush_buffers();
				 
				 $start = $this->smtracker_model->setting("start", $team);
				 for($a=0;$a<$timeout;$a+=5){
					sleep(5);
					if($this->checkStart($team) == FALSE){
						return FALSE;
					}
				 }
				 
			 }
			 else{
				 if($start == 1)
				 sleep(1);
			 }
		}
	 }
	 
	function getOpenIM($team){

		$ticketdetails = array();
		unset($ticketdetails);
					
		$extract_url = FCPATH."\Macros\ExtractTIckets.iim";
		
		ob_start(); ?>
		
		VERSION BUILD=10022823
		SET EXTRACT_TEST_POPUP NO
		SET !TIMEOUT_PAGE 120
		TAB T=1
		TAB CLOSEALLOTHERS
		TAB OPEN
		TAB T=2
		'extract Incident Ticket
		URL GOTO=http://smtracker.pg.com/pls/smtracker/pg_tracker.inc_groups?i_group=G.AACOE
		TAG POS=1 TYPE=TABLE ATTR=* EXTRACT=TXT
		TAB T=1
		TAB CLOSEALLOTHERS
		
		
		<?php
		$extractticket = ob_get_clean();
		
		
		
		$iimextractTicket = "
		VERSION BUILD=10022823
		SET EXTRACT_TEST_POPUP NO
		TAB T=1
		TAB CLOSEALLOTHERS
		TAB OPEN
		TAB T=2
		'extract Incident Ticket
		URL GOTO=http://smtracker.pg.com/pls/smtracker/pg_tracker.inc_groups?i_group=".$team."
		TAG POS=1 TYPE=TABLE ATTR=* EXTRACT=TXT
		TAB T=1
		TAB CLOSEALLOTHERS";
		
		$iim1 = new COM("imacros");
		$s = $iim1->iimOpen("-runner -kioskmode ", TRUE);
		$s = $iim1->iimSet("workgroup","$team");
		$s = $iim1->iimPlay($extract_url);
		// $s = $iim1->iimPlayCode($extractticket);
		
		if($s > 0){
		$tickets = $iim1->iimGetLastExtract();
		$s = $iim1->iimClose();
		$tickets = str_replace('[EXTRACT]', '', $tickets);
		$ticket = explode("#NEWLINE#", $tickets);
		
		foreach($ticket as $key => $ticks){
			$tdetails = explode("#NEXT#", $ticks);
			$ticketdetails[$key] = $tdetails;
		}
		return $ticketdetails;
		
		}
		else{
			echo $iim1->iimGetLastError;
			$s = $iim1->iimClose();
			echo '<br/>Failed to Extract Ticket';
			return FALSE;
		}
	 }
	 
	 function stopAssign($team){					//change value of Stop from DB
	 	// $this->load->model('main_model');
	 	// $team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		 $this->smtracker_model->stopAssign($team);
	 }
	 
	 function startAssign($team){					//change value of Start from DB
	 	// $this->load->model('main_model');
	 	// $team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$this->smtracker_model->startAssign($team);
	 }
	 
	 function startRun($shortname){					//change value of StartRun in UserProfile DB
		 $this->smtracker_model->startRun($shortname);
	 }
	 
	 function stopRun($shortname){					//change value of StartRun in UserProfile DB
		 $this->smtracker_model->stopRun($shortname);
	 }
	 
	 function assignTicket($tnum, $specialist, $priority, $type, $row, $titlesearch, $category){
		 

		 $ticketnum = $tnum;
		 $status = 'Accepted';
		 $assigned = $specialist;
		 $update = "Assigned to ".$specialist.". [AUTO-DM]";
		 
		$iimassignTicket = "
		VERSION BUILD=9002379
		SET !EXTRACT_TEST_POPUP NO
		TAB T=1
		TAB CLOSEALLOTHERS
		WAIT SECONDS=2
		TAG POS=1 TYPE=SPAN ATTR=TXT:Search<SP>Incidents
		FRAME F=3
		WAIT SECONDS=10
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/number CONTENT=".$ticketnum."
		FRAME F=0
		TAG POS=1 TYPE=BUTTON ATTR=TXT:search
		WAIT SECONDS=5
		FRAME F=3
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/problem.status CONTENT=".$status."
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/assignee.name CONTENT=".$assigned."
		TAG POS=1 TYPE=A FORM=NAME:topaz ATTR=TXT:Update
		TAG POS=1 TYPE=TEXTAREA FORM=NAME:topaz ATTR=NAME:var/pmc.actions/pmc.actions CONTENT=".$update."
		WAIT SECONDS=5
		FRAME F=0
		TAG POS=1 TYPE=BUTTON ATTR=TXT:save<SP>&<SP>Exit
		WAIT SECONDS=2
		FRAME F=3
		TAG POS=1 TYPE=DIV ATTR=CLASS:messageTrayElement<SP>infoMsg EXTRACT=TXT
		FRAME F=0
		TAG POS=2 TYPE=BUTTON ATTR=TXT:Cancel
		WAIT SECONDS=2";
		 
		 if ($category == "IM")
		{
			$iim1 = new COM("imacros");
			// $s = $iim1->iimOpen("-runner", FALSE);
			$s = $iim1->iimOpen('-cr -runner -crUserDataDir "C:\Users\perjohnv\AppData\Local\Google\Chrome\User Data\G.AACOE"', FALSE);
			$s = $iim1->iimPlayCode($iimassignTicket);
			// $s = $iim1->iimSet("-var_ticketnum","$ticketnum");
			// $s = $iim1->iimSet("-var_status","$status");
			// $s = $iim1->iimSet("-var_assignee","$assigned");
			// $s = $iim1->iimSet("-var_update","$update");
			// $s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\assign ticket.iim");
		}
		else if ($category == "FR")
		{
			$iim1 = new COM("imacros");
			$s = $iim1->iimOpen("-runner", FALSE);
			$s = $iim1->iimSet("-var_status","$status");
			$s = $iim1->iimSet("-var_assignee","$assigned");
			$s = $iim1->iimSet("-var_update","$update");
			$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\assign fr ticket.iim");
		}
		 
		 
	 }
	 
	 
	 
	 
	 
	 function flush_buffers(){ 
		ob_end_flush(); 
		flush(); 
		ob_start(); 
	}
	
	
	function RegionSelector($team){
		$current_region = $this->smtracker_model->RegionSelector($team);
		return $current_region;
	}
	
	function CheckDMAvailability($team){
		$allregions = $this->smtracker_model->getRegions($team);
		if($allregions == FALSE){
			echo 'Set atleast 1 Region for your Workgroup.';
			return FALSE;
		}
		foreach($allregions as $region){
			$assigned = $this->smtracker_model->CheckDMAvailability($team, $region['region']);
			if($assigned == FALSE){
				echo 'Set atleast one available Duty Manager to '.$region['region'].'.<br/>';
				echo 'SWITCHBOARD STOPPED AT EXACTLY '.date('h:i:s A');
				return FALSE;
			}
		}
		return TRUE;
	}
	
	function getRowApp($team){
		if($this->smtracker_model->getRowApp($team) == FALSE){
			echo "Set atleast 1 keyword in the Settings.";
			exit;
		}
		return $this->smtracker_model->getRowApp($team);
	}
	
	function minCriticalTicket($team, $rowapp){
		return $this->smtracker_model->minCriticalTicket($team, $rowapp);
		
	}
	
	function minIMTicket($team, $rowapp){
		return $this->smtracker_model->minIMTicket($team, $rowapp);
		
	}
	
	function minFRTicket($team, $rowapp){
		return $this->smtracker_model->minFRTicket($team, $rowapp);
		
	}
	
	function minRogueTicket($team, $rowapp){
		return $this->smtracker_model->minRogueTicket($team, $rowapp);
		
	}
	
	function checkStart($team){
		$start = $this->smtracker_model->setting("start", $team);
		if($start == 0){
			echo '<br/><b>['.date('h:i:sA').']<br/>SWITCHBOARD IS MANUALLY STOPPED.</b>';
		return FALSE;
		}
		return TRUE;
	}
	
	function sortdm($team){
		function cmp($a, $b){
			return $a['role'] - $b['role'];
		}
		
		$dms = $this->smtracker_model->getDM($team);
		usort($dms, "cmp");
		var_dump($dms);
	}
	
	function getCalendarShift($team, $status){
		$dmshift = $this->smtracker_model->getCalendar($team, $status);
		var_dump($dmshift);
	}
	
	function updateDM($team){
		$this->smtracker_model->updateDM($team);
		return TRUE;
	}
	
	function getDM($team, $region){
		$dms = $this->smtracker_model->getDM($team, $region);
		return $dms[0]['shortname'];
	}
	
	function getCurrentRegion($team){
		$regions = $this->smtracker_model->getRegions($team);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$currentRegion = '';
		foreach($regions as $region){
			if($region['start'] <= $date && $region['end'] >= $date){
				$currentRegion = $region['region'];
			}
		}
		return $currentRegion;
	}


}
