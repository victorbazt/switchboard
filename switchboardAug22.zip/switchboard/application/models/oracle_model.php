<?php
class oracle_model extends CI_Model {
	
	function heartbeat(){
		
		//TAKE NOTE THAT ORACLE ALWAYS RETURNS ALL CAPS COLUMN
		//TAKE NOTE NOT TO PUT ; at the end of the query as it gives out errors
		$sql = "
			SELECT SYSDATE as temp FROM DUAL
		";
		$heartbeatdb = $this->load->database('oracle', true);
		$query = $heartbeatdb->query($sql);
		return $query->first_row()->TEMP;
	}
	
	
}
?>