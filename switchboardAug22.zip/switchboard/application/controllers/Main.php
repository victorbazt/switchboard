<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct(){
			parent::__construct();
			ini_set('max_execution_time', 3000000);
			date_default_timezone_set("Asia/Singapore");
			$this->load->helper('url');
			$this->load->library('session');
			$this->load->model('main_model');
			$this->load->model('pgldap_model');
			date_default_timezone_set('Asia/Hong_Kong');
			$this->load->model('security_model');
			$this->security_model->is_logged_in();
	 }
	 
	 /*
	 Dashboard()
	 myTeam()
	 requestAccess()
	 saveRequestAccess()
	 userSetup()
	 saveUserSetup()
	 validateWorkgroup($workgroup)
	 getPGDetails($shortname)
	 donutIMFR()
	 donutROGUE()
	 calendar()
	 settings()
	 logout()
	 ticketlog()
	 openTickets($team)
	 getOpenIM($team)
	 stopAssign($team)
	 startAssign($team)
	 assignTicket($tnum, $specialist, $priority, $type, $row, $titlesearch, $category)
	 flush_buffers()
	 RegionSelector($team)
	 CheckDMAvailability($team)
	 getRowApp($team)
	 minCriticalTicket($team)
	 minIMTicket($team, $rowapp)
	 minFRTicket($team)
	 minRogueTicket($team)
	 checkStart($team)
	 sortdm($team)
	 getCalendarShift($team, $status)
	 updateDM($team)
	 smLogin()
	 
	 
	 
	 
	 */
	 
	 
	public function index()
	{

		redirect('Dashboard');
	}
	function getTicketCount(){
		var_dump($this->main_model->getTicketCount('G.AACOE', 'IM', '3 - Multiple Users'));
	}
	
	function Dashboard(){
		$data['currentPage'] = "home";
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$this->session->set_userdata('team', $team);		//set current team to session
		$data['dmoftheday'] = $this->main_model->getDM($team, 0);
		$data['regions'] = $this->main_model->getRegions($team);
		$data['ooospecialist'] = $this->main_model->getCalendar($team, 'ooo');
		$data['ticketcountspe'] = $this->main_model->getTicketCountSpecialist($team);
		//for pie chart
		$data['imcritical'] = $this->main_model->getTicketCount($team, 'IM', '1 - Enterprise');
		$data['imhigh'] = $this->main_model->getTicketCount($team, 'IM', '2 - Site/Dept');
		$data['imaverage'] = $this->main_model->getTicketCount($team, 'IM', '3 - Multiple Users');
		$data['imlow'] = $this->main_model->getTicketCount($team, 'IM', '4 - User');
		
		$data['frcritical'] = $this->main_model->getTicketCount($team, 'FR', '1 - Enterprise');
		$data['frhigh'] = $this->main_model->getTicketCount($team, 'FR', '2 - Site/Dept');
		$data['fraverage'] = $this->main_model->getTicketCount($team, 'FR', '3 - Multiple Users');
		$data['frlow'] = $this->main_model->getTicketCount($team, 'FR', '4 - User');
		
		
		
		if($this->main_model->getUserProfile($this->session->userdata('shortname'), 'ftuser') == TRUE){
			
			// $this->userSetup();
			// echo "this is first time user setup page";
			$data['hidemenu'] = TRUE;
			$this->load->view("template/header", $data);
			$this->load->view("setupwizard");
			$this->load->view("template/footer");
		}
		else
		{
			// echo "this is the dashboard";
			$this->load->view("template/header", $data);
			$this->load->view("home");
			$this->load->view("template/footer");
		}
	}
	
	function myTeam(){
		$data['currentPage'] = "myteam";
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$data['allspecialist'] = $this->main_model->getAllSpecialist($team);
		$this->load->view("template/header", $data);
		$this->load->view("specialist", $data);
		$this->load->view("template/footer");
	}
	
	// function assignTicket(){
		//ACTUAL ASSIGNMENT OF TICKET HERE
		
		
		//SEND EMAIL AFTER ASSIGNING OF TICKET
		// $this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'SAMPLE TICKET TITLE', $this->main_model->emailtemplate('PEREZ.JV', 'IM0123456', 'IM', 'SAMPLE TICKET TITLE', 'High', '07-22-16', 'OPEN', 'Sample Ticket Description'));
		
	// }
	
	function requestAccess(){
		$data['currentPage'] = "requestaccess";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("requestaccess");
		$this->load->view("template/footer");
		}
	
	function saveRequestAccess(){
		
		$shortname = strtolower($this->input->post('shortname'));
		$email = $this->input->post('email');
		$team = $this->input->post('team');

		
		if($this->getPGDetails($shortname) == TRUE)
			echo "valid pgshortname. ";
		else{
			$this->session->set_flashdata('errorshortname','Invalid P&G shortname');
             redirect('main/requestAccess');
		}
		
		if($this->validateWorkgroup($team) == TRUE)
			echo "valid workgroup";
		else{
			$this->session->set_flashdata('errorworkgroup','Invalid Workgroup');
             redirect('main/requestAccess');
		}
		//LOAD THE REQUEST ACCESS/REGISTRATION VIEW HERE
		echo "request access page";
		
		//AFTER VALIDATION SEND EMAIL TO Automated Ticket Dispatcher <acoe-atd@hpe.com> 
		// $this->main_model->Send_Mail('acoe-atd@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
		$this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
	}
	
	function userSetup(){
		$data['currentPage'] = "home";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("setup");
		$this->load->view("template/footer");
		
	}
	
	function saveUserSetup(){
		
		/*
		*Creation of atleast 1 specialist
		
		$newshortname = $this->input->post('shortname');		//shortname of newly added specialist
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');  //dm can only add specialist under his/her own team only
		$region = $this->input->post('region');
		$pgdetails = $this->getPGDetails('perez.jv');	// $pgdetails['email'] && $pgdetails['wholename']
		$row = $this->input->post('row');
		$type = "L1";
		$role = "";

		$this->main_model->addSpecialist($newshortname, $team, $region, $pgdetails['email'], $pgdetails['wholename'], $row, $type, $role);
		*/
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$timeout = $this->input->post('timeout');
		$titlesearch = $this->input->post('titlesearch');
		$regionsearch = $this->input->post('regionsearch');
		$noregionassignee = $this->input->post('noregionassignee');
		
		$this->main_model->updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee);
	}
	
	function validateWorkgroup($workgroup){
		$validate_url = FCPATH."\Macros\ValidateWorkgroup.iim";
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -tray", FALSE);
		$s = $iim1->iimSet("-var_workgroup","$workgroup");
		$s = $iim1->iimPlay($validate_url);
		$output = $iim1->iimGetLastExtract;
		$s = $iim1->iimClose();
		if(strpos($output, "Invalid Group Name") !== false)
			return FALSE;		//false if workgroup is invalid
		else if(strpos($output, "Make sure the web address http://smtracker.pg.com is correct.") !== false)
			echo "Failed to Validate. Check your VPN";
		else
			return 1;			//1 if workgroup is valid
	}
	
	function getPGDetails($shortname){
		$shortname = strtolower($shortname);
		$pgaccount = $this->pgldap_model->pgldap_search($shortname);
		
		if($shortname != $pgaccount['extshortname'][0])
			return FALSE;
		if(isset($pgaccount['extnotifyaddress'][0]))
			$data['email'] = $pgaccount['extnotifyaddress'][0];
		else
			$data['email'] = $pgaccount['mail'][0];
		$data['wholename'] = $pgaccount['cn'][0];
		$pgdetails = $data['email'].','.$data['wholename'];
		echo $pgdetails;
		return TRUE;
	}
	
	function donutIMFR(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$category = 'IM';
		$priority = ' 1 - Enterprise ';
		$donut = $this->main_model->getTicketCount($team, $category, $priority);
		var_dump($donut);
		
	}
	
	function donutROGUE(){
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
	}
	
	function calendar(){
		$team = $this->session->userdata('team');
		$data['currentPage'] = "calendar";	
		//for calendar
		$data['calendar'] = $this->fetchCalendar();
		$data['specialist'] = $this->main_model->getAllSpecialist($team);
		$this->load->view('template/header',$data);
		$this->load->view('calendar');
		$this->load->view('template/footer');
	}
	
	function settings(){
		$data['currentPage'] = "settings";
		$this->load->view('template/header',$data);
		$this->load->view('settings');
		$this->load->view('template/footer');
	}
	
	function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}
	
	function ticketlog(){
		$data['currentPage'] = "ticketlog";
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$data['allticket'] = $this->main_model->getAllTickets($team);
		$this->load->view("template/header", $data);
		$this->load->view("ticketlog", $data);
		$this->load->view("template/footer");
	}
	
	function openTickets($team){
		// $this->startAssign($team);
		$start = $this->main_model->setting("start", $team);
		
		//function for USORT
		function cmp($a, $b){
			return $a[2] - $b[2];
		}
		
		while($start == 1){
			 $workgroup = $this->main_model->getWorkgroup($team);
			 $stop = $this->main_model->setting("stop", $team);
			 
			 if($workgroup == FALSE){
				 echo "Team/Workgroup does not exist in the system.";
				 $this->stopAssign($team);
				 $this->checkStart($team);
				 return FALSE;			 
			 }
			 $workgroups = explode(",", $workgroup);		//workgroups should be separated by comma without space
			 
			 if(($stop == 0) && ($start == 1)){	//stop means pausing the current run; start == 0 terminating the run
				 
				 //copy this for FR Tickets
				 foreach($workgroups as $groups){
					$stop = $this->main_model->setting("stop", $team);
					$iimtickets = array();
					unset($iimtickets);
					$type = '';		//Rogue or not
					
					echo "<br/>Run Time: ".date('h:i:s A')."<br/>";
					echo 'currently running. . .<br/><br/>	';
					echo 'extracting IM tickets<br/>Please Wait. . .<br/><br/>	';
					
					$this->flush_buffers();
					$imtickets = $this->getOpenIM($groups);				//get IM Tickets
					
					// $imtickets = array(
							// array('IM', 'TITLE', 'PRIORITY', 'STATUS', 'TARGET DATE', 'SPECIALIST'),
							// array('IM012345', 'AR TEST TICKET DO NOT DELETE', ' 1 - Enterprise ', 'Open', '', ' N/A '),
							// array('IM012345', 'AS TEST TICKET DO NOT DELETE', ' 4 - User ', 'Open', '', ' N/A ')
					// );
					
					if($this->checkStart($team) == FALSE){
						exit();
					}
					// var_dump($imtickets);
					
					if($imtickets == FALSE){
						return FALSE;
					}
					
					usort($imtickets, "cmp");								//sort tickets to 1 - Enterprise > 4 - User
					
					$openIMoccurance = array_column($imtickets, 3);			//Open Occurance in smtracker
					$naIMoccurance = array_column($imtickets, 5);			//N/A Occurance in smtracker
					$numOpenIM = array_count_values($openIMoccurance);		
					$numNAIM = array_count_values($naIMoccurance);
					
					if(!isset($numOpenIM[' Misrouted ']))
						$numOpenIM[' Misrouted '] = 0;
					
					if(!isset($numNAIM[' N/A ']))
						$numNAIM[' N/A '] = 0;
					
					$totalOpen = $numNAIM[' N/A ']-$numOpenIM[' Misrouted '];
					echo '['.date('h:i:s A').'] Extracted a total of '.$totalOpen.'  Open IM ticket/s.<br/><br/>';
					
					if($totalOpen > 0){
						// $this->smLogin();
						$username = $this->session->userdata('shortname');
						$password = $this->main_model->getUserProfile($username, 'password');
						$iim1 = new COM("imacros");
						$s = $iim1->iimInit("-runner -kioskmode", true);
						$s = $iim1->iimSet("-var_username","$username");
						$s = $iim1->iimSet("-var_password","$password");
						$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGIN.iim");
					}
					$this->flush_buffers();
					
					for($a=1;$a<count($imtickets);$a++){
						$category = 'IM';
						$tnum = trim($imtickets[$a][0], " ");
						$title = ' '.$imtickets[$a][1];
						$rtitle = ' '.preg_replace('/[^A-Za-z0-9]/', ' ', $title);
						$priority = trim($imtickets[$a][2], " ");
						$status = trim($imtickets[$a][3], " ");
						$targetdate = $imtickets[$a][4];
						$specialist = trim($imtickets[$a][5], " ");
						$titlesearch = $this->main_model->getSettings($team, 'titlesearch');
						$regionsearch = $this->main_model->getSettings($team, 'regionsearch');
						$noregionassignee = $this->main_model->getSettings($team, 'noregionassignee');
						$rowapp = $this->getRowApp($team);
						$allregion = $this->main_model->getRegions($team);
						$regionPresent = 0;
						$keywordPresent = 0;
						$currentRegion = $this->getCurrentRegion($team);
						
						if($status == "Open" && $specialist == "N/A"){				//change this for team specs
							//Processing ticket should begin here
							$current_region = $this->RegionSelector($team);	//remove this if region tagging is turned off
							// $this->updateDM($team);
							$this->CheckDMAvailability($team);				//check if Duty Manager is available per Region
							
							//CHECK TITLE FOR REGION TAG
							$temp_regionpos = 200;
							$region = '';
							foreach($allregion as $allregions)
							{
								$regionlen = strlen($allregions['region']);
								$regionpos = stripos('  '.$rtitle, ' '.$allregions['region'].' ', 1);
								if($regionpos < $temp_regionpos && $regionpos != '')
								{
									$temp_regionpos = $regionpos;
									$region = $allregions['region'];
									$regionPresent = 1;
								}
							}
							//CHECK TITLE FOR KEYWORD TAGS
							$temp = '';
							$temp_rpos = 200; //title length
							$temp_rowapp = '%^&*(';
							foreach($rowapp as $rowapps)
							{
								$rlen = strlen($rowapps['rows']);
								$rpos = stripos($rtitle, ' '.$rowapps['rows'].' ', 1);
								if($rpos < $temp_rpos && $rpos != '')
								{
									$temp_rpos = $rpos;
									$temp_rowapp = $rowapps['rows'];
									$keywordPresent = 1;
								}
							}
							$rowapps = $temp_rowapp;	//change to keyword that's present in title
							$con = 0;
							if($titlesearch == 1){				//SEARCH TITLE FOR KEYWORD SETTING
								
								if($priority == '1 - Enterprise' && $keywordPresent == 1){
									$specialist = $this->minCriticalTicket($team, $rowapps);
									$con = 1;
								}
								else if($priority == '1 - Enterprise' && $keywordPresent == 0){
									$specialist = $this->getDM($team, $currentRegion);
									$con = 2;
								}
								else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 1 && $regionPresent == 1){
									$specialist = $this->minIMTicket($team, $rowapps, $region);
									$con = 3;
								}
								else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 1 && $regionPresent == 0 && $noregionassignee == 'dm'){
									$specialist = $this->getDM($team, $currentRegion);
									$con = 4;
								}
								else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 1 && $regionPresent == 0 && $noregionassignee == 'specialist'){
									$specialist = $this->minIMTicket($team, $rowapps);
									$con = 5;
								}
								else if($priority != '1 - Enterprise' && $keywordPresent == 1 && $regionsearch == 0){
									$specialist = $this->minIMTicket($team, $rowapps);
									$con = 6;
								}
								else if($priority != '1 - Enterprise' && $keywordPresent == 0 && $regionsearch == 1 && $regionPresent == 1){
									$specialist = $this->getDM($team, $region);
									$con = 7;
								}
								else if($priority != '1 - Enterprise' && $keywordPresent == 0 && $regionsearch == 1 && $regionPresent == 0){
									$specialist = $this->getDM($team, $currentRegion);
									$con = 8;
								}
								else{
									$specialist = $this->getDM($team, $currentRegion);
									$con = 9;

								}
								
						
							}
							else{
								if($priority == '1 - Enterprise'){
									$specialist = $this->minCriticalTicket($team, $rowapps);
								}
								else{
									$specialist = $this->minIMTicket($team, $rowapps);
								}
							}
							echo 'Titlesearch: '.$titlesearch.' Priority: '.$priority.'  keywordPresent: '.$keywordPresent.' regionsearch: '.$regionsearch.'  regionPresent: '.$regionPresent.' noregionassignee: '.$noregionassignee.'<br/>';
							echo $specialist.' '.$currentRegion.' '.$rowapps.'<br/>condition: '.$con.'<br/>';
							$this->flush_buffers();

							
						}
						
						if($this->checkStart($team) == FALSE){
							$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGOUT.iim");
							$s = $iim1->iimClose();
							exit();
						}
					}
					
					
					
				 }
				 // $this->smLogOut();
				 $s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGOUT.iim");
				 $s = $iim1->iimClose();
				 $timeout = $this->main_model->setting("timeout", $team);
				 $start = $this->main_model->setting("start", $team);
				 for($a=0;$a<$timeout;$a++)
					sleep(1);
				 
			 }
			 else{
				 if($start == 1)
				 sleep(1);
			 }
		}
	 }
	 
	 function getOpenIM($team){

		$ticketdetails = array();
		unset($ticketdetails);
					
		$extract_url = FCPATH."\Macros\ExtractTIckets.iim";
		
		ob_start(); ?>
		
		VERSION BUILD=10022823
		SET EXTRACT_TEST_POPUP NO
		SET !TIMEOUT_PAGE 120
		TAB T=1
		TAB CLOSEALLOTHERS
		TAB OPEN
		TAB T=2
		'extract Incident Ticket
		URL GOTO=http://smtracker.pg.com/pls/smtracker/pg_tracker.inc_groups?i_group=G.AACOE
		TAG POS=1 TYPE=TABLE ATTR=* EXTRACT=TXT
		TAB T=1
		TAB CLOSEALLOTHERS
		
		
		<?php
		$extractticket = ob_get_clean();
		
		
		
		$iimextractTicket = "
		VERSION BUILD=10022823
		SET EXTRACT_TEST_POPUP NO
		TAB T=1
		TAB CLOSEALLOTHERS
		TAB OPEN
		TAB T=2
		'extract Incident Ticket
		URL GOTO=http://smtracker.pg.com/pls/smtracker/pg_tracker.inc_groups?i_group=".$team."
		TAG POS=1 TYPE=TABLE ATTR=* EXTRACT=TXT
		TAB T=1
		TAB CLOSEALLOTHERS";
		
		$iim1 = new COM("imacros");
		$s = $iim1->iimOpen("-runner -kioskmode -tray", TRUE);
		$s = $iim1->iimSet("workgroup","$team");
		$s = $iim1->iimPlay($extract_url);
		// $s = $iim1->iimPlayCode($extractticket);
		
		if($s > 0){
		$tickets = $iim1->iimGetLastExtract();
		$s = $iim1->iimClose();
		$tickets = str_replace('[EXTRACT]', '', $tickets);
		$ticket = explode("#NEWLINE#", $tickets);
		
		foreach($ticket as $key => $ticks){
			$tdetails = explode("#NEXT#", $ticks);
			$ticketdetails[$key] = $tdetails;
		}
		return $ticketdetails;
		
		}
		else{
			echo $iim1->iimGetLastError;
			echo '<br/>Failed to Extract Ticket';
			return FALSE;
		}
	 }
	 
	 function stopAssign($team){					//change value of Stop from DB
		 $this->main_model->stopAssign($team);
	 }
	 
	 function startAssign($team){					//change value of Start from DB
		 $this->main_model->startAssign($team);
	 }
	 
	 function assignTicket($tnum, $specialist, $priority, $type, $row, $titlesearch, $category){
		 

		 $ticketnum = $tnum;
		 $status = 'Accepted';
		 $assigned = $specialist;
		 $update = "Assigned to ".$specialist.". [AUTO-DM]";
		 
		$iimassignTicket = "
		VERSION BUILD=9002379
		SET !EXTRACT_TEST_POPUP NO
		TAB T=1
		TAB CLOSEALLOTHERS
		WAIT SECONDS=2
		TAG POS=1 TYPE=SPAN ATTR=TXT:Search<SP>Incidents
		FRAME F=3
		WAIT SECONDS=10
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/number CONTENT=".$ticketnum."
		FRAME F=0
		TAG POS=1 TYPE=BUTTON ATTR=TXT:search
		WAIT SECONDS=5
		FRAME F=3
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/problem.status CONTENT=".$status."
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/assignee.name CONTENT=".$assigned."
		TAG POS=1 TYPE=A FORM=NAME:topaz ATTR=TXT:Update
		TAG POS=1 TYPE=TEXTAREA FORM=NAME:topaz ATTR=NAME:var/pmc.actions/pmc.actions CONTENT=".$update."
		WAIT SECONDS=5
		FRAME F=0
		TAG POS=1 TYPE=BUTTON ATTR=TXT:save<SP>&<SP>Exit
		WAIT SECONDS=2
		FRAME F=3
		TAG POS=1 TYPE=DIV ATTR=CLASS:messageTrayElement<SP>infoMsg EXTRACT=TXT
		FRAME F=0
		TAG POS=2 TYPE=BUTTON ATTR=TXT:Cancel
		WAIT SECONDS=2";
		 
		 if ($category == "IM")
		{
			$iim1 = new COM("imacros");
			// $s = $iim1->iimOpen("-runner", FALSE);
			$s = $iim1->iimOpen('-cr -runner -crUserDataDir "C:\Users\perjohnv\AppData\Local\Google\Chrome\User Data\G.AACOE"', FALSE);
			$s = $iim1->iimPlayCode($iimassignTicket);
			// $s = $iim1->iimSet("-var_ticketnum","$ticketnum");
			// $s = $iim1->iimSet("-var_status","$status");
			// $s = $iim1->iimSet("-var_assignee","$assigned");
			// $s = $iim1->iimSet("-var_update","$update");
			// $s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\assign ticket.iim");
		}
		else if ($category == "FR")
		{
			$iim1 = new COM("imacros");
			$s = $iim1->iimOpen("-runner", FALSE);
			$s = $iim1->iimSet("-var_status","$status");
			$s = $iim1->iimSet("-var_assignee","$assigned");
			$s = $iim1->iimSet("-var_update","$update");
			$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\assign fr ticket.iim");
		}
		 
		 
	 }
	 
	 
	 
	 
	 
	 function flush_buffers(){ 
		ob_end_flush(); 
		flush(); 
		ob_start(); 
	}
	
	
	function RegionSelector($team){
		$current_region = $this->main_model->RegionSelector($team);
		return $current_region;
	}
	
	function CheckDMAvailability($team){
		$allregions = $this->main_model->getRegions($team);
		if($allregions == FALSE){
			echo 'Set atleast 1 Region for your Workgroup.';
			exit;
		}
		foreach($allregions as $region){
			$assigned = $this->main_model->CheckDMAvailability($team, $region['region']);
			if($assigned == FALSE){
				echo 'Set atleast one available Duty Manager to '.$region['region'].'.<br/>';
				echo 'SWITCHBOARD STOPPED AT EXACTLY '.date('h:i:sA');
				exit;
			}
		}
	}
	
	function getRowApp($team){
		if($this->main_model->getRowApp($team) == FALSE){
			echo "Set atleast 1 keyword in the Settings.";
			exit;
		}
		return $this->main_model->getRowApp($team);
	}
	
	function getKeyword(){
		$team = $this->session->userdata('team');
		$keywords = $this->main_model->getRowApp($team);
		$keyword = '';
		foreach($keywords as $key => $value){
			$keyword = $keyword.','.$keywords[$key]['rows'];
		}
		echo $keyword;
	}
	
	function minCriticalTicket($team, $rowapp){
		return $this->main_model->minCriticalTicket($team, $rowapp);
		
	}
	
	function minIMTicket($team, $rowapp, $region){
		return $this->main_model->minIMTicket($team, $rowapp, $region);
		
	}
	
	function minFRTicket($team, $rowapp){
		return $this->main_model->minFRTicket($team, $rowapp);
		
	}
	
	function minRogueTicket($team, $rowapp){
		return $this->main_model->minRogueTicket($team, $rowapp);
		
	}
	
	function checkStart($team){
		$start = $this->main_model->setting("start", $team);
		if($start == 0){
			echo '<b>STOPPED AT EXACTLY '.date('h:i:sA').'.</b>';
		return FALSE;
		}
		return TRUE;
	}
	
	function sortdm($team){
		function cmp($a, $b){
			return $a['role'] - $b['role'];
		}
		
		$dms = $this->main_model->getDM($team);
		usort($dms, "cmp");
		var_dump($dms);
	}
	
	function getCalendarShift($team, $status){
		$dmshift = $this->main_model->getCalendar($team, $status);
		var_dump($dmshift);
	}
	
	function updateDM($team){
		$this->main_model->updateDM($team);
	}
	
	function smLogin(){
		$username = $this->session->userdata('shortname');
		$password = $this->main_model->getUserProfile($username, 'password');
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -kioskmode", true);
		$s = $iim1->iimSet("-var_username","$username");
		$s = $iim1->iimSet("-var_password","$password");
		$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGIN.iim");
	}
	
	function smLogOut(){
		$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGOUT.iim");
		$s = $iim1->iimClose();
	}
	
	function getDM($team, $region){
		$dms = $this->main_model->getDM($team, $region);
		return $dms[0]['shortname'];
	}
	
	function getCurrentRegion($team){
		$regions = $this->main_model->getRegions($team);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$currentRegion = '';
		foreach($regions as $region){
			if($region['start'] <= $date && $region['end'] >= $date){
				$currentRegion = $region['region'];
			}
		}
		return $currentRegion;
	}
	
	function updateCalendar(){
		$team = $this->session->userdata('team');
		// $shortname = $this->session->userdata('shortname');
		$type = $_POST['type'];

		if($type == 'new')
		{
			$status = $_POST['status'];
			$type = $_POST['ctype'];
			$shortname = $_POST['title'];
			$startdate = $_POST['startdate'];
			$startdate = strtotime($startdate);
			$startdate = date('Y-m-d', $startdate);
			$enddate = $startdate;
			$eventid = $_POST['eventid'];
			
			//ADD 1 Day to enddate
			// $enddate = strtotime($enddate);
			// $enddate = strtotime('+1 day', $enddate);
			// $enddate = date('Y-m-d H:i:s', $enddate);
			$shortname = $_POST['title'];
			$eventdetails = $this->main_model->newCalendar($shortname, $startdate, $enddate, $status, $type, $eventid);
			$eventid = $eventdetails['eventid'];
			echo json_encode($eventdetails);
		}

		if($type == 'changetitle')
		{
			$eventid = $_POST['eventid'];
			$status = $_POST['status'];
			$type = $_POST['ctype'];
			$this->main_model->changeStatusCalendar($status, $type, $eventid);
		}

		if($type == 'resetdate')
		{
			// $shortname = $_POST['title'];
			$startdate = $_POST['start'];
			$enddate = $_POST['end'];
			$eventid = $_POST['eventid'];
			$this->main_model->resetDateCalendar($startdate, $enddate, $eventid);
		}

		if($type == 'remove')
		{
			$eventid = $_POST['eventid'];
			$this->main_model->deleteCalendar($eventid);
		}

		if($type == 'fetch')
		{
			$events = array();
			$events = $this->main_model->fetchCalendar($team);
			foreach($events as $key => $value){
				if($events[$key]['status'] == 'DM'){
					$e = array("className" => 'label-dm');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Sick Leave'){
					$e = array("className" => 'label-danger');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Vacation Leave'){
					$e = array("className" => 'label-primary');
					$events[$key] = array_merge($events[$key], $e);
				}
				else{
					$e = array("className" => 'label-default');
					$events[$key] = array_merge($events[$key], $e);
				}
			}
			// $query = mysqli_query($con, "SELECT * FROM calendar");
			// while($fetch = mysqli_fetch_array($query,MYSQLI_ASSOC))
			// {
			// $e = array();
			// $e['id'] = $fetch['id'];
			// $e['title'] = $fetch['title'];
			// $e['start'] = $fetch['startdate'];
			// $e['end'] = $fetch['enddate'];

			// $allday = ($fetch['allDay'] == "true") ? true : false;
			// $e['allDay'] = $allday;

			// array_push($events, $e);
			// }
			$type = $_POST['type'];
			if($type != 'fetch' && $type != 'remove'){
				$type = $_POST['ctype'];	
				if($status == 'DM'){
					$dm = $this->main_model->getCalendar($team, $eventid);

					if($dm[0]['sdate'] <= date("Y-m-d") && $dm[0]['edate'] >= date("Y-m-d")){
						$data = array(
							'shortname' => $dm[0]['shortname'],
							'role' => '1'
							// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
						);
						$this->db->select('shortname');
						$this->db->from('specialist');
						$this->db->where('id', $eventid);
						$this->db->update('specialist', $data);
					}
				}
			}
			echo json_encode($events);
		}
		
		
		
		
	}

	
	function changeStatusCalendar($status, $id){
		$this->main_model->changeStatusCalendar($status, $id);
	}
	
	function deleteCalendar($id){
		$this->main_model->deleteCalendar($id);
	}
	
	function fetchCalendar(){
		$team = $this->session->userdata('team');
		$schedule = $this->main_model->fetchCalendar($team);
		foreach($schedule as $key => $value){
			if($schedule[$key]['title'] == 'DM'){
				$e = array("backgroundColor" => '#cccccc');
				$schedule[$key] = array_merge($schedule[$key], $e);
			}
		}
		
		return json_encode($schedule);
	}
	
	function updateAllSettings(){
		$team = $this->session->userdata('team');
		$settings = $_POST['setting'];
		
		if($settings == 'getsetting'){
			$allsettings = $this->main_model->getSettings($team, 'allsettings');
			$timeout = $allsettings[0]['timeout'];
			$titlesearch = ($allsettings[0]['titlesearch'] == '1') ? 'true' : 'false';
			$regionsearch = ($allsettings[0]['regionsearch'] == '1') ? 'true' : 'false';
			$noregionassignee = $allsettings[0]['noregionassignee'];
			$allsettings = $timeout.','.$titlesearch.','.$regionsearch.','.$noregionassignee;
			echo $allsettings;
		}
		
		if($settings == 'getworkgroup'){
			echo $this->main_model->getWorkgroup($team);
		}
		
		if($settings == 'getkeyword'){
			$keywords = $this->main_model->getRowApp($team);
			foreach($keywords as $keyword){
				echo $keyword['rows'].',';
			}
		}
			if($settings == ''){
				$timeout = $_POST['timeout'];
				$titlesearch = $_POST['titlesearch'];
				$regionsearch = $_POST['regionsearch'];
				$noregionassignee = $_POST['noregionassignee'];
				$workgroups = $_POST['workgroups'];
				$workgroups = strtoupper($workgroups);
				$keywords = $_POST['keywords'];
				$keywords = strtoupper($keywords);
				$keywords = explode(",", $keywords);
				
				if($this->main_model->updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE..';
				}
				
				if($this->main_model->updateWorkgroup($team, $workgroups) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE..';
				}
				

				if($this->main_model->insertRowApp($team, $keywords) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE KEYWORDS..';
				}
				echo $message;
			}
		
		
	}
	
	function updateRegion(){
		$team = $this->session->userdata('team');
		$type = $_POST['type'];
		
		if($type == 'new'){
			$region = $_POST['region'];
			$start = $_POST['start'];
			$end = $_POST['end'];

			if(strtotime($start) > strtotime($end)){
				$start = '1000-01-01 '.$start;
				$end = '1000-01-02 '.$end;
			}
			else{
				$start = '1000-01-02 '.$start;
				$end = '1000-01-02 '.$end;
			}
			$this->main_model->addRegion($team, $region, $start, $end);	
			echo 'Successfully Added';
		}
		
		if($type == 'fetch'){
			$regions = $this->main_model->getRegions($team);	
			foreach($regions as $key => $value){
				$allregion[$key] = $regions[$key]['region'].','.$regions[$key]['start'].','.$regions[$key]['end'];
			}
			$allregions = '';
			foreach($allregion as $region){
				$allregions = $allregions.$region.'*';
			}
			echo $allregions;
		}
		
		
	}
	
	function updateSpecialist(){
		$team = $this->session->userdata('team');
		$shortname = strtoupper($_POST['shortname']);
		$region = $_POST['shift'];
		$keywords = $_POST['keywordnew'];
		$wholename = $_POST['wholename'];
		$email = $_POST['email'];
		$type = $_POST['type'];
		
		$rowapp = '';
		if($keywords != ''){
			$keywords = explode(',', $keywords);
			foreach($keywords as $key => $values){
				if($keywords[$key] != '')
					$rowapp = $rowapp.'['.$keywords[$key].']';
			}			
		}
		
		$this->main_model->updateSpecialist($team, $shortname, $wholename, $email, $region, $rowapp, '', '', $type);
		
	}
	
	function getSettings($team, $column){
		print_r($this->main_model->getSettings($team, $column));
	}
	
	function getMyTeam(){
		$team = $this->session->userdata('team');
		$myteam = $this->main_model->getMyTeam($team);
		foreach($myteam as $key => $value){
			$e = array("edit" => '<input type="button" class="btn label-dm center" id="updateSpecialist" onclick="updateSpecialist(&#39;'.$myteam[$key]["shortname"].'&#39;);" value="EDIT" />');
			$myteam[$key] = array_merge($myteam[$key], $e);
		}
		echo json_encode($myteam);
	}
	
	function getTicketlog(){
		$shortname = $this->session->userdata('shortname');
		$ticketlog = $this->main_model->getTickets($shortname);
		echo json_encode($ticketlog);
	}
	
	function addSpecialist($team, $shortname, $wholename, $email, $region, $keyword){
		$this->main_model->updateSpecialist($team, $shortname, $wholename, $email, $region, $keyword, '', '', '');
	}
	
	function getRegions(){
		$team = $this->session->userdata('team');
		$regions = $this->main_model->getRegions($team);
		$data = '';
		foreach($regions as $key => $value){
			$data = $data.','.$regions[$key]['region'];
		}
		echo $data;
	}
	
	function getSpecialist($shortname){
		
		$specialist = $this->main_model->getSpecialist($shortname);
		echo $specialist[0]['region'].'*'.$specialist[0]['row'];
	}
	
	function deleteShift(){
		$shift = $_POST['shift'];
		$team = $this->session->userdata('team');
		$this->main_model->deleteShift($shift, $team);
		echo 'Successfully Deleted.';
	}

	function sendmail(){
		$this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'sample', 'sample');
	}
	
}
