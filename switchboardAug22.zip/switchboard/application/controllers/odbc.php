<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class odbc extends CI_Controller {

	/**
	 *	ODBC
	 *	Author: adrian-lester.tan@hpe.com
	 *	
	 *	I acknowledge that there are  numerous ODBC sample codes already in the net. I am putting how I managed to make it work. I would usually use ODBC when connecting to MS SQL and recently, HP Vertica.
	 *	
	 **/
	 public function __construct(){
			parent::__construct();
			
	 }
	
	/*
	*	Open Database Connectivity (ODBC) is a standard API for accessing various DBMS
		given the correct DB driver installed. 
		
		In Windows, you install drivers and they should be available to be added in your local
		ODBC.
		
		Control Panel > Administrative Tools > Data Source (ODBC)
		
		Take note that in the ODBC window, there are User DSN and System DNS.
		Always make sure to have one for user and system DNS when on a shared environment / server. 
		
		User DNS - used by ODBC to refer the drivername when a session is active.
		System DNS - used by ODBC to refer the drivername when there are no sessions.
		
	*	Drivername: this is the drivername you have dictated in your local ODBC when creating
	*	the connectivity.
	*	
	*	As a rule of thumb, if the test connection works upon ODBC creation, these should work. 
	*/
	function getConnection(){
		return odbc_connect(<drivername>,<username>,<password>); 
	}
	
	function home(){
		
	
		$conn = $this->getConnection();
		
		if (!$conn){
			exit("Connection Failed: " . $conn);
		} 
		
		$sql = "select * from <schema>.<tablename> limit 10;";
		$rs=odbc_exec($conn,$sql); 
		if (!$rs){
			exit("Error in SQL");
		}
		
		$resultArray = array();
		while($arr = odbc_fetch_array($rs)){
			$resultArray[] = $arr;
		}
		odbc_close($conn); 
		
		print_r($resultArray);

		
	}
	
}
