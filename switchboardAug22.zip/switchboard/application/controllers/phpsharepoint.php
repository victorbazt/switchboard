<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class phpsharepoint extends CI_Controller {

	/**
	 *	Integrating with Sharepoint. I used PHPSharepoint library by thybag. 
	 *	
	 *	For complete documentation, refer to:
	*	https://github.com/thybag/PHP-SharePoint-Lists-API
	 **/
	 public function __construct(){
			parent::__construct();
			ini_set ( 'max_execution_time', 300); 
	 }
	 
	 function readlist(){
		include $_SERVER["DOCUMENT_ROOT"]."/sphooks/lib/php_sharepoint/SharePointAPI.php";
		
		/*
		*	The wsdl path is the XML description of the site. Construct like this:
		*	<sharepoint url>/sitecollection/_vti_bin/Lists.asmx?WSDL
		*	The username and password must have the necessary access in the Sharepoint site for the WSDL to load in the first place.
		*/
		$wsdl = 'https://ent301.sharepoint.hpe.com/teams/automationcoe/_vti_bin/Lists.asmx?WSDL';
		$sp = new \Thybag\SharePointAPI('<email>','<password>',$wsdl, 'NTLM');
	
		//Sharepoint object GUIDs can be obtained in the URL when you go over List/Library Settings
		
		$listGUID = "{EAC3ED07-DA4C-4E62-A24D-7D549227AFE1}";
		
		//Reads the first 10 rows in the LIST with the given GUID
		print_r($sp->read($listGUID, 10)); 
		
	}
	
	
}
