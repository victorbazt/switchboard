<div class="container">
	
	<div class="tables">
		<div class="bs-example widget-shadow row autopad" data-example-id="hoverable-table"> 
			
			<table id="example" class="table table-striped myTable text-left"> <thead> <tr> <th>TICKET </th> <th>TITLE</th> <th>ASSIGNED TO</th>  <th>PRIORITY</th>  <th>TYPE</th>  <th>DATE ASSIGNED</th> </tr> </thead> 
				<tbody>
			<?php
			if(is_array($allticket))foreach($allticket as $key => $value){
				echo '<tr> 
							<td>'.$allticket[$key]['tnum'].'</td>
							<td>'.$allticket[$key]['title'].'</td>
							<td>'.$allticket[$key]['specialist'].'</td>
							<td>'.$allticket[$key]['priority'].'</td>
							<td>'.$allticket[$key]['type'].'</td>
							<td>'.$allticket[$key]['date'].'</td>';
				echo '</tr>';
			}
			
			?>
			</tbody>
			</table>
				
		</div>
	
	</div>
						
</div>		
	
		<script>
		$(document).ready(function(){
			$('.myTable').DataTable({
				"aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
				"iDisplayLength": 15
			});
		});
		</script>