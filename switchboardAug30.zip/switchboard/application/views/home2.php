

<div class="container">
	<div class="row">		
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
			<div class="panel">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/activity.png"/>Ticket Dispatcher Activity</div></div>
				<div class="panel-body">
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
						<img class="img-responsive" id="robot" src="<?php echo base_url();?>assets/images/icons/robotPending.png"/>

						<a href="#" onclick="
							
							if(document.getElementById('playStop').src == '<?php echo base_url();?>assets/images/icons/play.png')
							{
								document.getElementById('ifr').src='<?php echo base_url();?>index.php/smtracker/openTickets/G.AACOE/<?php echo $this->session->userdata('shortname'); ?>';
								document.getElementById('robot').src='<?php echo base_url();?>assets/images/icons/robotRunning.gif'; 
								document.getElementById('playStop').src='<?php echo base_url();?>assets/images/icons/stop.png';
								
							}
							
							else
							{
								document.getElementById('robot').src='<?php echo base_url();?>assets/images/icons/robotPending.png'; 
								document.getElementById('playStop').src='<?php echo base_url();?>assets/images/icons/play.png';
							}
							
						">
							<img id="playStop" class="icons" src="<?php echo base_url();?>assets/images/icons/play.png"/>
						</a>

					</div>
					<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
						<iframe id="stop" width="1px" height='1px' frameborder="0" scrolling="no" src="<?php echo base_url();?>blank.php"></iframe>
							<iframe id="ifr" width="100%" height="210px" frameborder="0" src="<?php echo base_url();?>blank.php"></iframe>
					</div>
				</div>
			</div>
		</div>

		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
			<div class="panel">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/statistics.png"/>Ticket Dispatcher Statistics</div></div>
				<div class="panel-body">
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
						<div id="totalDispatchedIMTickets"></div>
						<h4>TOTAL IM TICKETS DISPATCHED</h4>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
						<div id="totalDispatchedFRTickets"></div>
						<h4>TOTAL FR TICKETS DISPATCHED</h4>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
						<div id="rogueTickets"></div>
						<h4>IM/FR ROGUE TICKETS DISPATCHED</h4>
					</div>
				</div>
			</div>
		</div>

		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
			<div class="panel">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/heatmap.png"/>Workload Treemap</div></div>
				
				<div id="treemap"></div>
				
			</div>
		</div>


		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<div class="panel half">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/dm.png"/>DM of the Day</div></div>
				<div class="overflow">
				<table class="table table-ooo">					
					<?php 
					foreach($regions as $region){
						$temp = 0;
						echo '<thead><tr><th>'.$region['region'].'</th></tr></thead>';
						echo '<tbody>';
						foreach($dmoftheday as $dm){
							if($dm['region'] == $region['region']){
								echo '<tr><td align="left">'.$dm['wholename'].'</td></tr>';							
								$temp = 1;
							}
						}
						if($temp == 0)
							echo '<tr><td align="left">NO DM ASSIGNED TO THIS REGION</td></tr>';
						echo '</tbody>';
					}
					?>
				</table>
				</div>
			</div>
		</div>

		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<div class="panel half">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/OOOResources.png"/>OOO Resources</div></div>
				<div class="overflow">
				<table class="table table-ooo">
					<?php
					for($a=0;$a<5;$a++){
						$temp = 0;
						$datetoday = date('M d, Y', strtotime(date('M d, Y'). ' + '.$a.' days'));
						$timestamptoday = date('Y-m-d h:i:s', strtotime(date('Y-m-d h:i:s'). ' + '.$a.' days'));
						echo '<thead><tr><th colspan="2">'.$datetoday.'</th></tr></thead>';
						echo '<tbody>';
						if(is_array($ooospecialist))foreach($ooospecialist as $specialist){
							if($specialist['cstatus'] == 'SL' && $specialist['edate'] > $timestamptoday && $specialist['sdate'] < $timestamptoday){
								echo '<tr><td align="left">'.$specialist['wholename'].'</td><td><span class="label label-danger">'.$specialist['cstatus'].'</span></td></tr>';
								$temp = 1;
								
							}
							else if($specialist['cstatus'] == 'VL' && $specialist['edate'] > $timestamptoday && $specialist['sdate'] < $timestamptoday){
								echo '<tr><td align="left">'.$specialist['wholename'].'</td><td><span class="label label-primary">'.$specialist['cstatus'].'</span></td></tr>';
								$temp = 1;
								
							}
						}
						else{
							echo '<tr><td align="left">NO OOO RESOURCE</td></tr>';
							
						}
						if($temp == 0){
							echo '<tr><td align="left">NO OOO RESOURCE</td></tr>';
							
						}
						echo '</tbody>';
					}
					?>
				</table>
				</div>
					
				
			</div>
		</div>

	</div>
</div>


<script>
$(function () {
	
    $('#treemap').highcharts({
        colorAxis: {
            minColor: '#FFFFFF',
            maxColor: '#f04953'
        },
        series: [{
            type: 'treemap',
            layoutAlgorithm: 'squarified',
            data: [
			<?php
			foreach($ticketcountspe as $spe => $values)
			echo "{ name: '".$ticketcountspe[$spe]['specialist']."', value: ".$ticketcountspe[$spe]['tkt_count'].", colorValue: ".$ticketcountspe[$spe]['tkt_count']." },";
			?>
			]
        }],
        title: {
            text: ''
        }, 
		subtitle: {
            text: ''
        },
		credits: {
		    enabled: false
	    },
		chart: {
			backgroundColor: null
		}
    });

    //Pie charts!//
    /*

     $.getJSON(spoolsJSON, function(data) {
              // Populate series
             
              for (i = 0; i < 3; i++)
              {
                  arrayNaLalagyanMo.push([data[i].extractTime, data[i].spoolC]);
              }
*/
	//spoolChart = new Highcharts.Chart({
	$('#totalDispatchedIMTickets').highcharts({

        chart: {
        	marginTop: 20,
            type: 'pie',
            plotBorderWidth: 0,
            backgroundColor:null,
            height:180,
            // renderTo: 'totalDispatchedTickets',
        },

		title: {
            text: '<?php echo $imlow[0]['total']+$imaverage[0]['total']+$imhigh[0]['total']+$imcritical[0]['total']; ?>',
            
            style: {
            	color:'#cccccc',
            	fontSize:'20px'
        	},
        	verticalAlign:'middle'
     	},

		subtitle: {
		  text: '',
		  style: {
		      display: 'none'
		  }
		},

		credits:{
          enabled:false
        },

       
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            dataLabels: {
	                enabled: false
	            },
	            showInLegend: false,
	            innerSize:'80%',
	            borderWidth: 0
	        }
	    },

       series: [{
		   name: 'Ticket Count',
            data: [
                {name:'Critical', y:<?php if(isset($imcritical[0]['total']))
										   echo $imcritical[0]['total']; 
										  else
											echo '0';
									   ?>, color:'#f04953'},
                {name:'High', y:<?php if(isset($imhigh[0]['total']))
										   echo $imhigh[0]['total']; 
									  else
										   echo '0';
									   ?>, color:'#F09144'},
                {name:'Average', y:<?php if(isset($imaverage[0]['total'])) 
											echo $imaverage[0]['total']; 
										 else
											echo '0';
										?>, color:'#FFd144'},
                {name:'Low', y:<?php if(isset($imlow[0]['total'])) 
										echo $imlow[0]['total'];
									 else
										echo '0';
									?>, color:'#2AD2C9'}
    	]}]
    });


    /*
    });
    //calls the updater of json accoring to interval
    setInterval(function() { getSpoolData();}, spools_update_interval);
      
     function getSpoolData(){
                 
         var url = spoolsJSON;

         $.getJSON (url, function (jsonFromServer){
            spoolArray.length=0;
            for (i = 0; i < 3; i++){
                spoolArray.push([jsonFromServer[i].extractTime, jsonFromServer[i].spoolC]);

            }
            spoolArray.reverse();

             spoolChart.series[0].setData(spoolArray,true);
             console.log("refresh you");
         });
     }
     */

    $('#totalDispatchedFRTickets').highcharts({

        chart: {
        	marginTop: 20,
            type: 'pie',
            plotBorderWidth: 0,
            backgroundColor:null,
            height:180,
            // renderTo: 'totalDispatchedTickets',
        },

		title: {
            text: '<?php echo $frlow[0]['total']+$fraverage[0]['total']+$frhigh[0]['total']+$frcritical[0]['total']; ?>',
            
            style: {
            	color:'#cccccc',
            	fontSize:'20px'
        	},
        	verticalAlign:'middle'
     	},

		subtitle: {
		  text: '',
		  style: {
		      display: 'none'
		  }
		},

		credits:{
          enabled:false
        },

       
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            dataLabels: {
	                enabled: false
	            },
	            showInLegend: false,
	            innerSize:'80%',
	            borderWidth: 0
	        }
	    },

       series: [{
			name: 'Ticket Count',
            data: [
                {name:'Critical', y:<?php if(isset($frcritical[0]['total']))
										   echo $frcritical[0]['total']; 
										  else
											echo '0';
									   ?>, color:'#f04953'},
                {name:'High', y:<?php if(isset($frhigh[0]['total']))
										   echo $frhigh[0]['total']; 
									  else
										   echo '0';
									   ?>, color:'#F09144'},
                {name:'Average', y:<?php if(isset($fraverage[0]['total'])) 
											echo $fraverage[0]['total']; 
										 else
											echo '0';
										?>, color:'#FFd144'},
                {name:'Low', y:<?php if(isset($frlow[0]['total'])) 
										echo $frlow[0]['total'];
									 else
										echo '0';
									?>, color:'#2AD2C9'}
    	]}],
		
    });
	
	$('#rogueTickets').highcharts({

        chart: {
        	marginTop: 20,
            type: 'pie',
            plotBorderWidth: 0,
            backgroundColor:null,
            height:180,
            // renderTo: 'totalDispatchedTickets',
        },

		title: {
            text: '<?php echo $imlow[0]['total']+$imaverage[0]['total']+$imhigh[0]['total']+$imcritical[0]['total']+$frlow[0]['total']+$fraverage[0]['total']+$frhigh[0]['total']+$frcritical[0]['total']; ?>',
            
            style: {
            	color:'#cccccc',
            	fontSize:'20px'
        	},
        	verticalAlign:'middle'
     	},

		subtitle: {
		  text: '',
		  style: {
		      display: 'none'
		  }
		},

		credits:{
          enabled:false
        },

       
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            dataLabels: {
	                enabled: false
	            },
	            showInLegend: false,
	            innerSize:'80%',
	            borderWidth: 0
	        }
	    },

       series: [{
		   name: 'Ticket Count',
            data: [
                {name:'IM', y:<?php echo $imlow[0]['total']+$imaverage[0]['total']+$imhigh[0]['total']+$imcritical[0]['total']; ?>, color:'#94ABA8'},
                {name:'FR', y:<?php echo $frlow[0]['total']+$fraverage[0]['total']+$frhigh[0]['total']+$frcritical[0]['total']; ?>, color:'#8c6694'}
    	]}]
    });
    //End Pie Charts

});
</script>
<script>
$(document).ready(function() {
                $("#playStop").click(function(event) {
                    event.preventDefault();
                    var user_name = $("input#name").val();
                    var password = $("input#pwd").val();
                    jQuery.ajax({
                        type: "POST",
                        url: (document.getElementById('playStop').src == '<?php echo base_url();?>assets/images/icons/play.png') ? "<?php echo base_url(); ?>index.php/smtracker/startAssign/G.AACOE" : "<?php echo base_url(); ?>index.php/smtracker/stopAssign/G.AACOE",
                        dataType: 'json',
                        data: {name: user_name, pwd: password},
                        success: function(res) {
                            if (res)
                            {
                                // Show Entered Value
                                jQuery("div#test").show();
                                jQuery("div#value").html(res.username);
                                jQuery("div#value_pwd").html(res.pwd);
                            }
                        }
                    });
                });
				$('iframe').load( function() {
					$('iframe').contents().find("head")
					  .append($("<style type='text/css'>  body { font-family: lucida console; color: #aca89a; font-size: 11px;	 overflow-x: hidden !important; }  </style>"));
				});
            });
</script>

