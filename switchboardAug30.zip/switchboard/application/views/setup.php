

<div class="container">
	<div class="jumbotron">
		<form action="<?php echo base_url();?>index.php/main/saveUserSetup" autocomplete="off" method="post">
		<div class="spacer text-center">
			<img class="robot" src="<?php echo base_url();?>assets/images/icons/robot.png"/>FIRST TIME USER SETUP
		</div>
		<div class="row"></div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>Dispatcher Refresh Interval</p>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
				<input type="number" name="timeout" class="form-control" value="10" step="5" />
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<fieldset>
				  <label for="exampleSelect1" class="setup-label pull-left">Search Ticket Title for Keywords</label>
				  <input type="checkbox" name="ticketTitle" id="titlesearch" class="form-control pull-right ts" checked="true" data-size="mini">
			  </fieldset>
			</div>
			<!--
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<div class="onoffswitch">
					<input type="checkbox" name="titlesearch" class="onoffswitch-checkbox" id="titlesearch" checked>
					<label class="onoffswitch-label" for="titlesearch">
						<span class="onoffswitch-inner"></span>
						<span class="onoffswitch-switch"></span>
					</label>
				</div>
			</div>
			-->
		</div>
		<!--
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>Assign based on Region</p>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<div class="onoffswitch">
					<input type="checkbox" name="regionsearch" class="onoffswitch-checkbox" id="regionsearch" checked>
					<label class="onoffswitch-label" for="regionsearch">
						<span class="onoffswitch-inner"></span>
						<span class="onoffswitch-switch"></span>
					</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>If no Region Match</p>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<div class="styled-select">
					<select name="noregionassignee">
					  <option value="specialist" >ASSIGN TO NEXT AVAILABLE</option>
					  <option value="dm" >TAG AS ROGUE</option>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
		</div>
		-->
		<div class="row text-center">
			<a href="<?php echo base_url() ?>index.php/main/userSetup"><button type="submit" class="btn btn-primary center">SAVE</button></a>
		</div>
	</div>
</div>


