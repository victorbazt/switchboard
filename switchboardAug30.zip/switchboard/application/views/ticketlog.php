<div class="container">
	
	<div class="tables">
		<div class="bs-example widget-shadow row autopad" data-example-id="hoverable-table"> 
			
			<table id="example" class="table row-border myTable text-left" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>TICKET #</th>
					<th>TITLE</th>
					<th>ASSIGNED TO</th>
					<th>PRIORITY</th>
					<th>TYPE</th>
					<th>DATE ASSIGNED</th>
					<th>STATUS</th>
				</tr>
			</thead>
			</table>
				
		</div>
	
	</div>
						
</div>		
	
<script>
		// $(document).ready(function(){
		// 	$('.myTable').DataTable({
		// 		"aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
		// 		"iDisplayLength": 15
		// 	});
		// });

var table = $('#example').DataTable( {
	"ajax": {
		"url": "<?php echo base_url(); ?>index.php/main/getAllTickets",
		"dataSrc": ""
	},
	"columns": [
		{ "data": "tnum"},
		{ "data": "title"},
		{ "data": "specialist" },
		{ "data": "priority" },
		{ "data": "type" },
		{ "data": "date"},
		{ "data": "status"}
	]
} );
setInterval( function () {
	table.ajax.reload( null, false ); // user paging is not reset on reload
}, 10000 );

</script>