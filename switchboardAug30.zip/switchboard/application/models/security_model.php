<?php
class Security_model extends CI_Model{

	public function __construct(){
			ini_set('max_execution_time', 3000000);
			date_default_timezone_set("Asia/Singapore");
			parent::__construct();
			$this->load->database();
	 }
	 
    public function is_logged_in(){
        if($this->session->userdata('shortname')){
			return true;
       }
        else{
             $this->session->set_flashdata('feedback','Session Expired. Please Relogin.	');
             redirect('login');
       }
      }

       //check user package
      function checkSubscription(){
      	$this->db->from('userprofile');
      	$this->db->where('shortname', $this->session->userdata('shortname'));
      	$query = $this->db->get();
      	if($query->num_rows() > 0){
      		$date = $query->row()->date_added;
      		$date = strtotime($date);
      		$trialdate = strtotime('+30 day', $date);
      		$trialdate = date("Y-m-d", $trialdate);

      		if($trialdate < date('Y-m-d')){
      			$message = $trialdate;
      			$this->session->unset_userdata('shortname');
      			$this->session->set_flashdata('feedback', 'Your 30 Day Access has expired.');
             	redirect('login');
      		}
      	}

      }

     

	  
	  public function is_teamlead(){
		  $this->db->select('shortname');
		  $this->db->from('userprofile');
		  $this->db->where('shortname', $shortname);
		  $query = $this->db->get();
		  if($query->num_rows() > 0)
			  return TRUE;
		  else
			  redirect('main/userDashboard');
    }
}
	
?>