<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class email extends CI_Controller {

	/**
	 *	Integrating with Sharepoint. I used PHPSharepoint library by thybag. 
	 *	
	 *	For complete documentation, refer to:
	*	https://github.com/thybag/PHP-SharePoint-Lists-API
	 **/
	 public function __construct(){
			parent::__construct();
			 $this->load->library('email');
	 }
	 function send_hp(){
		$config['protocol'] = 'smtp';
		$config['mailpath'] = '/usr/sbin/sendmail';
		$config['smtp_host'] = 'smtp3.hpe.com';
		$config['smtp_port'] = 25;
		$config['charset'] = 'iso-8859-1';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		
		//Any sender with valid email format would do. 
		$sender = 'noreply@hp.com';
		
		$this->email->from($sender, 'NO REPLY');
		
		//Multiple recipients can be comma-separated
		$this->email->to('adrian-lester.tan@hp.com');
		//$this->email->cc();
		//$this->email->bcc(); 
		$this->email->subject("This is the subject");
		
		$this->email->message("This is the body.");
		
		$this->email->send();
		$this->email->print_debugger();
	 }
	 
	 /**
	 *	Due to SMTP policies of P&G, they have another layer to authorize what sender would from
	 *	from what server. Registration can be done via: eearegistrations.pg.com 
	 *	
	 *	For ACOE's P&G server (bdc-autocoe01.na.pg.com), the following are 
	 *	the authorized senders:
	 *		- noreply@autocoe.pg.com
			- noreply-autocoe@pg.com
			- noreply-autocoe@hp.com
	 **/
	 function send_pg(){
		 
		$config['protocol'] = 'smtp';
		$config['mailpath'] = '/usr/sbin/sendmail';
		$config['smtp_host'] = 'smtpgw.pg.com';
		$config['charset'] = 'iso-8859-1';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = 'html';
		$this->email->initialize($config);
		
		$sender = 'noreply-hlcp@pg.com';
		
		$this->email->from($sender, 'NO REPLY');
		
		//Multiple recipients can be comma-separated
		$this->email->to('adrian-lester.tan@hp.com');
		//$this->email->cc();
		//$this->email->bcc(); 
		$this->email->subject("This is the subject");
		
		$this->email->message("This is the body.");
		
		$this->email->send();
		$this->email->print_debugger();
	 }
	
	
}
