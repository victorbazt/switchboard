<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class job extends CI_Controller {

	/**
	 * Running PHP via Scheduled Tasks.
	 * To run a PHP activity on schedule, a batch file executing the command line sequence must be replicated.
	 
	 * The command line would look something like:
		1. Open the directory of the application
		2. Assuming we are in the application directory, we execute php.exe over the desired php endpoint
		
		Sample:
		> cd "C:/xampp/htdocs/<applicationfolder>"
		> C:/xampp/php/php.exe index.php <controller> <function> <param1> <param2> .....
	 **/
	 public function __construct(){
			parent::__construct();
			
	 }
	 
	 function myFunction($myParameter){
		 echo $myParameter;
	 }

	
	
}
