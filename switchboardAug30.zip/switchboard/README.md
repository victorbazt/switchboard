ciskeleton
==========

This repository would server as a jumpstart kit for PHP development in CI with HPE-relevant functionalities.

Functionalities are separated in each controller file.

**HPE and P&G LDAP**

-   Search (ldap\_search)

-   Auth (ldap\_bind)

**HPE and P&G Email**

-   Configurations for HPE and P&G SMTP servers

-   Listed authorized P&G sender coming from bdc-autocoe01

**Performing CRUD in Sharepoint via PHP (by thybag)**

**ODBC Connections –** used when connecting to the following DBMS:

-   MS SQL

-   HP Vertica
# switchboard
