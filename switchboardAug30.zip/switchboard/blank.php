<style type='text/css'>  body { font-family: lucida console; color: #aca89a; font-size: 11px;	 overflow-x: hidden !important; }  </style>
<script> function pageScroll(){window.scrollBy(0,10); scrolldelay = setTimeout('pageScroll()',1350); }pageScroll(); </script>
<br/><h3>SWITCHBOARD FORMERLY KNOWN AS AUTO-DM TOOL</h3><br/>
<p>Capture all open ticket assigned to a multiple workgroup.</p>
<p>Assign tickets to row or tag specific specialist.</p>
<p>Notify the assigned specialist via email.</p>