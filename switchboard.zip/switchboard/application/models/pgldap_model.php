<?php
class pgldap_model extends CI_Model {
	
	
	function pgldap_connect(){
		$conn = ldap_connect(PG_LDAP_URL)
            or die("Could not connect to LDAP server.");
			
		return $conn;
	}
	
	function pgldap_search($shortname){
		 // connect to ldap server
       $conn = $this->pgldap_connect();
        
        //Search dn based on email
        $dn = "ou=people,ou=pg,o=world";
        $filter= "(|(extshortname=".$shortname."))";
		$fields = array();
		$search=ldap_search($conn, $dn, $filter, $fields);
		
		//NOTE: The ldap_get_entries can return many objects since there could be multiple results based on the filter. In this case, extshortname is a unique identifier so we just return the first index.
		
        $info = ldap_get_entries($conn, $search);
		
		ldap_close($conn);
		if(isset($info[0])){
			return $this->discoverEmail($info[0]);
			
		}
		else
			return false;
	}
	
	
	 function pgldap_bind($username, $password) {
        // connect to ldap server
       $conn = $this->pgldap_connect();
        
        //Search dn based on email
        $dn = "ou=people,ou=pg,o=world";
        $filter= "(|(extshortname=".$username."))";
		$fields = array();
		$search=ldap_search($conn, $dn, $filter, $fields);
		
        $info = ldap_get_entries($conn, $search);
		
		
		//Create the rdn and proceed with authentication
		if(isset($info[0]['dn']))
			$rdn = $info[0]['dn'];
		else
			return false;
         
		$bind = ldap_bind($conn, $rdn, $password);
		 ldap_close($conn);
		if($bind)
			return $info;
		
		else
			return false;
		
	}
	
	function auth($username, $password){
	   
	   $username = str_replace('@pg.com','',$username);
	   $query = $this->pgldap_bind($username, $password);
	   
		if(isset($query[0]))
			$result = $query[0];
		else{
			return 'UNAUTHORIZED';
		}
	   
		$result = $this->discoverEmail($result);
		return $result;
		
	}
	
	/*
		Important Piece of code for checking if external p&g user can receive email. Due to P&G policies for 3rd party accounts, they can no longer can a dedicated mailbox, and will instead have auto forwarding
	*/
	function discoverEmail($result){
		//we check both mailroutingaddress and mail since new users would have mail field populated 
		//as their email forwarding
		if(isset($result['mailroutingaddress'][0])){
			$emailAddress = $result['mailroutingaddress'][0];
		}
		else if(isset($result['mail'][0])){
			$emailAddress = $result['mail'][0];
		}
		else{
			//block user as not supported and tell to apply for Forward-only PG service
			$emailAddress = "Request for email forwarding: https://am.svcs.hp.com/requestmanagement/CMP_PG/Form/Intermediate?subCategoryId=ddcc9dff-31f4-4a44-8cb6-97bd7f1c8af8&subCategoryName=Start%2Bor%2BStop%2Bemail%2BForwarding";
		}
		/*
		* 11-6-2015 hot patch fix if user doesn't have email forwarding enabled,
		* the returned email address is @exchangemail.pg.com so we have to remove exchangemail
		*/
		
		if(strpos($emailAddress, 'exchangemail.pg.com') !== false)
			$emailAddress = str_replace('exchangemail.', '', $emailAddress);
		
		array_push($result, array("trueEmail"=>$emailAddress));
		return $result;
	}
	
}
?>