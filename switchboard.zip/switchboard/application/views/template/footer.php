    
  </div>
</div>

</body>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="<?php echo base_url();?>assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap-switch.min.js"></script>
    <script src="//cdn.jsdelivr.net/bootstrap.tagsinput/0.4.2/bootstrap-tagsinput.min.js"></script>
  <script>
    $.fn.bootstrapSwitch.defaults.onColor = 'success';
    $.fn.bootstrapSwitch.defaults.offColor = 'warning';
    $("[name='ticketTitle']").bootstrapSwitch().size("mini");
    $("[name='regionSearch']").bootstrapSwitch().size("mini");
  </script>
  
  <script>
  $(document).ready(function() {
	  getWorkgroup();
	  getKeywords();
	  getSetting();
	  getRegions();
	  // deleteShift('EARLYASIA');
	  // getTable();
	  

  });
  
	function getSetting(){
		$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateAllSettings',
	        type: 'POST', // Send post data
	        data: 'setting=getsetting',
	        async: false,
	        success: function(s){
	        	settings = s;
	        }
		});
		settings = settings.split(',');
		document.getElementById('timeout').value = settings[0];
		if(settings[1] == 'true'){
			$('.ts').bootstrapSwitch('state', true);
		}
		else{
			$('.ts').bootstrapSwitch('state', false);
		}
		if(settings[2] == 'true'){
			$('.rs').bootstrapSwitch('state', true);
		}
		else{
			$('.rs').bootstrapSwitch('state', false);
		}
		document.getElementById('noregionassignee').value = settings[3];
	}
	
	function addRegion(){
		var region = $('#regionName').val();
		var start = $('#startTime').val();
		var end = $('#endTime').val();
		if(region != ''){
			$.post("<?php echo base_url(); ?>index.php/main/updateRegion", { type: 'new', region: region, start: start, end: end, setting : '' },
			function(data) {
			//change to notif modal
				alert(data);
			});
			updateShifts();
			
		}
	}
	
	function deleteShift(shift){
		if(shift != ''){
			$.post("<?php echo base_url(); ?>index.php/main/deleteShift", { type: 'new', shift: shift },
			function(data) {
			//change to notif modal
				alert(data);
			});
			
		}
	}
	
	function deleteRow(r) {
		var i = r.parentNode.parentNode.rowIndex;
		document.getElementById("shifts").deleteRow(i);
	}
	
	function getTable() { 

		var obj = $('#shifts tbody tr').map(function() {
		var $row = $(this);
		var t1 = $row.find(':nth-child(1)').text();
		var t2 = $row.find(':nth-child(2)').text();
		var t3 = $row.find(':nth-child(3)').text();
		return {
			td_1: $row.find(':nth-child(1)').text(),
			td_2: $row.find(':nth-child(2)').text(),
			td_3: $row.find(':nth-child(3)').text()
		   };
		}).get();
		console.log(obj);
	}
	
	 function getRegions() {
	  
	  $.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateRegion',
	        type: 'POST', // Send post data
	        data: 'type=fetch',
	        async: false,
	        success: function(s){
	        	regions = s;
	        }
		});
		region = new Array();
		allregion = regions.split('*');
		for(a=0;a<allregion.length-1;a++){
			region[a] = allregion[a].split(',');
			var regionName = region[a][0];
			var startTime = region[a][1];
			startTime = startTime.replace("1000-01-02 ", "");
			startTime = startTime.replace("1000-01-01 ", "");
			var endTime = region[a][2];
			endTime = endTime.replace("1000-01-02 ", "");
			endTime = endTime.replace("1000-01-01 ", "");
			var table=document.getElementById("shifts");
			var row=table.insertRow(-1);
			var cell1=row.insertCell(0);
			var cell2=row.insertCell(1);
			var cell3=row.insertCell(2);
			var cell4=row.insertCell(3);
			var cell5=row.insertCell(4);
			// cell1.innerHTML='<div contenteditable>'+regionName+'</div>';
			// cell2.innerHTML='<div contenteditable>'+startTime+'</div>';   
			cell1.innerHTML=regionName;
			cell2.innerHTML=startTime;        
			cell3.innerHTML=endTime;           
			cell4.innerHTML='';           
			cell5.innerHTML='<i id="'+regionName+'" class="fa fa-times icon-danger" aria-hidden="true" onclick="deleteRow(this); deleteShift(&#39;'+regionName+'&#39;)";></i>';           	
			
		}
      // var regionName = document.getElementById("regionName").value;
      // var startTime = document.getElementById("startTime").value;
      // var endTime = document.getElementById("endTime").value;
      
      

      // var table=document.getElementById("shifts");
      // var row=table.insertRow(-1);
      // var cell1=row.insertCell(0);
      // var cell2=row.insertCell(1);
      // var cell3=row.insertCell(2);
      // var cell4=row.insertCell(3);
      // var cell5=row.insertCell(4);
      // cell1.innerHTML=regionName;
      // cell2.innerHTML=startTime;        
      // cell3.innerHTML=endTime;           
      // cell4.innerHTML='<i class="fa fa-pencil" aria-hidden="true"></i>';           
      // cell5.innerHTML='<i class="fa fa-times" aria-hidden="true"></i>';           
  }
	function getWorkgroup(){
		$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateAllSettings',
	        type: 'POST', // Send post data
	        data: 'setting=getworkgroup',
	        async: false,
	        success: function(s){
	        	workgroups = s;
	        }
		});
		$('#workgroup').tagsinput('add', workgroups);
	}
	
	function SubmitFormData(){
		var workgroups = $('#workgroup').val();
		var timeout = $('#timeout').val();
		var titlesearch = (document.getElementById('titlesearch').checked == true) ? 1 : 0;
		var regionsearch = (document.getElementById('regionsearch').checked == true) ? 1 : 0;
		var noregionassignee = $('#noregionassignee').val();
		var keywords = $('#keyword').val();
		
		if(workgroups != ''){
			$.post("<?php echo base_url(); ?>index.php/main/updateAllSettings", { timeout: timeout, titlesearch: titlesearch, regionsearch: regionsearch, noregionassignee: noregionassignee, workgroups: workgroups, keywords: keywords, setting : '' },
			function(data) {
			 $('#saved').html(data);
			});
			alert(workgroups);
		}
		else{
			$('#saved').html('Workgroup cant be empty.');
		}
	}
	function getKeywords(){
		$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/updateAllSettings',
	        type: 'POST', // Send post data
	        data: 'setting=getkeyword',
	        async: false,
	        success: function(s){
	        	keywords = s;
	        }
		});
		$('#keyword').tagsinput('add', keywords);
	}
  </script>





<script>

  //sidebar
  $("#menu-toggle").click(function(e) {
      e.preventDefault();
		$('#shiftSettings').hide();
		$('#extractSettings').hide();
      $("#wrapper").toggleClass("toggled");
	  setTimeout(function () {
			 $('#shiftSettings').fadeIn();
		 },500);
	  

  });


  $("#settingsShift").click(function(e) {
    $('#shiftSettings').show();
    $('#extractSettings').hide();
     $(this).addClass('active').siblings().removeClass('active');
  });
 $("#settingsExtract").click(function(e) {
    $('#extractSettings').show();
    $('#shiftSettings').hide();
    $(this).addClass('active').siblings().removeClass('active');
  });



</script>

<script type="text/javascript">
  
  $('input[name="ticketTitle"]').on('switchChange.bootstrapSwitch', function(event, state) 
  {
    if($('input[name="ticketTitle"]').bootstrapSwitch('state'))
      $('#ticketTitleDependent').show();

    else
      $('#ticketTitleDependent').hide();
  });  
  $('input[name="regionSearch"]').on('switchChange.bootstrapSwitch', function(event, state) 
  {
    if($('input[name="regionSearch"]').bootstrapSwitch('state'))
      $('#regionSearchDependent').show();

    else
      $('#regionSearchDependent').hide();
  });
 
 (function ($) {
  $('.spinner .btn:first-of-type').on('click', function() {
    $('.spinner input').val( parseInt($('.spinner input').val(), 10) + 1);
  });
  $('.spinner .btn:last-of-type').on('click', function() {
    $('.spinner input').val( parseInt($('.spinner input').val(), 10) - 1);
  });
})(jQuery);

 
  function updateShifts() {
      var regionName = document.getElementById("regionName").value;
      var startTime = document.getElementById("startTime").value;
      var endTime = document.getElementById("endTime").value;
      
      

      var table=document.getElementById("shifts");
      var row=table.insertRow(-1);
      var cell1=row.insertCell(0);
      var cell2=row.insertCell(1);
      var cell3=row.insertCell(2);
      var cell4=row.insertCell(3);
      var cell5=row.insertCell(4);
      cell1.innerHTML=regionName;
	  // cell1.contentEditable = "true";
      cell2.innerHTML=startTime;        
      cell3.innerHTML=endTime;           
      cell4.innerHTML='';           
      cell5.innerHTML='<i id="'+regionName+'" class="fa fa-times icon-danger" aria-hidden="true" onclick="deleteRow(this); deleteShift(&#39;'+regionName+'&#39;)";></i>';    
	  
 
  }
</script>



</html>