<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Agnes Nuguid">
	<title>Switchboard</title>

	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="//cdn.jsdelivr.net/bootstrap.tagsinput/0.4.2/bootstrap-tagsinput.css" />
    <link href="<?php echo base_url('assets/css/simple-sidebar.css');?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/bootstrap-switch.css');?>" rel="stylesheet">
	
	<!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
	
	
	<?php 
		date_default_timezone_set("Asia/Singapore");
		   
		if ($currentPage == 'calendar') 
		{ 
			echo '<link rel="stylesheet prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"></script>';
		}
	?>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/font-awesome-4.6.3/css/font-awesome.min.css">
    <!-- Custom styles for this template -->

	<!-- Datatables CSS -->
	<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.min.css" rel='stylesheet' type='text/css' />
	<link href="<?php echo base_url(); ?>assets/css/chosen.css" rel='stylesheet' type='text/css' />

	<link href="<?php echo base_url();?>assets/css/template.css" rel="stylesheet">
		
		
    <script src="<?php echo base_url(); ?>/js/jquery-1.11.1.min.js"></script>
	<script src="<?php echo base_url(); ?>/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>/assets/js/chosen.jquery.js"></script>
	
	<!--animate-->
	<link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="<?php echo base_url(); ?>/js/wow.min.js"></script>
	<script>
	 new WOW().init();
		
	 $(document).ready(function() {
		 setTimeout(function () {
			 $('#load_screen').fadeOut();
		 },100);
		 
	});
		
	</script>
<!--//end-animate-->

    <?php if ($currentPage == 'home') 
      { ?>
      <script src="https://code.highcharts.com/highcharts.js"></script>
      <script src="https://code.highcharts.com/modules/heatmap.js"></script> 	
	  <script src="https://code.highcharts.com/modules/treemap.js"></script>

      <?php 
      }
    ?>

</head>
   <?php if ($currentPage == 'home') 
      { ?>
			<body onload=display_ct();>
	<?php 
      }
	  else{ echo "<body>";
	  }
    ?>

<div id="load_screen">
	
	
	</div>
	
	


<div id="wrapper" class="toggled">

  <div id="sidebar-wrapper">
    
   <div class="btn-group btn-group-justified" >
      <a href="#settingsShift" id="settingsShift" class="btn btn-info active">Shift</a>
      <a href="#settingsExtract" id="settingsExtract" class="btn btn-info">Extract</a>
    </div>
    <div class="settingsContainer" id="shiftSettings">
	<form id="shift-form" method="post">
      <fieldset>
        <label for="exampleSelect1" class="settings-label">Region Name</label>
        <input type="text" class="form-control pull-right mini" id="regionName" name="regionName"/>
      </fieldset>
      <fieldset>
        <label for="exampleSelect1" class="settings-label">Start Time</label>
        <select class="form-control pull-right" id="startTime" name="startTime">
          <option value="00:00:00">  00:00:00 </option>
          <option value="00:30:00">  00:30:00 </option>
          <option value="01:00:00">  01:00:00 </option>
          <option value="01:30:00">  01:30:00 </option>
          <option value="02:00:00">  02:00:00 </option>
          <option value="02:30:00">  02:30:00 </option>
          <option value="03:00:00">  03:00:00 </option>
          <option value="03:30:00">  03:30:00 </option>
          <option value="04:00:00">  04:00:00 </option>
          <option value="04:30:00">  04:30:00 </option>
          <option value="05:00:00">  05:00:00 </option>
          <option value="05:30:00">  05:30:00 </option>
          <option value="06:00:00">  06:00:00 </option>
          <option value="06:30:00">  06:30:00 </option>
          <option value="07:00:00">  07:00:00 </option>
          <option value="07:30:00">  07:30:00 </option>
          <option value="08:00:00">  08:00:00 </option>
          <option value="08:30:00">  08:30:00 </option>
          <option value="09:00:00">  09:00:00 </option>
          <option value="09:30:00">  09:30:00 </option>
          <option value="10:00:00">  10:00:00 </option>
          <option value="10:30:00">  10:30:00 </option>
          <option value="11:00:00">  11:00:00 </option>
          <option value="11:30:00">  11:30:00 </option>
          <option value="12:00:00">  12:00:00 </option>
          <option value="12:30:00">  12:30:00 </option>
          <option value="13:00:00">  13:00:00 </option>
          <option value="13:30:00">  13:30:00 </option>
          <option value="14:00:00">  14:00:00 </option>
          <option value="14:30:00">  14:30:00 </option>
          <option value="15:00:00">  15:00:00 </option>
          <option value="15:30:00">  15:30:00 </option>
          <option value="16:00:00">  16:00:00 </option>
          <option value="16:30:00">  16:30:00 </option>
          <option value="17:00:00">  17:00:00 </option>
          <option value="17:30:00">  17:30:00 </option>
          <option value="18:00:00">  18:00:00 </option>
          <option value="18:30:00">  18:30:00 </option>
          <option value="19:00:00">  19:00:00 </option>
          <option value="19:30:00">  19:30:00 </option>
          <option value="20:00:00">  20:00:00 </option>
          <option value="20:30:00">  20:30:00 </option>
          <option value="21:00:00">  21:00:00 </option>
          <option value="21:30:00">  21:30:00 </option>
          <option value="22:00:00">  22:00:00 </option>
          <option value="22:30:00">  22:30:00 </option>
          <option value="23:00:00">  23:00:00 </option>
          <option value="23:30:00">  23:30:00 </option>
         </select>
      </fieldset>
       <fieldset>
        <label for="exampleSelect1" class="settings-label">End Time</label>
        <select class="form-control pull-right" id="endTime" name="endTime">
          <option value="00:00:00">  00:00:00 </option>
          <option value="01:00:00">  01:00:00 </option>
          <option value="01:30:00">  01:30:00 </option>
          <option value="02:00:00">  02:00:00 </option>
          <option value="02:30:00">  02:30:00 </option>
          <option value="03:00:00">  03:00:00 </option>
          <option value="03:30:00">  03:30:00 </option>
          <option value="04:00:00">  04:00:00 </option>
          <option value="04:30:00">  04:30:00 </option>
          <option value="05:00:00">  05:00:00 </option>
          <option value="05:30:00">  05:30:00 </option>
          <option value="06:00:00">  06:00:00 </option>
          <option value="06:30:00">  06:30:00 </option>
          <option value="07:00:00">  07:00:00 </option>
          <option value="07:30:00">  07:30:00 </option>
          <option value="08:00:00">  08:00:00 </option>
          <option value="08:30:00">  08:30:00 </option>
          <option value="09:00:00">  09:00:00 </option>
          <option value="09:30:00">  09:30:00 </option>
          <option value="10:00:00">  10:00:00 </option>
          <option value="10:30:00">  10:30:00 </option>
          <option value="11:00:00">  11:00:00 </option>
          <option value="11:30:00">  11:30:00 </option>
          <option value="12:00:00">  12:00:00 </option>
          <option value="12:30:00">  12:30:00 </option>
          <option value="13:00:00">  13:00:00 </option>
          <option value="13:30:00">  13:30:00 </option>
          <option value="14:00:00">  14:00:00 </option>
          <option value="14:30:00">  14:30:00 </option>
          <option value="15:00:00">  15:00:00 </option>
          <option value="15:30:00">  15:30:00 </option>
          <option value="16:00:00">  16:00:00 </option>
          <option value="16:30:00">  16:30:00 </option>
          <option value="17:00:00">  17:00:00 </option>
          <option value="17:30:00">  17:30:00 </option>
          <option value="18:00:00">  18:00:00 </option>
          <option value="18:30:00">  18:30:00 </option>
          <option value="19:00:00">  19:00:00 </option>
          <option value="19:30:00">  19:30:00 </option>
          <option value="20:00:00">  20:00:00 </option>
          <option value="20:30:00">  20:30:00 </option>
          <option value="21:00:00">  21:00:00 </option>
          <option value="21:30:00">  21:30:00 </option>
          <option value="22:00:00">  22:00:00 </option>
          <option value="22:30:00">  22:30:00 </option>
          <option value="23:00:00">  23:00:00 </option>
          <option value="23:30:00">  23:30:00 </option>
         </select>
      </fieldset>

      <fieldset><input type="button" id="addregion" class="btn btn-primary center" onclick="addRegion(); " value="Add" />
      </fieldset>
      </form>
      <table id="shifts" class="table table-condensed table-striped">
        <tbody>
          <td id="regionShifts" class="col-md-6"></td>
          <td id="startTimeShifts" class="col-md-2"></td>
          <td id="endTimeShifts" class="col-md-2"></td>
          <td id="edit" class="col-md-1"></td>
          <td id="delete" class="col-md-1"></td>
        </tbody>
      </table>
    </div>

    <div class="settingsContainer" id="extractSettings">
	<form id="setting-form" method="post">
      <fieldset>
	  <label for="exampleSelect1" class="settings-label pull-left">Team</label><br>
	  <input type="text" id="team" name="team" class="form-control login" value="<?php echo $this->session->userdata('team');  ?>" disabled="disabled" />
      </fieldset>
      <fieldset>
        <label for="exampleSelect1" class="settings-label pull-left">Workgroup</label><br>
        <input type="text" id="workgroup" name="workgroup" class="form-control"
                   value="" data-role="tagsinput" />
      </fieldset>
      
      <fieldset>
         <label for="exampleSelect1" class="settings-label pull-left">Extraction Interval</label>
         <select class="form-control pull-right" id="timeout">
           <option value="300">5 minutes</option>
           <option value ="600">10 minutes</option>
           <option value ="900">15 minutes</option>
           <option value ="1200">20 minutes</option>
           <option value ="1500">25 minutes</option>
           <option value ="1800">30 minutes</option>
         </select>
      </fieldset>
      <fieldset>
          <label for="exampleSelect1" class="settings-label pull-left">Search Ticket Title for Keywords</label>
          <input type="checkbox" name="ticketTitle" id="titlesearch" class="form-control pull-right ts" checked="true" data-size="mini">
      </fieldset>

      <div id="ticketTitleDependent">

        <fieldset>
          <label for="exampleSelect1" class="settings-label pull-left">Search for Region?</label>
          <input type="checkbox" name="regionSearch" id="regionsearch" class="form-control pull-right rs" checked="true" data-size="mini" data-on-text="YES" data-off-text="NO">
        </fieldset>
<!--
        <fieldset>
          <label for="exampleSelect1" class="settings-label pull-left">Search Title Up To How Many Characters?</label>
          <div class="input-group spinner pull-right">
            <input type="text" class="form-control" value="42">
            <div class="input-group-btn-vertical">
              <button class="btn btn-default" type="button"><i class="fa fa-caret-up"></i></button>
              <button class="btn btn-default" type="button"><i class="fa fa-caret-down"></i></button>
            </div>
          </div>
        </fieldset>
-->
		<div id="regionSearchDependent">
			<fieldset>
			  <label for="exampleSelect1" class="settings-label pull-left">If Region Tag not present on Title assign to?</label>
			  <select class="form-control pull-right" id="noregionassignee">
			  <option value="dm">DM</option>
			  <option value="specialist">Specialists</option>
			  </select>
			</fieldset>
		</div>
        <fieldset>
          <label for="exampleSelect1" class="settings-label pull-left">List of keywords</label><br>
          <input type="text" id="keyword" name="keyword" class="form-control"
                   value="" data-role="tagsinput" />
        </fieldset>
      
      </div>
      <fieldset><input type="button" id="submit" class="btn btn-primary center" onclick="SubmitFormData();" value="Save" /></fieldset>
	  <p id="saved" class="pull-center"></p>
    </div>
	</form>
    
  </div>


<div id="page-content-wrapper">
  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <div class="navbar-text"><img class="icons" src="<?php echo base_url();?>assets/images/icons/switchboardLogo.png"/>Switchboard</div>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <?php 
		  if (!isset($hidemenu)){
		  if ($currentPage == 'home') 
          { ?>
              <li class="active">
          <?php 
          }
            else{ ?>
              <li>
          <?php  } ?>
          <a href="<?php echo base_url();?>/index.php/main/Dashboard"><img class="icons" src="<?php echo base_url();?>assets/images/icons/home.png"/>Home</a></li>
		  <?php 
		   
		  if ($currentPage == 'calendar') 
          { 
				echo '<li class="active">';
          }
            else{ 
              echo '<li>';
           }
			?>
		  <a href="<?php echo base_url();?>index.php/main/calendar"><img class="icons" src="<?php echo base_url();?>assets/images/icons/calendar.png"/>Calendar</a></li>
		  <?php
		  if ($currentPage == 'myteam') 
          { 
              echo '<li class="active">';
          }
            else{ 
              echo '<li>';
           }
		   ?>
          <a href="<?php echo base_url();?>index.php/main/myTeam"><img class="icons" src="<?php echo base_url();?>assets/images/icons/myTeam.png"/>My Team</a></li>
          <?php
		  if ($currentPage == 'ticketlog') 
          { 
              echo '<li class="active">';
          }
            else{ 
              echo '<li>';
           }
		   ?>
		   <a href="<?php echo base_url();?>index.php/main/ticketlog"><img class="icons" src="<?php echo base_url();?>assets/images/icons/ticketLog.png"/>Ticket Log</a></li>            
        </ul>

        <ul class="nav navbar-nav navbar-right">
        	
          <li><a href="#"><img class="icons" src="<?php echo base_url();?>assets/images/icons/profile.png"/><?php echo $this->session->userdata('wholename');  ?></a></li>
		  <li>
          <a href="<?php echo base_url();?>index.php/main/logout"><img class="icons" src="<?php echo base_url();?>assets/images/icons/logout.png"/></a></li>
		  <?php if ($currentPage == 'settings') 
          { ?>
              <li class="active">
          <?php 
          }
            else{ ?>
              <li>
          <?php  } ?>
          <a href="#menu-toggle" id="menu-toggle"><img class="icons" src="<?php echo base_url();?>assets/images/icons/settings.png"/></a></li>
        </ul>
		<?php
		  } ?>
      </div><!--/.nav-collapse -->
    </div>
  </nav>