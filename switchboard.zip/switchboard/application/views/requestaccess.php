

<div class="container">
	<div class="jumbotron">
		<form action="<?php echo base_url();?>index.php/main/saveRequestAccess" autocomplete="off" method="post">
		<div class="spacer text-center">
			<img class="robot" src="<?php echo base_url();?>assets/images/icons/robot.png"/>REQUEST ACCESS
		</div>
		<div class="row"></div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-6">	
				<?php echo $this->session->flashdata('errorshortname'); ?>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>P&G Shortname</p>
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-6">
				<input type="text" name="shortname" placeholder="PG.SHORTNAME" class="form-control" required="true"/>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>Email Address</p>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<input type="email" name="email" placeholder="john-doe@hpe.com" class="form-control" required="true"/>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
			</div>
			<div class="col-xs-3 col-sm-3 col-md-3 col-lg-6">	
				<?php echo $this->session->flashdata('errorworkgroup'); ?>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p>Team Name</p>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<input type="text" name="team" placeholder="G.AACOE" class="form-control" required="true" />
			</div>
		</div>
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<p></p>
			</div>
		</div>
		<div class="row text-center">
			<a href="#"><button type="submit" class="btn btn-primary center">Request</button></a>
		</div>
	</div>
</div>


