

<div class="container">
	<div class="row">
		<h2 align="center"><span id='ct'></span><h2>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<div class="panel asia third">
				<div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<i class="fa fa-sun-o fa-5x" aria-hidden="true"></i>
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							<p class="shift-header">ASIA</p>						
							<?php
							$asia = 0;
							if(isset($dmoftheday))foreach($dmoftheday as $dm){
								if($dm['region'] == 'ASIA'){
									$asia = 1;
									echo '<p>'.$dm['wholename'].'</p>';
								}
							}
							else{
								echo 'No Assigned DM';
							}
							if($asia == 0)
								echo 'No Assigned DM';
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<div class="panel emea third">
				<div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<i class="fa fa-cloud fa-5x" aria-hidden="true"></i>
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							<p class="shift-header">EMEA</p>					
							<?php
							$emea = 0;
							if(isset($dmoftheday))foreach($dmoftheday as $dm){
								if($dm['region'] == 'EMEA'){
									$emea = 1;
									echo '<p>'.$dm['wholename'].'</p>';
								}
							}
							else{
								echo 'No Assigned DM';
							}
							if($emea == 0)
								echo 'No Assigned DM'
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<div class="panel nala third">
				<div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<i class="fa fa-moon-o fa-5x" aria-hidden="true"></i>
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							<p class="shift-header">NALA</p>						
							<?php
							$nala = 0;
							if(isset($dmoftheday))foreach($dmoftheday as $dm){
								if($dm['region'] == 'NALA'){
									$nala = 1;
									echo '<p>'.$dm['wholename'].'</p>';
								}
							}
							else{
								echo 'No Assigned DM';
							}
							if($nala == 0)
								echo 'No Assigned DM';
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<div class="panel ooo third">
				<div class="panel-body">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
							<i class="fa fa-briefcase fa-5x" aria-hidden="true"></i>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
							<p class="shift-header">Out of Office</p>						
							<?php
							$temp = 0;
							if(isset($ooospecialist))foreach($ooospecialist as $specialist){
								if(date('Y-m-d h:i:s') >= $specialist['sdate'] && date('Y-m-d h:i:s') <= $specialist['edate']){
									echo '<p>'.$specialist['wholename'].'</p>';
									$temp = 1;
								}
							}else{
								$temp = 1;
								echo 'No OOO Resource';
							}
							if($temp == 0){
								echo 'No OOO Resource';
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
			<div class="panel">
				
				<div class="panel-body">
					<img class="img-responsive robot center" id="robot" src="<?php echo base_url();?>assets/images/icons/robotPending.png"/>
					<p>&nbsp;</p>
					<button type="submit" id="playStopButon" class="btn center btn-primary" onclick="
							
							if(document.getElementById('playStop').src == '<?php echo base_url();?>assets/images/icons/play.png')
							{
								document.getElementById('robot').src='<?php echo base_url();?>assets/images/icons/robotRunning.gif'; 
								$('#playStopText').html('STOP DISPATCHING');
								$('#playStopButton').removeClass('btn-primary').addClass('btn-danger');
							}
							
							else
							{
								document.getElementById('robot').src='<?php echo base_url();?>assets/images/icons/robotPending.png'; 
								$('#playStopText').html('START DISPATCHING');
							}
							
						">
							<img id="playStop" class="icons" src='<?php echo base_url();?>assets/images/icons/play.png'/><span id="playStopText">START DISPATCHING</span>
						</button>
						<iframe id="stop" width="1px" height='1px' frameborder="0" scrolling="no" src="<?php echo base_url();?>blank.php"></iframe>
							<iframe id="ifr" width="100%" height="300px" frameborder="0" src="<?php echo base_url();?>blank.php"></iframe>
					
					</p>						
				</div>
			</div>
		</div>

		<div class="col-xs-12 col-sm-12 col-md-5 col-lg-6">
			<div class="panel">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/statistics.png"/>Daily Ticket Dispatcher Statistics</div></div>
				<div class="panel-body pull-center">
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
						<div id="totalDispatchedIMTickets"></div>
						<h4>TOTAL IM TICKETS DISPATCHED</h4>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
						<div id="totalDispatchedFRTickets"></div>
						<h4>TOTAL FR TICKETS DISPATCHED</h4>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
						<div id="rogueTickets"></div>
						<h4>IM/FR ROGUE TICKETS DISPATCHED</h4>
					</div>
				</div>
			</div>			
<!--Workload Treemap-->
			<div class="panel">
				
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/heatmap.png"/>Team Workload</div></div>
				
				<div id="treemap" style="width:100%;margin: 0 auto"></div>
				
				
			</div>
	
<!--./Workload Treemap-->
		</div>
		<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
			<div class="panel">
				<div class="panel-heading clearfix"><div class="panel-title pull-left"><img class="icons" src="<?php echo base_url();?>assets/images/icons/statistics.png"/>Tickets Assigned to Me</div></div>
					<div class="panel-body" style="height:590px">
					<!--datatables -->
							
							<table id="example" class="table-assigned table table-striped myTable pull-center">
							<thead>
								<tr>
									<th class="pull-center">Ticket</th>
									<th class="pull-center">Title</th>
									<th class="pull-center">Priority</th>
								</tr>
							</thead>
							</table>
					<!--end datatables-->
					
					</div>
			</div>
		</div>


		

	</div>
	<div class="row">
	</div>

	</div>


<script type="text/javascript"> 
      function display_c(){
      var refresh=1000; // Refresh rate in milli seconds
      mytime=setTimeout('display_ct()',refresh)
      }

      function display_ct() {
      var strcount
      var x = new Date()
      var str = x.toString();

      // this should be safe since nothing else in the date string contains a opening paren
      var index = str.indexOf(" (");

      // if the index exists
      if(~index) {
        str = str.substr(0, index);
      }
      document.getElementById('ct').innerHTML = str;
      tt=display_c();
      }

</script>

<script>
$(function () {
	
    $('#treemap').highcharts({
        colorAxis: {
            minColor: '#FFFFFF',
            maxColor: '#01a982'
        },
        series: [{
            type: 'treemap',
			borderColor:'#31414e',
			borderWidth:3,
            layoutAlgorithm: 'squarified',
            data: [
			<?php
			if(isset($ticketcountspe))foreach($ticketcountspe as $spe => $values)
			echo "{ name: '".$ticketcountspe[$spe]['specialist']."', value: ".$ticketcountspe[$spe]['tkt_count'].", colorValue: ".$ticketcountspe[$spe]['tkt_count']." },";
			else
				echo "{ name: 'No Assigned Ticket to Specialist', value: 1, colorValue: 0 },";
			?>
			]
        }],
		
        title: {
            text: ''
        }, 
		subtitle: {
            text: ''
        },
		credits: {
		    enabled: false
	    },
		chart: {
			backgroundColor: null
		}
    });


    //Pie charts!//
    /*

     $.getJSON(spoolsJSON, function(data) {
              // Populate series
             
              for (i = 0; i < 3; i++)
              {
                  arrayNaLalagyanMo.push([data[i].extractTime, data[i].spoolC]);
              }
*/
	//spoolChart = new Highcharts.Chart({
	$('#totalDispatchedIMTickets').highcharts({

        chart: {
        	marginTop: 20,
            type: 'pie',
            plotBorderWidth: 0,
            backgroundColor:null,
            height:180,
            // renderTo: 'totalDispatchedTickets',
        },

		title: {
            text: '<?php echo $imlow[0]['total']+$imaverage[0]['total']+$imhigh[0]['total']+$imcritical[0]['total']; ?>',
            
            style: {
            	color:'#cccccc',
            	fontSize:'20px'
        	},
        	verticalAlign:'middle'
     	},

		subtitle: {
		  text: '',
		  style: {
		      display: 'none'
		  }
		},

		credits:{
          enabled:false
        },

       
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            dataLabels: {
	                enabled: false
	            },
	            showInLegend: false,
	            innerSize:'80%',
	            borderWidth: 0
	        }
	    },

       series: [{
		   name: 'Ticket Count',
            data: [
                {name:'Critical', y:<?php if(isset($imcritical[0]['total']))
										   echo $imcritical[0]['total']; 
										  else
											echo '0';
									   ?>, color:'#f04953'},
                {name:'High', y:<?php if(isset($imhigh[0]['total']))
										   echo $imhigh[0]['total']; 
									  else
										   echo '0';
									   ?>, color:'#F09144'},
                {name:'Average', y:<?php if(isset($imaverage[0]['total'])) 
											echo $imaverage[0]['total']; 
										 else
											echo '0';
										?>, color:'#FFd144'},
                {name:'Low', y:<?php if(isset($imlow[0]['total'])) 
										echo $imlow[0]['total'];
									 else
										echo '0';
									?>, color:'#2AD2C9'}
    	]}]
    });


    /*
    });
    //calls the updater of json accoring to interval
    setInterval(function() { getSpoolData();}, spools_update_interval);
      
     function getSpoolData(){
                 
         var url = spoolsJSON;

         $.getJSON (url, function (jsonFromServer){
            spoolArray.length=0;
            for (i = 0; i < 3; i++){
                spoolArray.push([jsonFromServer[i].extractTime, jsonFromServer[i].spoolC]);

            }
            spoolArray.reverse();

             spoolChart.series[0].setData(spoolArray,true);
             console.log("refresh you");
         });
     }
     */

    $('#totalDispatchedFRTickets').highcharts({

        chart: {
        	marginTop: 20,
            type: 'pie',
            plotBorderWidth: 0,
            backgroundColor:null,
            height:180,
            // renderTo: 'totalDispatchedTickets',
        },

		title: {
            text: '<?php echo $frlow[0]['total']+$fraverage[0]['total']+$frhigh[0]['total']+$frcritical[0]['total']; ?>',
            
            style: {
            	color:'#cccccc',
            	fontSize:'20px'
        	},
        	verticalAlign:'middle'
     	},

		subtitle: {
		  text: '',
		  style: {
		      display: 'none'
		  }
		},

		credits:{
          enabled:false
        },

       
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            dataLabels: {
	                enabled: false
	            },
	            showInLegend: false,
	            innerSize:'80%',
	            borderWidth: 0
	        }
	    },

       series: [{
			name: 'Ticket Count',
            data: [
                {name:'Critical', y:<?php if(isset($frcritical[0]['total']))
										   echo $frcritical[0]['total']; 
										  else
											echo '0';
									   ?>, color:'#f04953'},
                {name:'High', y:<?php if(isset($frhigh[0]['total']))
										   echo $frhigh[0]['total']; 
									  else
										   echo '0';
									   ?>, color:'#F09144'},
                {name:'Average', y:<?php if(isset($fraverage[0]['total'])) 
											echo $fraverage[0]['total']; 
										 else
											echo '0';
										?>, color:'#FFd144'},
                {name:'Low', y:<?php if(isset($frlow[0]['total'])) 
										echo $frlow[0]['total'];
									 else
										echo '0';
									?>, color:'#2AD2C9'}
    	]}],
		
    });
	
	$('#rogueTickets').highcharts({

        chart: {
        	marginTop: 20,
            type: 'pie',
            plotBorderWidth: 0,
            backgroundColor:null,
            height:180,
            // renderTo: 'totalDispatchedTickets',
        },

		title: {
            text: '<?php echo $imlow[0]['total']+$imaverage[0]['total']+$imhigh[0]['total']+$imcritical[0]['total']+$frlow[0]['total']+$fraverage[0]['total']+$frhigh[0]['total']+$frcritical[0]['total']; ?>',
            
            style: {
            	color:'#cccccc',
            	fontSize:'20px'
        	},
        	verticalAlign:'middle'
     	},

		subtitle: {
		  text: '',
		  style: {
		      display: 'none'
		  }
		},

		credits:{
          enabled:false
        },

       
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            dataLabels: {
	                enabled: false
	            },
	            showInLegend: false,
	            innerSize:'80%',
	            borderWidth: 0
	        }
	    },

       series: [{
		   name: 'Ticket Count',
            data: [
                {name:'IM', y:<?php echo $imlow[0]['total']+$imaverage[0]['total']+$imhigh[0]['total']+$imcritical[0]['total']; ?>, color:'#94ABA8'},
                {name:'FR', y:<?php echo $frlow[0]['total']+$fraverage[0]['total']+$frhigh[0]['total']+$frcritical[0]['total']; ?>, color:'#8c6694'}
    	]}]
    });
    //End Pie Charts

});
</script>


	<script>

		$(document).ready(function() {
			$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/getTicketlog',
			type: 'POST', // Send post data
			data: 'type=fetch',
			async: false,
			success: function(s){
				json_events = s;
			}
			});
			var dataSet = JSON.parse(json_events);
			
			var table = $('#example').DataTable( {
				"ajax": {
					"url": "<?php echo base_url(); ?>index.php/main/getTicketlog",
					"dataSrc": ""
				},
				"bFilter": false,
				"pageLength": 5,
				 "bLengthChange": false,
				// "autoWidth": true,
				"responsive": true,
				"columns": [
					{ "data": "tnum", "width": "10%" },
					{ "data": "title" },
					{ "data": "priority" }
				]
			} );
			setInterval( function () {
				table.ajax.reload( null, false ); // user paging is not reset on reload
			}, 10000 );
			
			//START STOP DISPATCHING
			$("#playStopButon").click(function(event) {
				event.preventDefault();
				var user_name = $("input#name").val();
				var password = $("input#pwd").val();
				jQuery.ajax({
					type: "POST",
					url: (document.getElementById('playStop').src == '<?php echo base_url();?>assets/images/icons/play.png') ? "<?php echo base_url(); ?>index.php/smtracker/startAssign/G.AACOE" : "<?php echo base_url(); ?>index.php/smtracker/stopAssign/G.AACOE",
					dataType: 'json',
					data: {name: user_name, pwd: password},
					success: function(res) {
						if (res)
						{
							// Show Entered Value
							jQuery("div#test").show();
							jQuery("div#value").html(res.username);
							jQuery("div#value_pwd").html(res.pwd);
						}
					}
				});
				
				if(document.getElementById('playStop').src == '<?php echo base_url();?>assets/images/icons/play.png'){
					document.getElementById('ifr').src='<?php echo base_url();?>index.php/smtracker/openTickets/G.AACOE/<?php echo $this->session->userdata('shortname'); ?>';
					document.getElementById('playStop').src='<?php echo base_url();?>assets/images/icons/stop.png';
				}
				else{
					document.getElementById('playStop').src='<?php echo base_url();?>assets/images/icons/play.png';
				}
			});
			$('iframe').load( function() {
				$('iframe').contents().find("head")
				  .append($("<style type='text/css'>  body { font-family: lucida console; color: #aca89a; font-size: 11px;	 overflow-x: hidden !important; }  </style>"));
			});
			//END START STOP DISPATCHING
			
		} );

	</script>
