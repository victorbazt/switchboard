<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Switchboard - Login</title>
 
    <!-- Bootstrap -->
    <link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/css/template.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

  </head>
  <body>
 
    <div class="container">
      <div class="row">

        <div class="col-md-4"></div>
        <div class="col-md-4">
          <div class="panel panel-primary">
            <div class="panel-heading pull-center"><img src="<?php echo base_url() ?>assets/images/hpeLogo.png" class="img-responsive center" width="40%"><h3>Switchboard</h3></div>
            
            <div class="panel-body">
			<form action="<?php echo base_url();?>index.php/pgldap/logincheck" autocomplete="off" method="post">
              <div class="form-group">
                <input type="text" class="form-control full-width login" id="username" name="pgusername" placeholder="P&G Username">
              </div>
              
              <div class="form-group">
                <input type="password" class="form-control full-width" id="password" name="pgpassword" placeholder="Password">
              </div>
			<?php 
			 $error = 0;
			 if(isset($_GET['e']))
				 $error = $_GET['e'];
			 if($error == 1)
				 echo '<span class="alert">Invalid Credentials</span>'; ?>
			  <br/>
			  <br/>
              <a href="<?php echo base_url() ?>home"><button type="submit" class="btn btn-primary center">Login</button></a>
			</form>
            </div> 
          </div>
        </div>
        <div class="col-md-4"></div>
      </div>
    </div>
 

    
    <script src="<?php echo base_url() ?>assets/js/vendor/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
  </body>

</html>