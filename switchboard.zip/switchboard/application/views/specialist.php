
<div class="container">			
				
	<p class="pull-right"><input type="button" class="btn btn-primary center" id="addSpecialist" onclick="addSpecialist();" value="ADD SPECIALIST" /></p>
	<div class="tables">
		<div class="bs-example widget-shadow row autopad" data-example-id="hoverable-table"> 
			
			<table id="example" class="table table-striped myTable text-left">
			<thead>
				<tr>
					<th>Shortname</th>
					<th>Wholename</th>
					<th>Email</th>
					<th>Region</th>
					<th>Row</th>
					<th>Status</th>
					<th></th>
				</tr>
			</thead>
			</table>
				
		</div>
	</div>
			
</div>
<div id="fullCalModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
				<span id="title"></span>
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                <h4 id="modalTitle" class="modal-title"></h4>
            </div>
            <div id="modalBody" class="modal-body">
			<form id="specialistform">
			<fieldset>
				<label for="shortname" class="settings-label">Shortname</label><br>
				<input type="text" id="shortname" name="shortname" class="form-control login"
						   value="" placeholder="LASTNAME.FN" />
			  </fieldset>
			  <fieldset>
				 <label for="shift" class="settings-label">Shift</label><br/>
				 <select class="form-control login" id="shift">
				   <option disabled selected value="">Select Shift</option>
				   
				 </select>
			  </fieldset> 
			  
			  <fieldset>
				 <label for="shift" class="settings-label">Keywords</label><br/>
				 
				 
				 <select name="rowapps[]" id="keywordnew" data-placeholder="Choose to Assign" multiple class="login uppercase form-control chosen-select" style="width:350px;">

					<option value=""></option>
					
				 </select>
			  </fieldset>
			  <div id="saved"></div
			  <input type="hidden" id="newtemp" name="newtemp" value="0" />
			  <fieldset><input type="button" id="submitspecialist" class="btn btn-primary center" onclick="SubmitForm();" data-dismiss="modal" value="Save" /></fieldset>
			  <script type="text/javascript">
				var config = {
				  '.chosen-select'           : {},
				  '.chosen-select-deselect'  : {allow_single_deselect:true},
				  '.chosen-select-no-single' : {disable_search_threshold:10},
				  '.chosen-select-no-results': {no_results_text:'No keyword Found!'},
				  '.chosen-select-width'     : {width:"95%"}
				}
				for (var selector in config) {
				  $(selector).chosen(config[selector]);
				}
			  </script>	
			</form>  
			</div>
        </div>
    </div>
</div>
		
		<script src="<?php echo base_url(); ?>assets/js/chosen.jquery.js" type="text/javascript"></script>
		<script>
		// $(document).ready(function(){
			// $('.myTable').DataTable({
				// "aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
				// "iDisplayLength": 5
			// });
			
		// });
		
		
		$(document).ready(function() {
			getShift();
			getKeyword();
			$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/getMyTeam',
			type: 'POST', // Send post data
			data: 'type=fetch',
			async: false,
			success: function(s){
				json_events = s;
			},
			error: function(e){		  
				console.log('a');
				revertFunc();
				alert('Error processing your request: '+e.responseText);
			}
			});
			var dataSet = JSON.parse(json_events);
			
			var table = $('#example').DataTable( {
				"ajax": {
					"url": "<?php echo base_url(); ?>index.php/main/getMyTeam",
					"dataSrc": ""
				},
				"columns": [
					{ "data": "shortname", "width": "10%" },
					{ "data": "wholename", "width": "10%" },
					{ "data": "email" },
					{ "data": "region" },
					{ "data": "row" },
					{ "data": "status", "width": "10%" },
					{ "data": "edit", "width": "10%", "className": "dt-body-center" }
				]
			} );
			setInterval( function () {
				table.ajax.reload( null, false ); // user paging is not reset on reload
			}, 10000 );
			
			dataTables();
			
		} );
		
		function dataTables(){
			
		}
		</script>
		
		<script>
		function addSpecialist(){
			$('#title').html('Add Specialist');
			$("#specialistform").trigger('reset');
			$('#shortname').prop('disabled', false);
			$('#shift').prop('selectedIndex', 0);
			$("#keywordnew").val('').trigger("chosen:updated");
			
			document.getElementById('submitspecialist').value = 'SAVE';
			console.log($('#submitspecialist').val());
			
			$('#fullCalModal').modal();
			//Override model's auto-generated div container as it always uses 0 width
			document.getElementById("keywordnew_chosen").style.width = "100%";
		}
		
		function updateSpecialist(shortname){
			
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/getSpecialist/'+shortname,
				type: 'POST', // Send post data
				data: 'nothing=null',
				async: false,
				success: function(s){
					specialist = s;
				},
				error: function(e){		  
					console.log('a');
					revertFunc();
					alert('Error processing your request: '+e.responseText);
				}
			});
			$('#title').html('Edit Specialist');
			$('#shortname').val(shortname);
			$('#shortname').prop('disabled', true);
			specialist = specialist.split('*');
			shift = specialist[0];
			$('#shift').val(shift);
			keywords = specialist[1].slice(1,-1);
			keywords = keywords.split('][');
			$("#keywordnew").val(keywords).trigger("chosen:updated");
			
			document.getElementById('submitspecialist').value = 'UPDATE';
			console.log($('#submitspecialist').val());
			
			$('#fullCalModal').modal();
			//Override model's auto-generated div container as it always uses 0 width
			document.getElementById("keywordnew_chosen").style.width = "100%";
		}
		
		function SubmitForm(){
			var shortname = $('#shortname').val();
			var shift = $('#shift').val();
			var keywordnew = new Array();
			keywordnew = $('#keywordnew').chosen().val();
			var keyword = '';
			
			if(keywordnew != null){
				for(a=0;a<keywordnew.length;a++){
					if(a != 0)
						keyword = keyword+','+keywordnew[a];
					else
					keyword = keywordnew[a];
				}
			}
			
			if(shortname != ''){
				$.ajax({
					url: '<?php echo base_url(); ?>index.php/main/getPGDetails/'+shortname,
					type: 'POST', // Send post data
					data: 'nothing=null',
					async: false,
					success: function(s){
						pgdetails = s;
					},
					error: function(e){		  
						console.log('a');
						revertFunc();
						alert('Error processing your request: '+e.responseText);
					}
				});
				if(pgdetails != ''){
					pgdetails = pgdetails.split(',');
					var email = pgdetails[0];
					var wholename = pgdetails[1];
					var type = $('#submitspecialist').val();
					
					$.post("<?php echo base_url(); ?>index.php/main/updateSpecialist", { shortname: shortname, shift: shift, keywordnew: keyword, email: email, wholename: wholename, type: type },
					function(data) {
					//change to notif modal
						alert(data);
					 $('#saved').html(data);
					});
					
				}
				else{
					//change to notif modal
					alert('Invalid P&G shortname');
				}
			}
		}
		
		function getKeywords(){
		
			$('#keyword').tagsinput('add', keywords);
		}
	
		function getShift(){
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/getRegions',
				type: 'POST', // Send post data
				data: 'nothing=null',
				async: false,
				success: function(s){
					shift = s;
				}
			});
			shift = shift.split(',');
			var select = document.getElementById('shift');
			
			for(a=1;a<shift.length;a++){
				var opt = shift[a];
				var el = document.createElement('option');
				el.textContent = opt;
				el.value = opt;
				select.appendChild(el);
			}
		}
		
		function getKeyword(){
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/getKeyword',
				type: 'POST', // Send post data
				data: 'nothing=null',
				async: false,
				success: function(s){
					keyword = s;
				}
			});
			keyword = keyword.split(',');
			var select = document.getElementById('keywordnew');
			
			for(a=1;a<keyword.length;a++){
				$('#keywordnew').append('<option value="'+keyword[a]+'">'+keyword[a]+'</option>');
			}
			$("#keywordnew").trigger("chosen:updated");
		}
		</script>
		
		
		
		
		
		
		
		
		
		