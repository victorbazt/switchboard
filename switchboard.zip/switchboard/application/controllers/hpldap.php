<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hpldap extends CI_Controller {

	/**
	 *	HPE LDAP in CodeIgniter PHP.
	 *	Author: adrian-lester.tan@hpe.com
	 **/
	 public function __construct(){
			parent::__construct();
			
	 }
	
	/*
	*	HPE LDAP Auth.
	*	Due to HPE's policy that all bindings need to go through the secured ldap 	
	*	protocol, we have to switch ldap url. To pass through this url, you need the ff:
	*
	*	1. Enroll for HPE certificate
	*	2. Create openldap.conf in C:/openldap folder to point to the .pem file
	*
	*	To save you the problem getting all these set up, the server c4w13939 will 
	*	already bind with these conditions when you give POST data to it username and
	*	password. No credentials are stored in this server.
	*
	*	Return: Array object of user when authenticated
	*/
	function auth(){
		$email = '';
		$password = '';
		$url = 'https://c4w13939.americas.hpqcorp.net/public/ldapservice.php';
		//constructing of post data
		$fields = "user=".urlencode($email).'&'."password=".urlencode($password);

		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //this option is important for us to get the json string
		curl_setopt($ch,CURLOPT_POST, true);
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));

		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);

		$result = curl_exec($ch);
		//close connection
		curl_close($ch);

		echo $result;
		
	}
	
	/*
	*	HPE LDAP search by email
	*	Return: JSON Encoded data for  
	*/
	function search($empID){
		
		$conn = ldap_connect('ldap://hpe-pro-ods-ed.infra.hpecorp.net')
		or die ("failed to connect to HPE LDAP");
		
		$username = 'adrian-lester.tan@hpe.com';
		$ldaprootdn = "ou=People,o=hp.com";
		$result = ldap_search( $conn, $ldaprootdn,"(employeeNumber=$empID)" );
		$d = ldap_get_entries($conn, $result)[0];
		$entry = array();
		foreach($d as $key => $value){
			$entry[$key]= utf8_encode($d[$key][0]);
		}
		echo json_encode($entry);
		
	}
	
}
