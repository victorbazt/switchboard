<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pgldap extends CI_Controller {

	/**
	 *	P&G LDAP in CodeIgniter PHP.
	 *	Author: adrian-lester.tan@hpe.com
	 *	
	 *	trueEmail: this is a new data pushed in the LDAP object in which this is  the extracted email address set by 3rd parties that don't have inboxes and have auto-forwarding service to their corporate email adds instead. 
	 **/
	 public function __construct(){
			parent::__construct();
			$this->load->model('pgldap_model');			
			$this->load->model('main_model');			
			$this->load->model('security_model');			
			$this->load->helper('url');
			$this->load->library('session');
			
	 }
	
	
	public function index()
	{
		if($this->session->userdata('shortname')){
			redirect('main/Dashboard');
		}
		else
		$this->load->view('login');
	}
	
	/*
	*	P&G LDAP bind (auth) by Shortname and Password
	*	Return: full ldap object of the first result 
	*/
	function auth(){
		
		print_r($this->pgldap_model->auth('perez.jv',''));
	}
	
	/*
	*	P&G LDAP search by shortname
	*	Return: full ldap object of the first result 
	*/
	function search(){
		var_dump($this->pgldap_model->pgldap_search('tan.a'));
	}
	
	function logincheck(){
		
		$username = strtolower($this->input->post('pgusername'));
		$password = $this->input->post('pgpassword');
		
		// prod login
		// $pgshortname = $this->pgldap_model->auth($username, $password);
		
		// test login
		$pgshortname = $this->pgldap_model->pgldap_search($username);
		
		
		if(($username == $pgshortname['extshortname'][0]) && ( strtolower($this->main_model->getUserProfile($username, 'shortname')) == $pgshortname['extshortname'][0])){
			$this->session->set_userdata('shortname', $username);
			$this->session->set_userdata('wholename', $pgshortname['cn'][0]);
			if(isset($pgshortname['extnotifyaddress'][0]))
				$this->session->set_userdata('email', $pgshortname['extnotifyaddress'][0]);
			else
				$this->session->set_userdata('email', $pgshortname['mail'][0]);
			
			$this->main_model->savePassword($username, $password);
			
			
			
			redirect("main/Dashboard");
		}
		else
			redirect('login?e=1');
	}
	
}
