<style type='text/css'>  body { font-family: lucida console; color: #ffffff; font-size: 11px;	 overflow-x: hidden !important; }  </style>
<script> function pageScroll(){window.scrollBy(0,10); scrolldelay = setTimeout('pageScroll()',1350); }pageScroll(); </script>
<br/><br/>
<p>Switchboard is currently running in the background..</p>
<p>Live Logs has been disabled due to page refresh.</p>
<p>Please Restart the Dispatching in Order to view Live Logs.</p>