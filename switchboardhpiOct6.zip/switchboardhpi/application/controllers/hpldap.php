<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hpldap extends CI_Controller {

	/**
	 *	HPE LDAP in CodeIgniter PHP.
	 *	Author: adrian-lester.tan@hpe.com
	 **/
	 public function __construct(){
			parent::__construct();
			$this->load->helper('url');
			$this->load->library('session');
			$this->load->library('encrypt');
			$this->load->model('main_model');
			$this->load->model('security_model');
			
	 }
	
	/*
	*	HPE LDAP Auth.
	*	Due to HPE's policy that all bindings need to go through the secured ldap 	
	*	protocol, we have to switch ldap url. To pass through this url, you need the ff:
	*
	*	1. Enroll for HPE certificate
	*	2. Create openldap.conf in C:/openldap folder to point to the .pem file
	*
	*	To save you the problem getting all these set up, the server c4w13939 will 
	*	already bind with these conditions when you give POST data to it username and
	*	password. No credentials are stored in this server.
	*
	*	Return: Array object of user when authenticated
	*/

	public function index()
	{
		if($this->session->userdata('email')){
			redirect('main/Dashboard');
		}
		else
		$this->load->view('login');
	}

	function logincheck(){
		
		$email = strtolower($this->input->post('hpemail'));
		$password = $this->input->post('hppassword');

		$hpldap = $this->auth($email, $password);

		if($hpldap != 'UNAUTHORIZED' && $hpldap != ''){
			// $wholename = $this->search($email);
			// $this->session->set_userdata('wholename', $wholename);
			$this->session->set_userdata('email', $email);

			//encrypt password
			$password = $this->encrypt->encode($password);
			$this->main_model->savePassword($email, $password);

			redirect("main/Dashboard");
		}
		else
			redirect('login?e=1');

	}

	function auth($email, $password){
		// $email = 'john-victor-o.perez@hpe.com';
		// $password = '';
		$url = 'https://c4w13939.americas.hpqcorp.net/public/ldapservice.php';
		//constructing of post data
		$fields = "user=".urlencode($email).'&'."password=".urlencode($password);

		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //this option is important for us to get the json string
		curl_setopt($ch,CURLOPT_POST, true);
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));

		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);

		$result = curl_exec($ch);
		//close connection
		curl_close($ch);

		return $result;
		
	}
	
	/*
	*	HPE LDAP search by email
	*	Return: JSON Encoded data for  
	*/
	function search($email){
		
		$conn = ldap_connect('ldap://hpe-pro-ods-ed.infra.hpecorp.net')
		or die ("failed to connect to HPE LDAP");
		
		$username = 'john-victor-o.perez@hpe.com';
		$ldaprootdn = "ou=People,o=hp.com";
		$result = ldap_search( $conn, $ldaprootdn,"(uid=$email)" );
		$d = ldap_get_entries($conn, $result)[0];
		$entry = array();
		foreach($d as $key => $value){
			$entry[$key]= utf8_encode($d[$key][0]);
		}
		// echo json_encode($entry);
		return $entry['hplegalname'];
		
	}
	
}
