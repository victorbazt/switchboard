<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class smtracker extends CI_Controller {

	
	 public function __construct(){
			ini_set('max_execution_time', 3000000);
			date_default_timezone_set("Asia/Singapore");
			parent::__construct();
			$this->load->helper('url');
			$this->load->model('smtracker_model');
			$this->load->library('encrypt');
			
			
	 }
	 
	 function myFunction($myParameter){
		 echo $myParameter;
	 }

	 function decoder(){
	 	$pass = $this->encrypt->decode('aYPMmMg9bXTv5MUp8jNSJKzFoNYAdhWLfd+xSxvFfLm6F7HMF+vsUrBf6JXfHQXCqKYd9ywgEReEULjgHeqnLw==');
	 	echo $pass;
	 }
	 
	 function allAG($target){
	 	var_dump($this->smtracker_model->getAllAG($target));
	 }

	 function searchKeyword($keywords, $haystack){
	 	// $keywords = $this->smtracker_model->getAllAG('TITLE');

	 	$titleorCI = ' '.strtolower($haystack);
	 	$match = 0;
	 	$keylength = 0;
	 	$assignmentGroup[0] = FALSE;
	 	$assignmentGroup[1] = '';
	 	foreach($keywords as $key){
	 		$keys = explode(',', $key['keywords']);
	 		$tempmatch = 0;
	 		$templength = 0;
	 		$mismatch = 0;
	 		foreach($keys as $explodedkeys){
	 			$explodedkeys = strtolower(trim($explodedkeys));
	 			if(strpos($titleorCI, $explodedkeys)){
	 				$tempmatch++;
	 				$templength = strlen($explodedkeys);
	 			}
	 			else{
	 				$mismatch = 1;
	 			}
	 			// echo $explodedkeys;
	 		}
	 		if(($tempmatch > $match && $mismatch != 1) || ($tempmatch == $match && $mismatch != 1 && $templength > $keylength)){
	 			$match = $tempmatch;
	 			$keylength = $templength;
	 			$assignmentGroup[0] = $key['assignment_group'];
	 			$assignmentGroup[1] = $key['group_name'];
	 			$assignmentGroup[2] = $key['keywords'];
	 			$keyword = $key['keywords'];
	 		}
	 		// echo $key['keyword'];
	 		// echo '<br/>';
	 	}
	 	return $assignmentGroup;
	 }

	 // function allTitleKeyword(){
	 // 	// var_dump($this->smtracker_model->getAllTitleKeyword());
	 // 	$keywords = $this->smtracker_model->getAllTitleKeyword();
	 // 	$title = ' '.strtolower('MCDFC-EDW Load:something:');
	 // 	$match = 0;
	 // 	$nextworkgroup = '';
	 // 	$groupName = '';
	 // 	foreach($keywords as $key){
	 // 		$keys = explode(',', $key['keywords']);
	 // 		$tempmatch = 0;
	 // 		$mismatch = 0;
	 // 		foreach($keys as $explodedkeys){
	 // 			$explodedkeys = strtolower(trim($explodedkeys));
	 // 			if(strpos($title, $explodedkeys)){
	 // 				$tempmatch++;
	 // 			}
	 // 			else{
	 // 				$mismatch = 1;
	 // 			}
	 // 			// echo $explodedkeys;
	 // 		}
	 // 		if($tempmatch > $match && $mismatch != 1){
	 // 			$match = $tempmatch;
	 // 			$nextworkgroup = $key['assignment_group'];
	 // 			$groupName = $key['group_name'];
	 // 			$keyword = $key['keywords'];
	 // 		}
	 // 		// echo $key['keyword'];
	 // 		// echo '<br/>';
	 // 	}
	 // 	echo $nextworkgroup;
	 // 	echo $groupName;
	 // 	echo $keyword;
	 // }
	 
	 
	function openTickets($team, $username){
		  echo "<style type='text/css'>  body { font-family: lucida console; color: #eeeeee; font-size: 11px;	 overflow-x: hidden !important; }  </style>";
		 echo "<script> function pageScroll(){window.scrollBy(0,10); scrolldelay = setTimeout('pageScroll()',1350); }pageScroll(); </script>";
		 //Check if someone started Dispatching already
		if($this->smtracker_model->getSettings($team, 'start') == '1'){
		 	echo '<script> window.top.location.reload(); </script>';
		 	exit;
		 }

		$this->startAssign($team);
		$this->startRun($username);
		$start = $this->smtracker_model->setting("start", $team);

		//IIM URL's
		$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
		
		//function for USORT
		function cmp($a, $b){
			return $a[3] - $b[3];
		}

		while($start == 1){
			$runtime_start = strtotime(date('H:i:s'));
			echo '['.date('h:i:sA').']<br/>';
			echo 'Switchboard running. . .<br/><br/>	';
			echo '<br/>Logging-in to SM...<br/><br/>';
			
			$this->flush_buffers();

			$password = $this->smtracker_model->getUserProfile($username, 'password');
			$password = $this->encrypt->decode($password);
		 	$hpsmlogin_url = FCPATH."\Macros\HPSM LOGIN.iim";
			$iim1 = new COM("imacros");
			$s=$iim1->iimOpen("-runner",TRUE);
			$s = $iim1->iimSet("user", $username); //SM9 user
			$s = $iim1->iimSet("password", $password);     //SM9 password
			$s = $iim1->iimPlay($hpsmlogin_url);
			if($s > 0) { //Checks if an error was encountered before clicking on Login
				$message = $iim1->iimGetLastExtract();
				if ($message == "#EANF#[EXTRACT]") //Checks if page loaded. If #EANF# was returned, it means that element was not found in page within 60 secs.
				{
					$s = $iim1->iimPlay("QuickLogout.iim"); //Perform forced logout
					$s = $iim1->iimClose();
				}
				else{
					//Login Successful. Continue code.
				}
			}
			else { 
				echo $iim1->iimGetLastError;
				$s = $iim1->iimClose();
				echo "<br/>Error encountered during login."; 
				return FALSE;
				} //Error was encountered before or during clicking of Login.

			
			if($this->checkStart($team) == FALSE){
				$s = $iim1->iimPlay($logout_url);
				$s = $iim1->iimClose();
				return FALSE;
			}

			$runtime = strtotime(date('H:i:s')) - $runtime_start;
			if($runtime > 600){
				$s = $iim1->iimPlay($logout_url);
				$s = $iim1->iimClose();
				echo ($runtime/60).' mins. has passed since last Extraction of Open Ticket.<br/><br/>Switchboard will Extract Again.<br/><br/>';
				continue;
			}

			echo 'extracting IM tickets<br/>Please Wait. . .<br/><br/>	';
			$this->flush_buffers();

		//SAVE MY AG UNASSIGNED INCIDENTS AS CSV
			$folderpath = FCPATH;
			$s = $iim1->iimSet("folder",$folderpath); 
			$extractim_url = FCPATH."\Macros\HPSM EXTRACTIM.iim";
			$s = $iim1->iimPlay($extractim_url);

			if($s < 0){
				echo $s;
				echo $iim1->iimGetLastError;
				$s = $iim1->iimClose();
				return FALSE;
			}
		//END SAVE

			$workgroup = $this->smtracker_model->getWorkgroup($team);
			$stop = $this->smtracker_model->setting("stop", $team);

			if(($stop == 0) && ($start == 1)){

				$handle = fopen(FCPATH."OPEN-TICKETS.csv", "r");
				$i=0; 
				while (($data = fgetcsv($handle, 5000, ",")) !== FALSE) 
				{
					$csvrow = print_r($data, true);
					$tickets[$i] = $data;
					$i+=1;
				}
				fclose($handle);
				$max = '1';
				if($tickets[1][0] != '')
				{
					$max = count($tickets);
				}
				echo '['.date('h:i:s A').'] Extracted a total of '.($max-1).'  Open IM ticket/s.<br/><br/>';
				$this->flush_buffers();

				//Notify Logged in user if Extracted ticket is > 50
				if($max > 51){
					$this->smtracker_model->Send_Mail($username, 'Alert: '.($max-1).' Incidents to be Dispatched ', '<p style="font-size:15px;font-family:Arial">To: '.$username.'<br/><br/>Please be advised that there are '.($max-1).' incidents waiting to be dispatched. Check if mass update access is needed ASAP.<br/><br/>This is an automatically generated message. Please do not reply to this e-mail.</p>');
				}

				if($this->checkStart($team) == FALSE){
					$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
					$s = $iim1->iimPlay($logout_url);
					$s = $iim1->iimClose();
					return FALSE;
				}

				usort($tickets, "cmp");	
				if($max-1 > 0){	//if zero extracted ticket
					if($max > 11)
						$max = 11;								//limit to 10 tickets
					// for($a=1; $a<count($tickets);$a++){			
					for($a=1; $a<$max;$a++){			//limit to 10 tickets

						$runtime = strtotime(date('H:i:s')) - $runtime_start;
						if($runtime > 600){
							$s = $iim1->iimPlay($logout_url);
							$s = $iim1->iimClose();
							echo ($runtime/60).' mins. has passed since last Extraction of Open Ticket.<br/><br/>Switchboard will Extract Again.<br/><br/>';
							$a = $max;
							continue;
						}

						//update assignee shift
						$this->smtracker_model->updateAssigneeShift('G.AACOE');
						$shift = $this->getCurrentRegion('G.AACOE');
						$category = 'IM';
						$tnum = $tickets[$a][0];
						$ci = $tickets[$a][1];
						$title = ' '.$tickets[$a][2];
						// $rtitle = ' '.preg_replace('/[^A-Za-z0-9]/', ' ', $title);
						$priority = $tickets[$a][3];
						$status = $tickets[$a][4];
						$targetdate = $tickets[$a][7];
						$nextassignee = '';
						$type = '';

						if(!($priority  == '1 - Top' || $priority  == '2 - High' || $priority  == '3 - Medium' || $priority  == '4 - Low' )){
							echo '<br/>Columns on the Queue not in proper order.<br/>';
							continue;
						}
						echo '<br/>['.date('h:i:sA').']';
						echo '<br/>Processing ticket #'.$a.'..<br/>';
						$this->flush_buffers();

						//SEARCH FOR SPECIFIC TICKET
						$iim1 = new COM("imacros");				//delete this after testing
						$s = $iim1->iimOpen("-runner", FALSE);	//delete this after testing
						$searchticket_url = FCPATH."\Macros\HPI_SearchTicket.iim";
						$s = $iim1->iimSet("ticketnum", $tnum);
						$s = $iim1->iimPlay($searchticket_url);

						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						//END SEARCH FOR SPECIFIC TICKET 
						// $assignee = 'john-victor-o.perez@hpe.com';

						if($this->checkStart($team) == FALSE){
							$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
							$s = $iim1->iimPlay($logout_url);
							$s = $iim1->iimClose();
							return FALSE;
						}

				//ERROR HANDLING
						//READ THE SAVE AND EXIT(If not present Ticket has been assigned already)
						$readsaveandexit_url = FCPATH."\Macros\HPSM READ SAVE AND EXIT.iim";
						$s = $iim1->iimPlay($readsaveandexit_url); //Extract ticket details [STEP 2]
						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						$saveandexittext = $iim1->iimGetLastExtract();
						if($saveandexittext == '#EANF#[EXTRACT]'){
							//CANCEL OPENED TAB
							$cancel_url = FCPATH."\Macros\HPSM CANCEL.iim";
							$s = $iim1->iimPlay($cancel_url);
							$s = $iim1->iimPlay($cancel_url);		//delete after testing the run without save
							if($s < 0){
								echo $s;
								echo $iim1->iimGetLastError;
								$s = $iim1->iimClose();
								$this->flush_buffers();
								return FALSE;
							}
							//END CANCEL OPENED TAB
							echo '<br/>'.$tnum.'has been dispatched manually by other Person.';
							echo '<br/><br/>Cancelling Assignment of this Ticket.<br/>';
							continue;
						}

						//READ POPUP MODAL
						$readpopup_url = FCPATH."\Macros\HPSM READ POPUP.iim";
						$s = $iim1->iimPlay($readpopup_url); //Extract ticket details [STEP 2]
						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						$popuptext = $iim1->iimGetLastExtract();
						if($popuptext != '#EANF#[EXTRACT]'){
							//CANCEL OPENED TAB
							$cancel_url = FCPATH."\Macros\HPSM CANCEL.iim";
							$s = $iim1->iimPlay($cancel_url);
							$s = $iim1->iimPlay($cancel_url);		//delete after testing the run without save
							if($s < 0){
								echo $s;
								echo $iim1->iimGetLastError;
								$s = $iim1->iimClose();
								$this->flush_buffers();
								return FALSE;
							}
							//END CANCEL OPENED TAB
							echo '<br/>'.$tnum.'is currently locked by other Person.';
							echo '<br/><br/>Cancelling Assignment of this Ticket.<br/>';
							continue;
						}


				//END ERROR HANDLING

						if($this->checkStart($team) == FALSE){
							$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
							$s = $iim1->iimPlay($logout_url);
							$s = $iim1->iimClose();
							return FALSE;
						}

						//EXTRACT FOR TICKET DETAILS
						$extractdetails_url = FCPATH."\Macros\HPSM EXTRACT IM DETAILS.iim";
						$s = $iim1->iimPlay($extractdetails_url); //Extract ticket details [STEP 2]
						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						//END EXTRACT FOR TICKET DETAILS

						$ticketDetails = $iim1->iimGetLastExtract();	//SET EXTRACTED TICKET DETAILS TO VAR
						list($CI,$workgroup,$assignee,$affectedItem,$subCat,$product,$prodSpec,$issueType) = explode("[EXTRACT]",$ticketDetails);


					//NEW LOGIC: 
					//1. SEARCH KEYWORDS ON TITLE
						$searchKeyword = $this->searchKeyword($this->smtracker_model->getAllAG('TITLE'), $title);
			//NEW LOGIC FROM GLEN
						if($workgroup == 'W-INCFLS-ESAPS-GSCS-AMOS'){
							$nextworkgroup = 'W-INCFLS-ESAPS-GSCS-DISPATCH';
						}
						else{
							$nextworkgroup = $searchKeyword[0];
						}
						$groupName = $searchKeyword[1];
					// 	if($nextworkgroup == FALSE){
					// //2. SEARCH CI TO AG DIRECT MAPPING
					// 		$nextworkgroup = $this->smtracker_model->getAssignmentGroup($CI, 'assignment_group');	//GET WORKGROUP BASED ON CI
					// 	}
					//3. SEARCH KEYWORDS ON TICKET CI
						if($nextworkgroup == FALSE){
							$searchKeyword = $this->searchKeyword($this->smtracker_model->getAllAG('CI'), $ci);
							$nextworkgroup = $searchKeyword[0];
							$groupName = $searchKeyword[1];
						}

						if($nextworkgroup != FALSE){		//CI TO WORKGROUP FOUND. LOOK FOR ASSIGNEE
							// $groupName = $this->smtracker_model->getAssignmentGroup($CI, 'group_name');
							$nextassignee = $this->smtracker_model->minIMTicket($groupName, $shift);
							if($nextassignee == TRUE){
								$condition = 4;			//SET TO NEXT WORKGROUP AND NEXT ASSIGNEE
							}
							else{						//IF NO ASSIGNEE ON SPECIFIC WORKGROUP
								$nextassignee = ''; //LEAVE ASSIGNEE BLANK
							}
							// echo 'NEXT WORKGROUP: '.$nextworkgroup.'<br/>';
							// echo 'NEXT ASSIGNEE: '.$nextassignee;
							echo '<br/>Keyword/s found: '.$searchKeyword[2].'<br/>';
						}
						else{							//NO CI TO WORKGROUP FOUND. OWN THE Ticket
							$type = 'Rogue';
							$nextworkgroup = $workgroup;
							$nextassignee = $username; //LOGGED IN USER WHO STARTED DISPATCHING
							$condition = 6;				//OWN THE TICKET
						}

						//0. update all the fields before owning.
						if($affectedItem == '')
							$affectedItem = 'om';
						if($subCat == 'select area')
							$subCat = 'application';
						if($product == '')
							$product = 'functionality';
						if($prodSpec == 'rarchy>')
							$prodSpec = '';
						if($issueType == 'rarchy>')
							$issueType = '';
					//SET OTHER FIELDS BEFORE OWNING
						$setremainingdetails_url = FCPATH."\Macros\HPSM SET REMAINING DETAILS.iim";
						$s = $iim1->iimSet("affecteditem", $affectedItem);
						$s = $iim1->iimSet("subcat", $subCat);
						$s = $iim1->iimSet("product", $product);
						$s = $iim1->iimSet("prodspec", $prodSpec);
						$s = $iim1->iimSet("issuetype", $issueType);
						$s = $iim1->iimPlay($setremainingdetails_url);

						if($this->checkStart($team) == FALSE){
							$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
							$s = $iim1->iimPlay($logout_url);
							$s = $iim1->iimClose();
							return FALSE;
						}

					//1. Own/Set assignee first if ticket is Open
						//SET ASSIGNEE
						$setassignee_url = FCPATH."\Macros\HPSM SET ASSIGNEE.iim";
						//OWN TICKET FIRST IF OPEN
						if($status == 'Open'){
							$s = $iim1->iimSet("assignee", $username);		
							$s = $iim1->iimPlay($setassignee_url);
							$save_url = FCPATH."\Macros\HPSM SAVE.iim";
							// $s = $iim1->iimPlay($save_url);		//remove when dev mode
						}

						if($this->checkStart($team) == FALSE){
							$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
							$s = $iim1->iimPlay($logout_url);
							$s = $iim1->iimClose();
							return FALSE;
						}
						
					//1.2 get TTO
						//READ POPUP MODAL
						$getTTO_url = FCPATH."\Macros\HPSM GET TTO.iim";
						$s = $iim1->iimPlay($getTTO_url); //Extract ticket details [STEP 2]
						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						$tto = $iim1->iimGetLastExtract();


						$s = $iim1->iimSet("assignee", $nextassignee);	//REAL ASSIGNEE
						$s = $iim1->iimPlay($setassignee_url);

						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						//END SET ASSIGNEE

				//NEW LOGIC FROM GLEN
						if($workgroup == 'W-HPE-INCFLS-ESAPS-GSCS-CRITJOBS'){
							$nextworkgroup = 'W-HPE-INCFLS-ESAPS-GSCS-CRITJOBS';
						}


					//3. check if condition 6 to skip the changing of assignment group.
						if($condition != 6){
							$assignmentgroup_url = FCPATH."\Macros\HPSM SET ASSIGNMENT GROUP.iim";
							$s = $iim1->iimSet("nextworkgroup", $nextworkgroup);
							$s = $iim1->iimPlay($assignmentgroup_url);
						}	
					//4. Set Checkbox and New Update
						$checkboxandupdate_url = FCPATH."\Macros\HPSM SET CHECKBOX AND UPDATE.iim";
						$s = $iim1->iimSet("nextworkgroup", $nextworkgroup);
						$s = $iim1->iimPlay($checkboxandupdate_url);

					//5. Save and Exit.
						$saveandexit_url = FCPATH."\Macros\HPSM SAVE AND EXIT.iim";
						// $s = $iim1->iimPlay($saveandexit_url);	//remove when dev mode


						//CANCEL OPENED TAB
						$cancel_url = FCPATH."\Macros\HPSM CANCEL.iim";
						$nochanges_url = FCPATH."\Macros\HPSM DO NOT SAVE CHANGES.iim";
						$s = $iim1->iimPlay($cancel_url);
						$s = $iim1->iimPlay($nochanges_url);	//delete after testing the run without save
						$s = $iim1->iimPlay($cancel_url);		//delete after testing the run without save
						if($s < 0){
							echo $s;
							echo $iim1->iimGetLastError;
							$s = $iim1->iimClose();
							$this->flush_buffers();
							return FALSE;
						}
						//END CANCEL OPENED TAB

						// echo '<br/><br/>Affected CI: '.$CI.' <br/>Workgroup: '.$workgroup.' <br/>Assignee: '.$nextassignee.' <br/>Affected Service: '.$affectedItem.' <br/>Area: '.$subCat.' <br/>Subarea: '.$product.' <br/>Product Specifics: '.$prodSpec.' <br/>Issue Type: '.$issueType.'<br/>';
						// echo '<br/>Ticket:'.$tnum.' CI:'.$ci.' Title:'.$title.' Priority:'.$priority.' Status:'.$status.'<br/><br/>';
					
						echo '<br/>TICKET: '.$tnum.'<br/><br/>AG: '.$nextworkgroup.'<br/><br/>ASSIGNEE: '.$nextassignee.'<br/><br/><br/>';
						// $specialist = 'john-victor-o.perez@hpe.com';
						$team = 'G.AACOE';

						sleep(1);

					//EMAIL ASSIGNEE
						if($nextassignee == 'john-victor-o.perez@hpe.com')
						$this->smtracker_model->Send_Mail($nextassignee, 'Assigned to you: '.$tnum.' - Priority: '.$priority, '<p style="font-size:15px;font-family:Arial">To: '.$nextassignee.'<br/><br/>Please be advised that the following incident has been assigned to you:<br/><br/><b>Incident ID: </b>'.$tnum.'<br/><b>Title: </b>'.$title.'<br/><b>Priority: </b>'.$priority.'<br/><b>Affected CI: </b>'.$CI.'<br/><b>Assignment Group: </b>'.$nextworkgroup.'<br/><br/>This is an automatically generated message. Please do not reply to this e-mail.</p>');

						$this->smtracker_model->addTickets($tnum, $team, $CI, $nextworkgroup, $category, $title, $priority, $nextassignee, $targetdate, 'Accepted', $type, $tto);
						$this->flush_buffers();
					}
				}
				
				if($runtime > 600){
					continue;
				}
				sleep(2);
				$logout_url = FCPATH."\Macros\HPSM LOGOUT.iim";
				$s = $iim1->iimPlay($logout_url);
				$s = $iim1->iimClose();

				if($s < 0){
					echo $s;
					echo $iim1->iimGetLastError;
					$s = $iim1->iimClose();
					$this->flush_buffers();
					return FALSE;
				}

				echo '<br/><br/>Logged Out in SM9.<br/><br/>	';
				$this->flush_buffers();

				$timeout = $this->smtracker_model->setting("timeout", $team);
				 
				 $nextdispatch = strtotime(date("Y-m-d H:i:s"));
				 $nextdispatch = $nextdispatch+$timeout;
				 $nextdispatch = date("h:i:sA", $nextdispatch);
				 echo '<br/><br/>Next Dispatch at '.$nextdispatch.'<br/><br/><br/>';
				 
				 $this->flush_buffers();
				 
				 $start = $this->smtracker_model->setting("start", $team);
				 for($a=0;$a<$timeout;$a+=5){
					sleep(5);
					if($this->checkStart($team) == FALSE){
						return FALSE;
					}
				 }
				 
			}
			else{
				 if($start == 1)
				 sleep(1);
			}
		}
		
	 }

	 function sampleemail(){
	 	$nextassignee = 'john-victor-o.perez@hpe.com';
	 	$tnum = 'IM1234567';
	 	$priority = '2 - High';
	 	$CI = 'hpit:velocity:sample';
	 	$nextworkgroup = 'SAMPLE-WORKGROUP-SAMPLE';

	 	$this->smtracker_model->Send_Mail($nextassignee, 'Assigned to you: '.$tnum.' - Priority: '.$priority, '<p style="font-size:16px;font-family:Arial">To: '.$nextassignee.'<br/><br/>Please be advised that the following incident has been assigned to you:<br/><br/><b>Incident ID: </b>'.$tnum.'<br/><b>Title: </b>'.$title.'<br/><b>Priority: </b>'.$priority.'<br/><b>Affected CI: </b>'.$CI.'<br/><b>Assignment Group: </b>'.$nextworkgroup.'<br/><br/>This is an automatically generated message. Please do not reply to this e-mail.</p>');
	 }
	 
	 
	function getOpenIM($team){

		$ticketdetails = array();
		unset($ticketdetails);
					
		$extract_url = FCPATH."\Macros\ExtractTIckets.iim";
		
		ob_start(); ?>
		
		VERSION BUILD=10022823
		SET EXTRACT_TEST_POPUP NO
		SET !TIMEOUT_PAGE 120
		TAB T=1
		TAB CLOSEALLOTHERS
		TAB OPEN
		TAB T=2
		'extract Incident Ticket
		URL GOTO=http://smtracker.pg.com/pls/smtracker/pg_tracker.inc_groups?i_group=G.AACOE
		TAG POS=1 TYPE=TABLE ATTR=* EXTRACT=TXT
		TAB T=1
		TAB CLOSEALLOTHERS
		
		
		<?php
		$extractticket = ob_get_clean();
		
		
		
		$iimextractTicket = "
		VERSION BUILD=10022823
		SET EXTRACT_TEST_POPUP NO
		TAB T=1
		TAB CLOSEALLOTHERS
		TAB OPEN
		TAB T=2
		'extract Incident Ticket
		URL GOTO=http://smtracker.pg.com/pls/smtracker/pg_tracker.inc_groups?i_group=".$team."
		TAG POS=1 TYPE=TABLE ATTR=* EXTRACT=TXT
		TAB T=1
		TAB CLOSEALLOTHERS";
		
		$iim1 = new COM("imacros");
		$s = $iim1->iimOpen("-runner -kioskmode -tray", TRUE);
		$s = $iim1->iimSet("workgroup","$team");
		$s = $iim1->iimPlay($extract_url);
		// $s = $iim1->iimPlayCode($extractticket);
		
		if($s > 0){
		$tickets = $iim1->iimGetLastExtract();
		$s = $iim1->iimClose();
		$tickets = str_replace('[EXTRACT]', '', $tickets);
		$ticket = explode("#NEWLINE#", $tickets);
		
		foreach($ticket as $key => $ticks){
			$tdetails = explode("#NEXT#", $ticks);
			$ticketdetails[$key] = $tdetails;
		}
		return $ticketdetails;
		
		}
		else{
			echo $iim1->iimGetLastError;
			$s = $iim1->iimClose();
			echo '<br/>Failed to Extract Ticket';
			return FALSE;
		}
	 }
	 
	function getOpenFR($team){

		$ticketdetails = array();
		unset($ticketdetails);
					
		$extract_url = FCPATH."\Macros\ExtractTIcketsFR.iim";
		
		$iim1 = new COM("imacros");
		$s = $iim1->iimOpen("-runner -kioskmode ", TRUE);
		$s = $iim1->iimSet("workgroup","$team");
		$s = $iim1->iimPlay($extract_url);
		// $s = $iim1->iimPlayCode($extractticket);
		
		if($s > 0){
		$tickets = $iim1->iimGetLastExtract();
		$s = $iim1->iimClose();
		$tickets = str_replace('[EXTRACT]', '', $tickets);
		$ticket = explode("#NEWLINE#", $tickets);
		
		foreach($ticket as $key => $ticks){
			$tdetails = explode("#NEXT#", $ticks);
			$ticketdetails[$key] = $tdetails;
		}
		return $ticketdetails;
		
		}
		else{
			echo $iim1->iimGetLastError;
			$s = $iim1->iimClose();
			echo '<br/>Failed to Extract Ticket';
			return FALSE;
		}
	 }
	 
	 function stopAssign($team){					//change value of Stop from DB
	 	// $this->load->model('main_model');
	 	// $team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		 $this->smtracker_model->stopAssign($team);
	 }
	 
	 function startAssign($team){					//change value of Start from DB
	 	// $this->load->model('main_model');
	 	// $team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');
		$this->smtracker_model->startAssign($team);
	 }
	 
	 function startRun($email){					//change value of StartRun in UserProfile DB
		 $this->smtracker_model->startRun($email);
	 }
	 
	 function stopRun($email){					//change value of StartRun in UserProfile DB
		 $this->smtracker_model->stopRun($email);
	 }
	 
	 function assignTicket($tnum, $specialist, $priority, $type, $row, $titlesearch, $category){
		 

		 $ticketnum = $tnum;
		 $status = 'Accepted';
		 $assigned = $specialist;
		 $update = "Assigned to ".$specialist.". [AUTO-DM]";
		 
		$iimassignTicket = "
		VERSION BUILD=9002379
		SET !EXTRACT_TEST_POPUP NO
		TAB T=1
		TAB CLOSEALLOTHERS
		WAIT SECONDS=2
		TAG POS=1 TYPE=SPAN ATTR=TXT:Search<SP>Incidents
		FRAME F=3
		WAIT SECONDS=10
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/number CONTENT=".$ticketnum."
		FRAME F=0
		TAG POS=1 TYPE=BUTTON ATTR=TXT:search
		WAIT SECONDS=5
		FRAME F=3
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/problem.status CONTENT=".$status."
		TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:topaz ATTR=NAME:instance/assignee.name CONTENT=".$assigned."
		TAG POS=1 TYPE=A FORM=NAME:topaz ATTR=TXT:Update
		TAG POS=1 TYPE=TEXTAREA FORM=NAME:topaz ATTR=NAME:var/pmc.actions/pmc.actions CONTENT=".$update."
		WAIT SECONDS=5
		FRAME F=0
		TAG POS=1 TYPE=BUTTON ATTR=TXT:save<SP>&<SP>Exit
		WAIT SECONDS=2
		FRAME F=3
		TAG POS=1 TYPE=DIV ATTR=CLASS:messageTrayElement<SP>infoMsg EXTRACT=TXT
		FRAME F=0
		TAG POS=2 TYPE=BUTTON ATTR=TXT:Cancel
		WAIT SECONDS=2";
		 
		 if ($category == "IM")
		{
			$iim1 = new COM("imacros");
			// $s = $iim1->iimOpen("-runner", FALSE);
			$s = $iim1->iimOpen('-cr -runner -crUserDataDir "C:\Users\perjohnv\AppData\Local\Google\Chrome\User Data\G.AACOE"', FALSE);
			$s = $iim1->iimPlayCode($iimassignTicket);
			// $s = $iim1->iimSet("-var_ticketnum","$ticketnum");
			// $s = $iim1->iimSet("-var_status","$status");
			// $s = $iim1->iimSet("-var_assignee","$assigned");
			// $s = $iim1->iimSet("-var_update","$update");
			// $s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\assign ticket.iim");
		}
		else if ($category == "FR")
		{
			$iim1 = new COM("imacros");
			$s = $iim1->iimOpen("-runner", FALSE);
			$s = $iim1->iimSet("-var_status","$status");
			$s = $iim1->iimSet("-var_assignee","$assigned");
			$s = $iim1->iimSet("-var_update","$update");
			$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\assign fr ticket.iim");
		}
		 
		 
	 }
	 
	 
	 
	 
	 
	 function flush_buffers(){ 
		ob_end_flush(); 
		flush(); 
		ob_start(); 
	}
	
	
	function RegionSelector($team){
		$current_region = $this->smtracker_model->RegionSelector($team);
		return $current_region;
	}
	
	function CheckDMAvailability($team){
		$allregions = $this->smtracker_model->getRegions($team);
		if($allregions == FALSE){
			echo 'Set atleast 1 Region for your Workgroup.';
			return FALSE;
		}
		foreach($allregions as $region){
			$assigned = $this->smtracker_model->CheckDMAvailability($team, $region['region']);
			if($assigned == FALSE){
				echo 'Set atleast one available Duty Manager to '.$region['region'].'.<br/>';
				echo 'SWITCHBOARD STOPPED AT EXACTLY '.date('h:i:s A');
				return FALSE;
			}
		}
		return TRUE;
	}
	
	function getRowApp($team){
		if($this->smtracker_model->getRowApp($team) == FALSE){
			echo "Set atleast 1 keyword in the Settings.";
			exit;
		}
		return $this->smtracker_model->getRowApp($team);
	}
	
	function minCriticalTicket($team, $rowapp){
		return $this->smtracker_model->minCriticalTicket($team, $rowapp);
		
	}
	
	function minIMTicket($team, $rowapp){
		return $this->smtracker_model->minIMTicket($team, $rowapp);
		
	}
	
	function minFRTicket($team, $rowapp){
		return $this->smtracker_model->minFRTicket($team, $rowapp);
		
	}
	
	function minRogueTicket($team, $rowapp){
		return $this->smtracker_model->minRogueTicket($team, $rowapp);
		
	}
	
	function checkStart($team){
		$start = $this->smtracker_model->setting("start", $team);
		if($start == 0){
			echo '<br/><b>['.date('h:i:sA').']<br/>SWITCHBOARD IS MANUALLY STOPPED.</b>';
		return FALSE;
		}
		return TRUE;
	}
	
	function sortdm($team){
		function cmp($a, $b){
			return $a['role'] - $b['role'];
		}
		
		$dms = $this->smtracker_model->getDM($team);
		usort($dms, "cmp");
		var_dump($dms);
	}
	
	function getCalendarShift($team, $status){
		$dmshift = $this->smtracker_model->getCalendar($team, $status);
		var_dump($dmshift);
	}
	
	function updateDM($team){
		$this->smtracker_model->updateDM($team);
		return TRUE;
	}
	
	function getDM($team, $region){
		$dms = $this->smtracker_model->getDM($team, $region);
		return $dms[0]['email'];
	}
	
	function getCurrentRegion($team){
		$regions = $this->smtracker_model->getRegions($team);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$currentRegion = '';
		foreach($regions as $region){
			if($region['start'] <= $date && $region['end'] >= $date){
				$currentRegion = $region['region'];
			}
		}
		return $currentRegion;
	}

	function updateAssigneeShift($team){
		$this->smtracker_model->updateAssigneeShift($team);
		return NULL;
	}


}
