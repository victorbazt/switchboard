<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct(){
			parent::__construct();
			ini_set('max_execution_time', 3000000);
			date_default_timezone_set("Asia/Singapore");
			$this->load->helper('url');
			$this->load->library('session');
			$this->load->model('main_model');
			$this->load->model('pgldap_model');
			date_default_timezone_set('Asia/Hong_Kong');
			$this->load->model('security_model');
			$this->security_model->is_logged_in();
			$this->security_model->checkSubscription();
	 }
	 
	 /*
	 Dashboard()
	 myTeam()
	 requestAccess()
	 saveRequestAccess()
	 userSetup()
	 saveUserSetup()
	 validateWorkgroup($workgroup)
	 getPGDetails($email)
	 donutIMFR()
	 donutROGUE()
	 calendar()
	 settings()
	 logout()
	 ticketlog()
	 openTickets($team)
	 getOpenIM($team)
	 stopAssign($team)
	 startAssign($team)
	 assignTicket($tnum, $specialist, $priority, $type, $row, $titlesearch, $category)
	 flush_buffers()
	 RegionSelector($team)
	 CheckDMAvailability($team)
	 getRowApp($team)
	 minCriticalTicket($team)
	 minIMTicket($team, $rowapp)
	 minFRTicket($team)
	 minRogueTicket($team)
	 checkStart($team)
	 sortdm($team)
	 getCalendarShift($team, $status)
	 updateDM($team)
	 smLogin()
	 
	 
	 
	 
	 */
	 
	 
	public function index()
	{

		redirect('Dashboard');
	}
	function getTicketCount(){
		var_dump($this->main_model->getTicketCount('G.AACOE', 'IM', '3 - Medium'));
	}
	
	function Dashboard(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		//update dm shift
		$this->updateDM($team);
		$data['currentPage'] = "home";
		$this->session->set_userdata('team', $team);		//set current team to session
		$data['startrun'] = $this->main_model->getStartRun($team);
		$data['dmoftheday'] = $this->main_model->getDM($team, 0);
		$data['regions'] = $this->main_model->getRegions($team);
		$data['ooospecialist'] = $this->main_model->getCalendar($team, 'ooo');


		if($this->main_model->getUserProfile($this->session->userdata('email'), 'ftuser') == TRUE){
			
			// $this->userSetup();
			// echo "this is first time user setup page";
			$data['hidemenu'] = TRUE;
			$this->load->view("template/header", $data);
			$this->load->view("setupwizard");
			$this->load->view("template/footer");
		}
		else
		{
			// echo "this is the dashboard";
			$this->load->view("template/header", $data);
			$this->load->view("home");
			$this->load->view("template/footer");
		}
	}
	
	function myTeam(){
		$data['currentPage'] = "myteam";
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$data['allspecialist'] = $this->main_model->getAllSpecialist($team);
		$this->load->view("template/header", $data);
		$this->load->view("specialist", $data);
		$this->load->view("template/footer");
	}
	
	function assignmentGroup(){
		$data['currentPage'] = "assignmentgroup";
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$this->load->view("template/header", $data);
		$this->load->view("assignmentgroup");
		$this->load->view("template/footer");
	}
	
	function shiftSchedule(){
		$data['currentPage'] = "shiftschedule";
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$this->load->view("template/header", $data);
		$this->load->view("shiftschedule");
		$this->load->view("template/footer");
	}
	
	// function assignTicket(){
		//ACTUAL ASSIGNMENT OF TICKET HERE
		
		
		//SEND EMAIL AFTER ASSIGNING OF TICKET
		// $this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'SAMPLE TICKET TITLE', $this->main_model->emailtemplate('PEREZ.JV', 'IM0123456', 'IM', 'SAMPLE TICKET TITLE', 'High', '07-22-16', 'OPEN', 'Sample Ticket Description'));
		
	// }
	
	function requestAccess(){
		$data['currentPage'] = "requestaccess";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("requestaccess");
		$this->load->view("template/footer");
		}
	
	function saveRequestAccess(){
		
		$email = strtolower($this->input->post('email'));
		$email = $this->input->post('email');
		$team = $this->input->post('team');

		
		if($this->getPGDetails($email) == TRUE)
			echo "valid pgemail. ";
		else{
			$this->session->set_flashdata('errorshortname','Invalid P&G shortname');
             redirect('main/requestAccess');
		}
		
		if($this->validateWorkgroup($team) == TRUE)
			echo "valid workgroup";
		else{
			$this->session->set_flashdata('errorworkgroup','Invalid Workgroup');
             redirect('main/requestAccess');
		}
		//LOAD THE REQUEST ACCESS/REGISTRATION VIEW HERE
		echo "request access page";
		
		//AFTER VALIDATION SEND EMAIL TO Automated Ticket Dispatcher <acoe-atd@hpe.com> 
		// $this->main_model->Send_Mail('acoe-atd@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
		$this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'SAMPLE REQUEST ACCESS TITLE', 'Sample Request Access Details');
	}
	
	function userSetup(){
		$data['currentPage'] = "home";
		$data['hidemenu'] = TRUE;
		$this->load->view("template/header", $data);
		$this->load->view("setup");
		$this->load->view("template/footer");
		
	}
	
	function saveUserSetup(){
		
		/*
		*Creation of atleast 1 specialist
		
		$newshortname = $this->input->post('shortname');		//shortname of newly added specialist
		$team = $this->main_model->getUserProfile($this->session->userdata('shortname'), 'team');  //dm can only add specialist under his/her own team only
		$region = $this->input->post('region');
		$pgdetails = $this->getPGDetails('perez.jv');	// $pgdetails['email'] && $pgdetails['wholename']
		$row = $this->input->post('row');
		$type = "L1";
		$role = "";

		$this->main_model->addSpecialist($newshortname, $team, $region, $pgdetails['email'], $pgdetails['wholename'], $row, $type, $role);
		*/
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$timeout = $this->input->post('timeout');
		$titlesearch = $this->input->post('titlesearch');
		$regionsearch = $this->input->post('regionsearch');
		$noregionassignee = $this->input->post('noregionassignee');
		
		$this->main_model->updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee);
	}
	
	function validateWorkgroup($workgroup){
		$validate_url = FCPATH."\Macros\ValidateWorkgroup.iim";
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -tray", FALSE);
		$s = $iim1->iimSet("-var_workgroup","$workgroup");
		$s = $iim1->iimPlay($validate_url);
		$output = $iim1->iimGetLastExtract;
		$s = $iim1->iimClose();
		if(strpos($output, "Invalid Group Name") !== false)
			return FALSE;		//false if workgroup is invalid
		else if(strpos($output, "Make sure the web address http://smtracker.pg.com is correct.") !== false)
			echo "Failed to Validate. Check your VPN";
		else
			return 1;			//1 if workgroup is valid
	}
	
	function getPGDetails($shortname){
		$shortname = strtolower($shortname);
		$pgaccount = $this->pgldap_model->pgldap_search($shortname);
		
		if($shortname != $pgaccount['extshortname'][0])
			return FALSE;
		if(isset($pgaccount['extnotifyaddress'][0]))
			$data['email'] = $pgaccount['extnotifyaddress'][0];
		else
			$data['email'] = $pgaccount['mail'][0];
		$data['wholename'] = $pgaccount['cn'][0];
		$pgdetails = $data['email'].','.$data['wholename'];
		echo $pgdetails;
		return TRUE;
	}
	
	function donutIMFR(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$category = 'IM';
		$priority = ' 1 - Critical ';
		$donut = $this->main_model->getTicketCount($team, $category, $priority);
		var_dump($donut);
		
	}
	
	function donutROGUE(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
	}

	function getAllSpecialist(){
		var_dump($this->main_model->getAllSpecialist('G.AACOE'));
	}
	
	function calendar(){
		$this->load->helper(array('form', 'url'));

		$team = $this->session->userdata('team');
		$data['currentPage'] = "calendar";	
		//for calendar
		$data['calendar'] = $this->fetchCalendar();
		$data['specialist'] = $this->main_model->getAllSpecialist($team);
		$data['shift'] = $this->main_model->getRegions($team);
		$this->load->view('template/header',$data);
		$this->load->view('calendar');
		$this->load->view('template/footer');
	}
	
	function settings(){
		$data['currentPage'] = "settings";
		$this->load->view('template/header',$data);
		$this->load->view('settings');
		$this->load->view('template/footer');
	}
	
	function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}
	
	function ticketlog(){
		$data['currentPage'] = "ticketlog";
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		// $data['allticket'] = $this->main_model->getAllTickets($team);
		$this->load->view("template/header", $data);
		$this->load->view("ticketlog");
		$this->load->view("template/footer");
	}

	function getAllTickets(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$tickets = $this->main_model->getAllTickets($team);
		foreach($tickets as $key => $value){
			$e = array("delete" => '<button type="button" class="btn-edit label-critical center fa fa-times" id="deleteTicket" onclick="deleteTicket(&#39;'.$tickets[$key]["id"].'&#39;);" value="" /></button>');
			$tickets[$key] = array_merge($tickets[$key], $e);
			if($tickets[$key]['priority'] == '1 - Top'){
				$tickets[$key]['priority'] = '<span class="label label-critical">1 - Top</span>';
			}
			else if($tickets[$key]['priority'] == '2 - High'){
				$tickets[$key]['priority'] = '<span class="label label-high">2 - High</span>';
			}
			else if($tickets[$key]['priority'] == '3 - Medium'){
				$tickets[$key]['priority'] = '<span class="label label-average">3 - Medium</span>';
			}
			else if($tickets[$key]['priority'] == '4 - Low'){
				$tickets[$key]['priority'] = '<span class="label label-low">4 - Low</span>';
			}
			// else{
			// 	$tickets[$key]['priority'] = '<span class="label label-danger">1 - Critical</span>';
			// }
		}
		echo json_encode($tickets);
	}

	
	
	 
	 
	 
	 
	 function flush_buffers(){ 
		ob_end_flush(); 
		flush(); 
		ob_start(); 
	}
	
	
	function RegionSelector($team){
		$current_region = $this->main_model->RegionSelector($team);
		return $current_region;
	}
	
	function CheckDMAvailability($team){
		$allregions = $this->main_model->getRegions($team);
		if($allregions == FALSE){
			echo 'Set atleast 1 Region for your Workgroup.';
			exit;
		}
		foreach($allregions as $region){
			$assigned = $this->main_model->CheckDMAvailability($team, $region['region']);
			if($assigned == FALSE){
				echo 'Set atleast one available Duty Manager to '.$region['region'].'.<br/>';
				echo 'SWITCHBOARD STOPPED AT EXACTLY '.date('h:i:sA');
				exit;
			}
		}
	}
	
	function getRowApp($team){
		if($this->main_model->getRowApp($team) == FALSE){
			echo "Set atleast 1 keyword in the Settings.";
			exit;
		}
		return $this->main_model->getRowApp($team);
	}
	
	function getKeyword(){
		$team = $this->session->userdata('team');
		$keywords = $this->main_model->getRowApp($team);
		$keyword = '';
		foreach($keywords as $key => $value){
			$keyword = $keyword.','.$keywords[$key]['rows'];
		}
		echo $keyword;
	}
	
	function minCriticalTicket($team, $rowapp){
		return $this->main_model->minCriticalTicket($team, $rowapp);
		
	}
	
	function minIMTicket($team, $rowapp, $region){
		return $this->main_model->minIMTicket($team, $rowapp, $region);
		
	}
	
	function minFRTicket($team, $rowapp){
		return $this->main_model->minFRTicket($team, $rowapp);
		
	}
	
	function minRogueTicket($team, $rowapp){
		return $this->main_model->minRogueTicket($team, $rowapp);
		
	}
	
	function checkStart($team){
		$start = $this->main_model->setting("start", $team);
		if($start == 0){
			echo '<b>STOPPED AT EXACTLY '.date('h:i:sA').'.</b>';
		return FALSE;
		}
		return TRUE;
	}
	
	function sortdm($team){
		function cmp($a, $b){
			return $a['role'] - $b['role'];
		}
		
		$dms = $this->main_model->getDM($team);
		usort($dms, "cmp");
		var_dump($dms);
	}
	
	function getCalendarShift($team, $status){
		$dmshift = $this->main_model->getCalendar($team, $status);
		var_dump($dmshift);
	}
	
	function updateDM($team){
		$this->main_model->updateDM($team);
	}

	function assigneeShift(){
		$assignee_shift = $this->main_model->getAssigneeShift();
		var_dump($assignee_shift);
	}

	function updateAssigneeShift($team){
		$this->main_model->updateAssigneeShift($team);
	}
	
	function smLogin(){
		$username = $this->session->userdata('email');
		$password = $this->main_model->getUserProfile($username, 'password');
		$iim1 = new COM("imacros");
		$s = $iim1->iimInit("-runner -kioskmode", true);
		$s = $iim1->iimSet("-var_username","$username");
		$s = $iim1->iimSet("-var_password","$password");
		$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGIN.iim");
	}
	
	function smLogOut(){
		$s = $iim1->iimPlay("C:\wamp\www\AutoDM\Macros\SM LOGOUT.iim");
		$s = $iim1->iimClose();
	}
	
	function getDM($team, $region){
		$dms = $this->main_model->getDM($team, $region);
		return $dms[0]['email'];
	}
	
	function getCurrentRegion($team){
		$regions = $this->main_model->getRegions($team);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$currentRegion = '';
		foreach($regions as $region){
			if($region['start'] <= $date && $region['end'] >= $date){
				$currentRegion = $region['region'];
			}
		}
		return $currentRegion;
	}

	function getNextRegion($team, $currentRegion){
		// $team = 'G.AACOE';
		// $currentRegion = 'NALA';
		$regions = $this->main_model->getRegions($team);
		$region_end = $this->main_model->getRegionEndTime($team, $currentRegion);
		$end = explode(' ', $region_end);
		$time = $end[1];
		$region_end = strtotime($time);
		$region_end+= 1860;
		$region_end = date('H:i:s', $region_end);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$nextRegion = '';
		foreach($regions as $region){
			$regions_start = explode(' ', $region['start']);
			$starttime = $regions_start[1];
			$regions_end = explode(' ', $region['end']);
			$endtime = $regions_end[1];
			if($starttime <= $region_end && $endtime >= $region_end){
				$nextRegion = $region['region'];
			}
		}

		return $nextRegion;
	}

	function getRegionStart(){
		$region_start = $this->main_model->getRegionStartTime('G.AACOE', 'EMEA');
		echo $region_start;
	}

	function getPrevRegion($team, $currentRegion){
		// $team = 'G.AACOE';
		// $currentRegion = 'EMEA';
		$regions = $this->main_model->getRegions($team);
		$region_end = $this->main_model->getRegionStartTime($team, $currentRegion);
		$end = explode(' ', $region_end);
		$time = $end[1];
		$region_end = strtotime($time);
		$region_end-= 1860;
		$region_end = date('H:i:s', $region_end);
		$date = new DateTime('1000-01-02');
		$date->setTime(date('H'), date('i'), date('s'));
		$date = $date->format('Y-m-d H:i:s');
		// echo $date;
		$nextRegion = '';
		foreach($regions as $region){
			$regions_start = explode(' ', $region['start']);
			$starttime = $regions_start[1];
			$regions_end = explode(' ', $region['end']);
			$endtime = $regions_end[1];
			if($starttime <= $region_end && $endtime >= $region_end){
				$nextRegion = $region['region'];
			}
		}

		return $nextRegion;
	}
	
	function updateCalendar(){
		$team = $this->session->userdata('team');
		// $email = $this->session->userdata('email');
		$type = $_POST['type'];

		if($type == 'new')
		{
			$status = $_POST['status'];
			$type = $_POST['ctype'];
			$email = $_POST['title'];
			$startdate = $_POST['startdate'];
			$startdate = strtotime($startdate);
			$startdate = date('Y-m-d', $startdate);
			$enddate = $startdate;
			$eventid = $_POST['eventid'];
			
			//ADD 1 Day to enddate
			// $enddate = strtotime($enddate);
			// $enddate = strtotime('+1 day', $enddate);
			// $enddate = date('Y-m-d H:i:s', $enddate);
			$email = $_POST['title'];
			$eventdetails = $this->main_model->newCalendar($email, $startdate, $enddate, $status, $type, $eventid);
			$eventid = $eventdetails['eventid'];
			echo json_encode($eventdetails);
		}

		if($type == 'changetitle')
		{
			$eventid = $_POST['eventid'];
			$status = $_POST['status'];
			$type = $_POST['ctype'];
			$this->main_model->changeStatusCalendar($status, $type, $eventid);
		}

		if($type == 'resetdate')
		{
			// $email = $_POST['title'];
			$startdate = $_POST['start'];
			$enddate = $_POST['end'];
			$eventid = $_POST['eventid'];
			$this->main_model->resetDateCalendar($startdate, $enddate, $eventid);
		}

		if($type == 'remove')
		{
			$eventid = $_POST['eventid'];
			$dm = $this->main_model->getCalendar($team, $eventid);
			if($dm[0]['sdate'] <= date("Y-m-d") && $dm[0]['edate'] >= date("Y-m-d")){
				$data = array(
						'role' => '',
						'status' => 'Unavailable'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
				$this->db->select('email');
				$this->db->from('specialist');
				$this->db->where('email', $dm[0]['email']);
				$this->db->update('specialist', $data);
			}

			
			$this->main_model->deleteCalendar($eventid);
		}

		if($type == 'fetch')
		{
			$events = array();
			$events = $this->main_model->fetchCalendar($team);
			foreach($events as $key => $value){
				if($events[$key]['status'] == 'DM'){
					$e = array("className" => 'label-default');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Sick Leave'){
					$e = array("className" => 'label-danger');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Vacation Leave'){
					$e = array("className" => 'label-primary');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'CDO'){
					$e = array("className" => 'label-primary');
					$events[$key] = array_merge($events[$key], $e);
				}
				else if($events[$key]['type'] == 'Training'){
					$e = array("className" => 'label-primary');
					$events[$key] = array_merge($events[$key], $e);
				}
				else{
					$e = array("className" => 'label-dm');
					$events[$key] = array_merge($events[$key], $e);
				}
			}
			// $query = mysqli_query($con, "SELECT * FROM calendar");
			// while($fetch = mysqli_fetch_array($query,MYSQLI_ASSOC))
			// {
			// $e = array();
			// $e['id'] = $fetch['id'];
			// $e['title'] = $fetch['title'];
			// $e['start'] = $fetch['startdate'];
			// $e['end'] = $fetch['enddate'];

			// $allday = ($fetch['allDay'] == "true") ? true : false;
			// $e['allDay'] = $allday;

			// array_push($events, $e);
			// }
			
			echo json_encode($events);
		}

		$type = $_POST['type'];
		if($type != 'fetch' && $type != 'remove'){
			$type = $_POST['ctype'];	
			$dm = $this->main_model->getCalendar($team, $eventid);
			if($dm[0]['cstatus'] == 'DM'){

				if($dm[0]['sdate'] <= date("Y-m-d") && $dm[0]['edate'] >= date("Y-m-d")){
					$data = array(
						'role' => '1'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('email');
					$this->db->from('specialist');
					$this->db->where('email', $dm[0]['email']);
					$this->db->update('specialist', $data);
				}
				else{
					$data = array(
						'role' => ''
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('email');
					$this->db->from('specialist');
					$this->db->where('email', $dm[0]['email']);
					$this->db->update('specialist', $data);
				}
			}
			if($dm[0]['cstatus'] == 'Leave'){

				if($dm[0]['sdate'] <= date("Y-m-d") && $dm[0]['edate'] >= date("Y-m-d")){
					$data = array(
						'status' => 'Unavailable'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('email');
					$this->db->from('specialist');
					$this->db->where('email', $dm[0]['email']);
					$this->db->update('specialist', $data);
				}
				else{
					$data = array(
						'status' => 'Available'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('email');
					$this->db->from('specialist');
					$this->db->where('email', $dm[0]['email']);
					$this->db->update('specialist', $data);
				}
			}
			if($dm[0]['cstatus'] != 'DM' && $dm[0]['cstatus'] != 'Leave'){

				if($dm[0]['sdate'] <= date("Y-m-d") && $dm[0]['edate'] >= date("Y-m-d")){
					$data = array(
						'status' => 'Available'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('email');
					$this->db->from('specialist');
					$this->db->where('email', $dm[0]['email']);
					$this->db->update('specialist', $data);
				}
				else{
					$data = array(
						'status' => 'Unavailable'
						// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)
					);
					$this->db->select('email');
					$this->db->from('specialist');
					$this->db->where('email', $dm[0]['email']);
					$this->db->update('specialist', $data);
				}
			}

		}
		
		
		
		
	}
	function xx(){
		// var_dump($this->main_model->getCalendar('G.AACOE','ooo'));
		$start = strtotime(date('H:i:s'));
		sleep(5);
		$end = strtotime(date('H:i:s'));
		echo $end-$start;
	}
	
	function changeStatusCalendar($status, $id){
		$this->main_model->changeStatusCalendar($status, $id);
	}
	
	function deleteCalendar($id){
		$this->main_model->deleteCalendar($id);
	}
	
	function fetchCalendar(){
		$team = $this->session->userdata('team');
		$schedule = $this->main_model->fetchCalendar($team);
		foreach($schedule as $key => $value){
			if($schedule[$key]['title'] == 'DM'){
				$e = array("backgroundColor" => '#cccccc');
				$schedule[$key] = array_merge($schedule[$key], $e);
			}
		}
		
		return json_encode($schedule);
	}
	
	function updateAllSettings(){
		$team = $this->session->userdata('team');
		$settings = $_POST['setting'];
		
		if($settings == 'getsetting'){
			$allsettings = $this->main_model->getSettings($team, 'allsettings');
			$timeout = $allsettings[0]['timeout'];
			$titlesearch = ($allsettings[0]['titlesearch'] == '1') ? 'true' : 'false';
			$regionsearch = ($allsettings[0]['regionsearch'] == '1') ? 'true' : 'false';
			$noregionassignee = $allsettings[0]['noregionassignee'];
			$allsettings = $timeout.','.$titlesearch.','.$regionsearch.','.$noregionassignee;
			echo $allsettings;
		}
		
		if($settings == 'getworkgroup'){
			echo $this->main_model->getWorkgroup($team);
		}
		
		if($settings == 'getkeyword'){
			$keywords = $this->main_model->getRowApp($team);
			foreach($keywords as $keyword){
				echo $keyword['rows'].',';
			}
		}
			if($settings == ''){
				$timeout = $_POST['timeout'];
				$titlesearch = $_POST['titlesearch'];
				$regionsearch = $_POST['regionsearch'];
				$noregionassignee = $_POST['noregionassignee'];
				$workgroups = $_POST['workgroups'];
				$workgroups = strtoupper($workgroups);
				$keywords = $_POST['keywords'];
				$keywords = strtoupper($keywords);
				$keywords = explode(",", $keywords);
				
				if($this->main_model->updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE..';
				}
				
				if($this->main_model->updateWorkgroup($team, $workgroups) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE..';
				}
				

				if($this->main_model->insertRowApp($team, $keywords) == TRUE){
					$message = '<br/>SAVE SUCCESSFUL!';
				}
				else{
					$message = '<br/>FAILED TO SAVE KEYWORDS..';
				}
				echo $message;
			}
		
		
	}
	
	function updateRegion(){
		$team = $this->session->userdata('team');
		$type = $_POST['type'];
		
		if($type == 'new'){
			$region = $_POST['region'];
			$start = $_POST['start'];
			$end = $_POST['end'];

			if(strtotime($start) > strtotime($end)){
				$start = '1000-01-01 '.$start;
				$end = '1000-01-02 '.$end;
			}
			else{
				$start = '1000-01-02 '.$start;
				$end = '1000-01-02 '.$end;
			}
			$this->main_model->addRegion($team, $region, $start, $end);	
			echo 'Successfully Added';
		}
		
		if($type == 'fetch'){
			$regions = $this->main_model->getRegions($team);	
			foreach($regions as $key => $value){
				$allregion[$key] = $regions[$key]['region'].','.$regions[$key]['start'].','.$regions[$key]['end'];
			}
			$allregions = '';
			foreach($allregion as $region){
				$allregions = $allregions.$region.'*';
			}
			echo $allregions;
		}
		
		
	}
	
	function updateSpecialist(){
		$team = $this->session->userdata('team');
		// $email = strtoupper($_POST['email']);
		$region = $_POST['shift'];
		$keywords = $_POST['keywordnew'];
		$wholename = $_POST['wholename'];
		$email = $_POST['email'];
		$assignmentgroup = $_POST['assignment_group'];
		$type = $_POST['type'];
		
		$rowapp = '';
		if($keywords != ''){
			$keywords = explode(',', $keywords);
			foreach($keywords as $key => $values){
				if($keywords[$key] != '')
					$rowapp = $rowapp.'['.$keywords[$key].']';
			}			
		}
		
		$this->main_model->updateSpecialist($team, $email, $assignmentgroup, $wholename, $region, $rowapp, '', '', $type);
		// echo $type;
	}

	function deleteSpecialist(){
		$specialistid = $_POST['specialistid'];
		$this->main_model->deleteSpecialist($specialistid);
	}

	function deleteTicket(){
		$ticketid = $_POST['ticketid'];
		$this->main_model->deleteTicket($ticketid);
	}
	
	function getSettings($team, $column){
		print_r($this->main_model->getSettings($team, $column));
	}
	
	function getMyTeam(){
		$team = $this->session->userdata('team');
		$this->updateAssigneeShift($team);
		$myteam = $this->main_model->getMyTeam($team);
		foreach($myteam as $key => $value){
			$e = array("edit" => '<button type="button" class="btn-edit asia center fa fa-pencil" id="updateSpecialist" onclick="updateSpecialist(&#39;'.$myteam[$key]["email"].'&#39;);" value="" /></button><button type="button" class="btn-edit label-critical center fa fa-times" id="deleteSpecialist" onclick="deleteSpecialist(&#39;'.$myteam[$key]["id"].'&#39;);" value="" /></button>');
			$myteam[$key] = array_merge($myteam[$key], $e);
			$myteam[$key]['row'] = str_replace('[', '&nbsp;&nbsp;<span class="label-gray">&nbsp;&nbsp;', $myteam[$key]['row']);
			$myteam[$key]['row'] = str_replace(']', '&nbsp;&nbsp;</span>', $myteam[$key]['row']);
		}
		echo json_encode($myteam);
	}
	
	function getTicketlog(){
		$email = $this->session->userdata('email');
		$tickets = $this->main_model->getTickets($email);
		foreach($tickets as $key => $value){
			if($tickets[$key]['priority'] == '1 - Top'){
				$tickets[$key]['priority'] = '<span class="label label-critical">1 - Top</span>';
			}
			else if($tickets[$key]['priority'] == '2 - High'){
				$tickets[$key]['priority'] = '<span class="label label-high">2 - High</span>';
			}
			else if($tickets[$key]['priority'] == '3 - Medium'){
				$tickets[$key]['priority'] = '<span class="label label-average">3 - Medium</span>';
			}
			else if($tickets[$key]['priority'] == '4 - Low'){
				$tickets[$key]['priority'] = '<span class="label label-low">4 - Low</span>';
			}
			// else{
			// 	$tickets[$key]['priority'] = '<span class="label label-danger">1 - Critical</span>';
			// }
		}
		echo json_encode($tickets);
	}
	
	function addSpecialist($team, $email, $wholename, $email, $region, $keyword){
		$this->main_model->updateSpecialist($team, $email, $wholename, $email, $region, $keyword, '', '', '');
	}
	
	function getRegions(){
		$team = $this->session->userdata('team');
		$regions = $this->main_model->getRegions($team);
		$data = '';
		foreach($regions as $key => $value){
			$data = $data.','.$regions[$key]['region'];
		}
		echo $data;
	}
	
	function getSpecialist($email){
		
		$specialist = $this->main_model->getSpecialist($email);
		echo $specialist[0]['region'].'*'.$specialist[0]['row'].'*'.$specialist[0]['wholename'].'*'.$specialist[0]['assignmentgroup'];
	}
	
	function deleteShift(){
		$shift = $_POST['shift'];
		$team = $this->session->userdata('team');
		$this->main_model->deleteShift($shift, $team);
		echo 'Successfully Deleted.';
	}

	// function getTicketCountSpecialist(){
	// 	$team = $this->session->userdata('team');
	// 	echo json_encode($this->main_model->getTicketCountSpecialist($team), JSON_NUMERIC_CHECK);
	// }

	function getTicketCountAG(){
		$team = $this->session->userdata('team');
		echo json_encode($this->main_model->getTicketCountAG($team), JSON_NUMERIC_CHECK);
	}

	function getTicketCountIM(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$ticketcountim = $this->main_model->getTicketCount($team, 'IM', 'ALL');
		foreach($ticketcountim as $key => $value){
				if($ticketcountim[$key]['name'] == '1 - Top'){
					$e = array("color" => '#f04953');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
				else if($ticketcountim[$key]['name'] == '2 - High'){
					$e = array("color" => '#f09144');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
				else if($ticketcountim[$key]['name'] == '3 - Medium'){
					$e = array("color" => '#ffd144');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
				else{
					$e = array("color" => '#2AD2C9');
					$ticketcountim[$key] = array_merge($ticketcountim[$key], $e);
				}
			}
		echo json_encode($ticketcountim, JSON_NUMERIC_CHECK);
	}

	function getTicketCountFR(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$ticketcountfr = $this->main_model->getTicketCount($team, 'FR', 'ALL');
		foreach($ticketcountfr as $key => $value){
				if($ticketcountfr[$key]['name'] == '1 - Top'){
					$e = array("color" => '#f04953');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
				else if($ticketcountfr[$key]['name'] == '2 - High'){
					$e = array("color" => '#f09144');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
				else if($ticketcountfr[$key]['name'] == '3 - Medium'){
					$e = array("color" => '#ffd144');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
				else{
					$e = array("color" => '#2AD2C9');
					$ticketcountfr[$key] = array_merge($ticketcountfr[$key], $e);
				}
			}
		echo json_encode($ticketcountfr, JSON_NUMERIC_CHECK);
	}

	
	function getAllRogue(){
		$team = $this->main_model->getUserProfile($this->session->userdata('email'), 'team');
		$tickets = $this->main_model->getAllRogue($team);

		foreach($tickets as $key => $value){
				if($tickets[$key]['name'] == 'IM'){
					$e = array("color" => '#94ABA8');
					$tickets[$key] = array_merge($tickets[$key], $e);
				}
				else{
					$e = array("color" => '#8c6694');
					$tickets[$key] = array_merge($tickets[$key], $e);
				}
		}

		echo json_encode($tickets, JSON_NUMERIC_CHECK);
	}

	function sendHandover(){
		$shift = $this->getCurrentRegion('G.AACOE');
		$dispatcher = $this->main_model->getUserProfile($this->session->userdata('email'), 'wholename');
		$handedTo = $this->getNextRegion('G.AACOE', $shift);
		$nextDispatch = "12AM";
		$message = "
		<html>
		<head>
		</head>
		<body style='font-family:Arial;'>
		<p style='font-size:16px;'>Hi,</p>
		<table style='border-collapse:collapse;font-family:Arial;font-size:15px;'>
			<tr style='background-color: #9de1e1;color:black;text-align:center;'>
				<td style='border:1px solid black;width:200px;'>Report</td>
				<td style='border:1px solid black;width:200px;'>L2 Handover - Takeover</td>
			</tr>
			<tr>
				<td style='border:1px solid black;'>Shift</td>
				<td style='border:1px solid black;'>".$shift."</td>
			</tr>
			<tr>
				<td style='border:1px solid black;'>Dispatcher Name</td>
				<td style='border:1px solid black;'>".$dispatcher."</td>
			</tr>
			<tr>
				<td style='border:1px solid black;'>Handed over to</td>
				<td style='border:1px solid black;'>".$handedTo."</td>
			</tr>
			<tr>
				<td style='border:1px solid black;'>Next Dispatcher Report</td>
				<td style='border:1px solid black;'>".$nextDispatch."</td>
			</tr>
		</table>
		<br>
		<b style='text-decoration:underline;font-size:14px;'>Number of tickets dispatched</b>
		<br><br>
		<table style='border-collapse:collapse;font-family:Arial;font-size:14px;'>
			<tr style='text-align:center;'>
				<td style='border:none;width:350px;'></td>
				<td style='border:1px solid black;width:100px;font-size:15px;'>1 - Top</td>
				<td style='border:1px solid black;width:100px;font-size:15px;'>2 - High</td>
				<td style='border:1px solid black;width:100px;font-size:15px;'>3 - Medium</td>
				<td style='border:1px solid black;width:100px;font-size:15px;'>4 - Low</td>
			</tr>
		";
		$tickets = $this->main_model->handover();
		foreach ($tickets as $workgroup){ //Code to show Number of dispatched tickets table
			$message = $message."<tr>";
			for($i=0;$i<5;$i++){
				$message = $message."<td style='border:1px solid black;";
				if($i == 0){
					$message = $message."'><b>".$workgroup['assignmentgroup']."</b></td>";
				}
				else{
					$message = $message."text-align:center;'>".$workgroup['tkt_count']."</td>";
				}
			}
			$message = $message."</tr>";
		}
		$message = $message."
		</table><br>
		<b style='text-decoration:underline;font-size:14px;'>Rogue Tickets</b>
		<br>
		<table style='border-collapse:collapse;font-family:Arial;font-size:15px;'>
			<tr style='text-align:center;'>
				<td style='border:1px solid black;width:150px;'>1 - Top</td>
				<td style='border:1px solid black;width:150px;'>2 - High</td>
				<td style='border:1px solid black;width:150px;'>3 - Medium</td>
				<td style='border:1px solid black;width:150px;'>4 - Low</td>
			</tr>
			";
			// while(count($rogue)>0){ //Code to display rogue tickets. Deletes each entry displayed in ticket and ends when there are no entries left
			// 	$done = false;
			// 	$count = 0;
			// 	$i = 0;
			// 	$message = $message."<tr>";
			// 	while($done == false){
			// 		if($rogue[$i][1] == ($count + 1)){ //Checks if the priority of current rogue ticket matches column's priority
			// 			$message = $message."<td style='border:1px solid black;text-align:center;'>".$rogue[$i][0]."</td>";
			// 			unset($rogue[$i]);
			// 			$j = 0;
			// 			$new_array = array();
			// 			foreach($rogue as $value)
			// 			{
			// 				$new_array[$j] = $value;
			// 				++$j;
			// 			}
			// 			$rogue = $new_array;
			// 			$i = 0;
			// 			$count++;
			// 			if(count($rogue) < 1){ //Forces end of loop if no entries left in array
			// 				$done = true;
			// 			}
			// 		}
			// 		else{
			// 			if($i == (count($rogue) - 1))
			// 			{
			// 				$count++;
			// 				$i = 0;
			// 				$message = $message."<td style='border:1px solid black;'></td>";
			// 			}
			// 			else{
			// 				$i++;
			// 			}
			// 		}
			// 		if($count == 4){ //Go to next table row
			// 			$done = true;
			// 			$message = $message."</tr>";
			// 		}
			// 	}
			// }
			while($count < 4){ //Populates remaining cells if loop stopped before the 4th column
				$message = $message."<td style='border:1px solid black;'>IM</td>";
				$count++;
			}
			$message = $message."</tr>
		</table>
		</body>
		</html>
		";




		$this->main_model->Send_Mail('john-victor-o.perez@hpe.com', 'Handover Email', $message);
		// echo $message;
	}

	// function handover(){
	// 	$ticket = $this->main_model->rogue();
	// 	var_dump($ticket);
	// 	// echo '!<br/><br/><br/>!	'.$ticket[0]['tnum'];
	// }

	public function handover()
	{	$currentShift = $this->getCurrentRegion('G.AACOE');
		$dispatcher = $this->main_model->getUserProfile($this->session->userdata('email'), 'wholename');
		$nextShift = $this->getNextRegion('G.AACOE', $currentShift);


		$shift_start = $this->main_model->getRegionStartTime('G.AACOE', $currentShift);

		$start = explode(' ', $shift_start);
		$stime = $start[1];
		$shift_start = strtotime($stime);
		// $shift_start + strtotime(date('Y-m-d'));
		$shift_start = date('Y-m-d H:i:s', $shift_start);
		// $date = new DateTime('1000-01-02');
		// $date->setTime(date('H'), date('i'), date('s'));
		// $date = $date->format('Y-m-d H:i:s');

		$shift_end = $this->main_model->getRegionEndTime('G.AACOE', $currentShift);

		$end = explode(' ', $shift_end);
		$etime = $end[1];
		$shift_end = strtotime($etime);
		$shift_end = date('Y-m-d H:i:s', $shift_end);

		// $shift_start = date( 'Y-m-d H:i:s', mktime(15,0,0,date('n'),4,date('Y')));
		// $shift_end = date( 'Y-m-d H:i:s', mktime(23,0,0,date('n'),4,date('Y')));
		//echo $APJstart.'<br/>'.$EMEAstart;
		$tickets = $this->main_model->get_tickets($shift_start,$shift_end);
		if(count($tickets) > 0){
			$data['tickets'] = $this->ticket_count($tickets);
			$rogue = $this->main_model->get_rogue($shift_start,$shift_end);
			$achieved = $this->main_model->get_tto_achieved($shift_start,$shift_end);
			$breached = $this->main_model->get_tto_breached($shift_start,$shift_end);
			if(count($rogue) > 0){
				$data['rogue'] = $this->rogue_count($rogue);
			}
			else{
				$data['rogue'] = "<b style='text-decoration:underline;font-size:14px;'>No Manually assigned tickets during this shift</b>";
			}
			
			$data['tto'] = $this->tto_count($achieved,$breached);
		}
		else{
			$data['tickets'] = "<b style='text-decoration:underline;font-size:14px;'>No tickets assigned during this shift</b>";
		}
		$data['message'] = $this->build_mail($currentShift,$dispatcher,$nextShift,$data['tickets'],$data['rogue'],$data['tto']);
		$this->main_model->Send_Mail('apps_gdph_clienthp_gscs_l2@hpe.com, amos_bgl@hpe.com, katrina-marie.cunanan@hpe.com, '.$this->session->userdata('email').' ', 'ES Dispatching Handover Report - '.$currentShift.' Shift - '.date('Y-m-d H:i:s'), $data['message']);
	}

	public function ticket_count($tickets)
	{
		$extract = array();
		$priority = array("Top", "High", "Medium", "Low");
		foreach($tickets as $item){
			$i = 0;
			$moved = false;
			while($moved == false){
				if(count($extract) > 0 and array_key_exists($i,$extract) and $i < count($tickets)){
					if($extract[$i][0] == $item["assignmentgroup"]){
						$x = 0;
						while(strpos($item["priority"],$priority[$x]) == false){
							$x++;
						}
						$extract[$i][$x + 1]++;
						$moved = true;
					}
				}
				else{
					$moved = true;
					$extract[$i] = array($item["assignmentgroup"],0,0,0,0);
					$x = 0;
					while(strpos($item["priority"],$priority[$x]) == false){
						$x++;
					}
					$extract[$i][$x + 1]++;
				}
				$i++;
			}
		}
		$message = "
		<table style='width:100%;padding:2px;margin:0;'>
			<tr>
				<td style='color:white;background-color:#01a982;width:100%;font-family:Arial;font-size:15px;'><b>Volume of Tickets Dispatched</b></td>
			</tr>
		</table>
		<br>
		<table style='border-collapse:collapse;font-family:Arial;font-size:14px;'>
			<tr style='text-align:center;'>
				<td style='border:1px solid black;width:300px;font-size:15px;'><b>Assignment Group</b></td>
				<td style='border:1px solid black;width:100px;font-size:15px;'><b>1 &#45; Top</b></td>
				<td style='border:1px solid black;width:100px;font-size:15px;'><b>2 &#45; High</b></td>
				<td style='border:1px solid black;width:100px;font-size:15px;'><b>3 &#45; Medium</b></td>
				<td style='border:1px solid black;width:100px;font-size:15px;'><b>4 &#45; Low</b></td>
			</tr>
		";
		foreach ($extract as $workgroup){
			if(strpos($workgroup[0],"DISPATCH") == false){
				$message = $message."<tr>";
				for($i=0;$i<5;$i++){
					$message = $message."<td style='border:1px solid black;";
					if($i == 0){
						$message = $message."'>".$workgroup[$i]."</td>";
					}
					else{
						$message = $message."text-align:center;'>".$workgroup[$i]."</td>";
					}
				}
			}
			$message = $message."</tr>";
		}
		return $message."</table>";
	}
	
	public function rogue_count($tickets){
		$message = "
		<table style='width:100%;padding:2px;margin:0;'>
			<tr>
				<td style='color:white;background-color:#01a982;width:100%;font-family:Arial;font-size:15px;'><b>Manually Dispatched Tickets</b></td>
			</tr>
		</table>
		<br>
		<table style='border-collapse:collapse;font-family:Arial;font-size:15px;'>
			<tr style='text-align:center;'>
				<td style='border:1px solid black;width:300px;'><b>Ticket No.</b></td>
				<td style='border:1px solid black;width:410px;'><b>Affected CI</b></td>
			</tr>
		";
		foreach($tickets as $item){
			$message = $message."
				<tr>
					<td style='border:1px solid black;text-align:center;'>".$item["tnum"]."</td>
					<td style='border:1px solid black;text-align:center;'>".$item["affectedCI"]."</td>
				</tr>";
		}
		return $message."</table>";
	}
	
	// public function reindex($array){
	// 	$i = 0;
	// 	$new_array = array();
	// 	foreach($array as $value){
	// 		$new_array[$i] = $value;
	// 		++$i;
	// 	}
	// 	return $new_array;
	// }
	
		//#TTO STATUS TABLE
	public function tto_count ($achieved,$breached){
		$message = "
			<table style='width:100%;padding:2px;margin:0;'>
				<tr>
					<td style='color:white;background-color:#01a982;width:100%;font-family:Arial;font-size:15px;'><b>Time-To-Own Status</b></td>
				</tr>
			</table>
			<br>
			<table style='border-collapse:collapse;font-family:Arial;font-size:15px;'>
				<tr style='text-align:center;'>
					<td style='border:1px solid black;width:300px;'><b>TTO Status</b></td>
					<td style='border:1px solid black;width:100px;'><b>1 &#45; Top</b></td>
					<td style='border:1px solid black;width:100px;'><b>2 &#45; High</b></td>
					<td style='border:1px solid black;width:100px;'><b>3 &#45; Medium</b></td>
					<td style='border:1px solid black;width:100px;'><b>4 &#45; Low</b></td>
				</tr>
				<tr style='text-align:center;'>
					<td style='border:1px solid black;width:300px;'>Achieved</td>
			";
			for($i=0;$i<4;$i++){
				$message = $message."<td style='border:1px solid black;width:100px;'>".$achieved[$i]."</td>";
			}
			$message = $message."
				</tr>
				<tr style='text-align:center;'>
					<td style='border:1px solid black;width:300px;'>Breached</td>";
			for($i=0;$i<4;$i++){
				$message = $message."<td style='border:1px solid black;width:100px;'>".$breached[$i]."</td>";
			}
			$message = $message."
				</tr>
			</table>
				";
		//echo $message;
		return $message;
	}
	//END
	
	public function build_mail($currShift,$dispatcher,$nextShift,$ticketCount,$rogueCount, $ttoStatus){
		$dateNow = date('F')." ".date('d')." ".date('Y');
		$message = "
		<p style='font-size:22px;font-family:Arial'><b>ES Dispatching Handover Report &#45; ".$currShift." to ".$nextShift."</b></p>
		<p style='font-size:15px;font-family:Arial'>Dispatcher Name: ".$dispatcher."<br>
		Date: ".$dateNow."</p>
		".$ticketCount."<br>".$ttoStatus."<br>".$rogueCount;

		$message = $message."<br/><br/><br/><br/><p style='font-size:10px;font-family:Arial'>Disclaimer: The information transmitted is intended solely for the individual or entity to which it is addressed and may contain Hewlett Packard Company confidential and/or privileged material. Any review, retransmission, dissemination or other use of or taking action in reliance upon this information by persons or entities other than the intended recipient is prohibited. If you have received this email in error please contact the sender and delete the material from any computer.</p>";
		return $message;
	}

	//Handover Aknowledgement
	public function handoverack()
	{
		$currentshift = $this->getCurrentRegion('G.AACOE');
		$previousshift = $this->getPrevRegion('G.AACOE', $currentshift);
		$currentdispatcher = $this->main_model->getUserProfile($this->session->userdata('email'), 'wholename');
		$previousdispatcher = $this->getDM('G.AACOE', $previousshift);
		$dateNow = date('F')." ".date('d')." ".date('Y');
		// echo $currentshift;
		// echo $previousshift;
		// echo $previousdispatcher;
		$message = "
		<p style='font-size:22px;font-family:Arial'><b>ES Dispatching Handover Acknowledgement &#45; ".$previousshift." to ".$currentshift."</b></p>
		<p style='font-size:15px;font-family:Arial'>Dispatcher Name: ".$currentdispatcher."<br>
		Date: ".$dateNow."</p>
		";

		$message = $message."<br/><br/><br/><br/><p style='font-size:10px;font-family:Arial'>Disclaimer: The information transmitted is intended solely for the individual or entity to which it is addressed and may contain Hewlett Packard Company confidential and/or privileged material. Any review, retransmission, dissemination or other use of or taking action in reliance upon this information by persons or entities other than the intended recipient is prohibited. If you have received this email in error please contact the sender and delete the material from any computer.</p>";

		$this->main_model->Send_Mail("apps_gdph_clienthp_gscs_l2@hpe.com, amos_bgl@hpe.com, katrina-marie.cunanan@hpe.com, ".$this->session->userdata('email')." ","ES Dispatching Handover Acknowledgement - ".$currentshift." Shift - ".date('Y-m-d H:i:s'), $message);
	}

	public function handoverack_email($to,$cc,$shift,$dispatcher){
		$this->load->library('email');

		# Best practice to have a dev environment-specific settings that is different to your production settings.
		# You can specify testing information here (i.e. hardcoded receipient)
		# Environment can be specified in root_folder (project folder)\index.php
			$subject = "[HPI SWITCHBOARD]Handover Acknowledgement";
			$message = "
			<html>
			<head>
			</head>
			<body style='font-family:Arial;'>
			<p style='font-size:16px;'>Hi,</p>
			<p style='font-size:16px;'>
			This email is to acknowledge handover from the previous shift.</p>
			<p style='font-size:16px;'>HPI Switchboard's dispatcher for the <b>".$shift." shift</b> will be:<br><b> ".$dispatcher."</b>.
			</p>
			</body>
			</html>
			";

			
			# HPE SMTP, use for servers in HPE Network
			$config['protocol'] = 'smtp'; 
            $config['smtp_host'] = 'smtp3.hp.com';
            $config['charset'] = 'iso-8859-1';
            $config['wordwrap'] = TRUE;
            $config['mailtype'] = 'html';
            $sender = 'christopher-joseph.doctolero@hpe.com'; #"automationcenterofexcellence@hp.com"

		$this->email->initialize($config);
		$this->email->from($sender, 'HPI Handover Email');
		$this->email->to($to); 

		$messageFooter = "Please note that this is an automated mailbox and is not monitored. Please do not reply to this email.";

		$this->email->subject($subject);
		$this->email->message($message.$messageFooter);  

		$this->email->send();
	}




	//Handover Aknowledgement


	function getKeyList(){ //Gets the list of entries in the table
		$keyword = $this->main_model->getKey(); //reset to original model
		foreach($keyword as $key => $value){
			$e = array("edit" => '<button type="button" class="btn-edit asia center fa fa-pencil" id="updateKey" onclick="updateKey(&#39;'.$keyword[$key]["id"].'&#39;);" value="" /></button><button type="button" class="btn-edit label-critical center fa fa-times" id="deleteKey" onclick="deleteKey(&#39;'.$keyword[$key]["id"].'&#39;);" value="" /></button>');
			$keyword[$key] = array_merge($keyword[$key], $e);
		}
		echo json_encode($keyword);
	}

	function getKey($id){ //Get single CI
		$entry = $this->main_model->getSingleKey($id); //reset to original model
		echo $entry[0]['assignment_group'].'*'.$entry[0]['group_name'].'*'.$entry[0]['keywords'].'*'.$entry[0]['target'];
	}


	function deleteKey(){
		$id = $_POST['id'];
		$this->main_model->deleteKey($id); //reset to original model
	}

	function updateKey(){
		$group_name = $_POST['group_name'];
		$assignment_group = $_POST['assignment_group'];
		$keyword = $_POST['keyword'];
		$type = $_POST['type'];
		$id = $_POST['id'];
		$target = $_POST['target'];
		$this->main_model->updateKey($group_name, $assignment_group, $keyword, $type, $id, $target); //reset to original model
		echo $type;
	}

	function getShiftList(){ //Gets the list of entries in the table
		$shift = $this->main_model->getShift(); //reset to original model
		foreach($shift as $key => $value){
			$e = array("edit" => '<button type="button" class="btn-edit asia center fa fa-pencil" id="updateCI" onclick="updateShift(&#39;'.$shift[$key]["id"].'&#39;);" value="" /></button><button type="button" class="btn-edit label-critical center fa fa-times" id="deleteCI" onclick="deleteAGShift(&#39;'.$shift[$key]["id"].'&#39;);" value="" /></button>');
			$shift[$key] = array_merge($shift[$key], $e);
		}
		echo json_encode($shift);
	}

	function getShift($id){ //Get single CI
		$entry = $this->main_model->getSingleShift($id); //reset to original model
		echo $entry[0]['group_name'].'*'.$entry[0]['shift'].'*'.$entry[0]['start_time'].'*'.$entry[0]['end_time'];
	}


	function deleteAGShift(){
		$id = $_POST['id'];
		$this->main_model->deleteAGShift($id); //reset to original model
	}

	function updateShift(){
		$group_name = strtoupper($_POST['group_name']);
		$shift = strtoupper($_POST['shift']);
		$startTime = $_POST['startTime'];
		$endTime = $_POST['endTime'];
		$type = $_POST['type'];
		$id = $_POST['id'];
		$this->main_model->updateShift($group_name, $shift, $startTime, $endTime, $type, $id); //reset to original model
		// echo $shift;
	}

	function uploadCSV(){
		$this->load->helper(array('form', 'url'));
		$this->load->library('upload');
	}

	public function do_upload()
    {
		$this->load->helper(array('form', 'url'));
        $config['upload_path']          = './assets/uploads/';
        $config['allowed_types']        = 'csv';
        $config['max_size']             = 100;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('userfile'))
        {
                $error = array('error' => $this->upload->display_errors());

                // $this->load->view('upload_form', $error);
                echo $error['error'];
        }
        else
        {
                $data = array('upload_data' => $this->upload->data());

                $this->uploadCalendar($data['upload_data']['file_name']);

                // $this->calendar();
                var_dump($data);
        }
    }

	function uploadCalendar($filename){

		//READ CSV
		// $handle = fopen(FCPATH."OPEN-TICKETS.csv", "r");
		$path = "./assets/uploads/".$filename;
		$handle = fopen($path, "r");
		$i=0; 
		while (($data = fgetcsv($handle, 5000, ",")) !== FALSE) 
		{
			$csvrow = print_r($data, true);
			$calendar[$i] = $data;
			$i+=1;
		}
		fclose($handle);
		// for($a=1;$a<count($calendar);$a++) {
		// 	$email =  $calendar[$a][0];
		// 	$shift =  $calendar[$a][1];	
		// 	$groupname =  $calendar[$a][2];	
		// 	$date =  $calendar[$a][3];	

		// 	echo $email.$shift.$groupname.$date.'<br/>';
		// }

		$this->main_model->uploadCalendar($calendar);

		redirect('main/calendar');

		//END READ CSV
	}



	
}
