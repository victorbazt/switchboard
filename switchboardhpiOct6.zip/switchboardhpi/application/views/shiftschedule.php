
<!-- Optional for Timepicker -->
<link href="<?php echo base_url('assets/lib/jquery-ui-1.11.4/jquery-ui.min.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/lib/jquery-timepicker/jquery-ui-timepicker-addon.css'); ?>" rel="stylesheet">
<!-- End of Optional Code -->
<style>
.modal-content {
    color:white;
}

</style>
<div class="container">			
				
	<p class="pull-right"><input type="button" class="btn btn-primary center" id="addShift" onclick="addShift();" value="ADD SHIFT" /></p>
	<div class="tables">
		<div class="bs-example widget-shadow row autopad" data-example-id="hoverable-table"> 
		
			<table id="example" class="table row-border myTable text-left" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th></th>
					<th>Group Name</th>
					<th>Shift</th>
					<th>Start Time</th>
					<th>End Time</th>
				</tr>
			</thead>
			</table>
			
			<p id="test"></p>
			
		</div>
	</div>
			
</div>
<div id="fullCalModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
				<span id="title"></span>
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                <h4 id="modalTitle" class="modal-title"></h4>
            </div>
            <div id="modalBody" class="modal-body">
			<form id="Shiftform">
			<input type="text" id="shiftID" name="shiftID" class="form-control login"
						   value="" placeholder="" style="display:none"/>
			<fieldset>
				<label for="GN" class="settings-label">Group Name</label><br> 
				<input type="text" id="GN" name="GN" class="form-control login"
						   value="" placeholder="" />
			  </fieldset>
			  <fieldset>
				 <label for="shiftnew" class="settings-label">Shift Name</label><br/>
				 <input type="text" id="shiftnew" name="shiftnew" class="form-control login"
						   value="" placeholder="" />
			  </fieldset> 
			  
			  <fieldset>
		        <label for="exampleSelect1" class="settings-label">Start Time</label>
		        <select class="form-control pull-right" id="startTimeAG" name="startTime">
		          <?php
		          for($a=0;$a<24;$a++){
		            echo '<option value="'.str_pad($a, 2, '0', STR_PAD_LEFT).':00:00">'.str_pad($a, 2, '0', STR_PAD_LEFT).':00:00 </option>';
		            echo '<option value="'.str_pad($a, 2, '0', STR_PAD_LEFT).':30:00">'.str_pad($a, 2, '0', STR_PAD_LEFT).':30:00 </option>';
		          }
		          ?>
		         </select>
		      </fieldset>
		       <fieldset>
		        <label for="exampleSelect1" class="settings-label">End Time</label>
		        <select class="form-control pull-right" id="endTimeAG" name="endTime">
		          <?php
		          for($a=0;$a<24;$a++){
		            echo '<option value="'.str_pad($a, 2, '0', STR_PAD_LEFT).':00:00">'.str_pad($a, 2, '0', STR_PAD_LEFT).':00:00 </option>';
		            echo '<option value="'.str_pad($a, 2, '0', STR_PAD_LEFT).':30:00">'.str_pad($a, 2, '0', STR_PAD_LEFT).':30:00 </option>';
		          }
		          ?>
		         </select>
		      </fieldset>

			  <div id="saved"></div
			  <input type="hidden" id="newtemp" name="newtemp" value="0" />
			  <fieldset><input type="button" id="submitShift" class="btn btn-primary center" onclick="SubmitForm();" data-dismiss="modal" value="Save" /></fieldset>
			</form>  
			</div>
        </div>
    </div>
</div>
<!-- Optional for Timepicker -->
<script src="<?php echo base_url(); ?>assets/lib/jquery-ui-1.11.4/jquery-ui.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/lib/jquery-timepicker/jquery-ui-timepicker-addon.js" type="text/javascript"></script>
<!-- End of Optional Code -->
<script>
var modal = document.getElementById('fullCalModal');
var span = document.getElementsByClassName("close")[0];
span.onclick = function(){
	modal.modal("close");
}
window.onclick = function(event) {
    if (event.target == modal) {
        modal.modal("close");
    }
}

</script>
<script>
		$(document).ready(function() {
			$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/getShiftList',
			type: 'POST', // Send post data
			data: 'type=fetch',
			async: false,
			success: function(s){
				json_events = s;
			},
			error: function(e){		  
				console.log('error get shift');
				revertFunc();
				alert('Error processing your request: '+e.responseText);
			}
			});
			var dataSet = JSON.parse(json_events);
			
			var table = $('#example').DataTable( {
				"ajax": {
					"url": "<?php echo base_url(); ?>index.php/main/getShiftList",
					error: function (xhr, error, thrown) {
					window.top.location.reload();
					},
					"dataSrc": ""
				},
				"columns": [
					{ "data": "edit", "width": "10%", "className": "dt-body-center" },
					{ "data": "group_name", "className": "dt-head-center dt-body-center" },
					{ "data": "shift", "className": "dt-head-center dt-body-center" },
					{ "data": "start_time", "className": "dt-head-center dt-body-center" },
					{ "data": "end_time", "className": "dt-head-center dt-body-center" }
				]
			} );
			setInterval( function () {
				table.ajax.reload( null, false ); // user paging is not reset on reload
			}, 5000 );
			
			dataTables();
			//Optional Code for Timepicker
			// $('#startTimeAG').timepicker({
			// 	controlType: 'select',
			// 	oneLine: true,
			// 	timeFormat: 'HH:mm:ss'
			// });
			// $('#endTimeAG').timepicker({
			// 	controlType: 'select',
			// 	oneLine: true,
			// 	timeFormat: 'HH:mm:ss'
			// });
			//End of Optional Code
		} );
		
		function dataTables(){
			
		}
		</script>
		
		<script>
		function addShift(){
			$('#title').html('Add Shift');
			$("#Shiftform").trigger('reset');
			$('#shiftID').val('0');
			$('#GN').prop('disabled', false);
			document.getElementById('submitShift').value = 'SAVE';
			console.log($('#submitShift').val());
			$("#fullCalModal").modal();
			//$('#fullCalModal').css('display','block');
		}
		
		function updateShift(id){
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/getShift/'+id,
				type: 'POST', // Send post data
				data: 'nothing=null',
				async: false,
				success: function(s){
					entry = s;
				},
				error: function(e){		  
					console.log('error update shift');
					revertFunc();
					alert('Error processing your request: '+e.responseText);
				}
			});
			$('#shiftID').val(id);
			$('#title').html('Edit Shift');
			entry = entry.split('*');
			GN = entry[0];
			$('#GN').val(GN);
			$('#GN').prop('disabled', true);
			shift = entry[1];
			$('#shiftnew').val(shift);
			startTime = entry[2];
			$("#startTimeAG").val(startTime);
			endTime = entry[3];
			$("#endTimeAG").val(endTime);
			
			document.getElementById('submitShift').value = 'UPDATE';
			console.log($('#submitShift').val());
			
			$("#fullCalModal").modal();
			//Override model's auto-generated div container as it always uses 0 width
		}
		
		function deleteAGShift(id){
			console.log('a'+id);
			var con = confirm('Are you sure to delete this shift permanently?');
		    	if(con == true) {
					$.ajax({
						url: '<?php echo base_url(); ?>index.php/main/deleteAGShift',
						type: 'POST', // Send post data
						data: 'id='+id,
						async: false,
						success: function(s){
							$(function(){
							    new PNotify({
							        title: 'Successfully Deleted',
							        text: 'Shift Schedule has been deleted.',
							        type: 'success'
							    });
							});
						},
						error: function(e){		  
							console.log('a');
							revertFunc();
							alert('Error processing your request: '+e.responseText);
						}
					});
				}
		}
		
		function SubmitForm(){
			var group_name = $('#GN').val();
			var shift = $('#shiftnew').val();
			var startTime = $('#startTimeAG').val();
			var endTime = $('#endTimeAG').val();
			var type = $('#submitShift').val();
			var id = $('#shiftID').val();
			
			if(group_name != ''){
				$.post("<?php echo base_url(); ?>index.php/main/updateShift", { group_name: group_name, shift: shift, startTime: startTime, endTime: endTime, type:type, id:id},
				function(data) {
					//change to notif modal
					if(type == 'SAVE'){
						$(function(){
						    new PNotify({
						        title: 'Successfully Added',
						        text: 'Shift Schedule has been Added.',
						        type: 'success'
						    });
						});
					}
					else{
						$(function(){
						    new PNotify({
						        title: 'Successfully Updated',
						        text: 'Shift Schedule has been Updated.',
						        type: 'success'
						    });
						});
					}

					 // $('#saved').html(data);
					});
					
			}
			else{
					//change to notif modal
					$(function(){
					    new PNotify({
					        title: 'Failed to Add Shift',
					        text: 'Error encountered adding/updating Shift.',
					        type: 'error'
					    });
					});
			}
			
		}
</script>