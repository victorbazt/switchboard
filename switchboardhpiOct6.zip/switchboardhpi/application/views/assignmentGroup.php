<div class="container">			
				
	<p class="pull-right"><input type="button" class="btn btn-primary center" id="addKey" onclick="addKey();" value="ADD KEYWORD" /></p>
	<div class="tables">
		<div class="bs-example widget-shadow row autopad" data-example-id="hoverable-table"> 
		
			<table id="example" class="table row-border myTable text-left" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th></th>
					<th>Keywords</th>
					<th>Assignment Group</th>
					<th>Group Name</th>
					<th>Applicable Field</th>
				</tr>
			</thead>
			</table>
			
			<p id="test"></p>
			
		</div>
	</div>
			
</div>
<div id="fullCalModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
				<span id="title"></span>
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                <h4 id="modalTitle" class="modal-title"></h4>
            </div>
            <div id="modalBody" class="modal-body">
			<form id="Keyform">
			<input type="text" id="keyID" name="keyID" class="form-control inputfull"
						   value="" placeholder="" style="display:none"/>
			<fieldset>
				 <label for="keywordnew" class="settings-label">Keywords</label><br/>
				 <input type="text" id="keywordnew" name="keywordnew" class="form-control inputfull"
						   value="" placeholder="" />
			  </fieldset>
			<fieldset>
				<label for="AG" class="settings-label">Assignment Group</label><br> 
				<input type="text" id="AG" name="AG" class="form-control inputfull"
						   value="" placeholder="" />
			  </fieldset>
			  <fieldset>
				 <label for="GN" class="settings-label">Group Name</label><br/>
				 <input type="text" id="GN" name="GN" class="form-control inputfull"
						   value="" placeholder="" />
			  </fieldset> 
			  <fieldset>
				 <label for="target" class="settings-label">Applicable Field</label><br/>
				 <select id="target" name="target" class="form-control login">
					<option value="CI">CI</option>
					<option value="TITLE">Title</option>
				 </select>
				 <!--<input type="text" id="target" name="target" class="form-control login"
						   value="" placeholder="" />-->
			  </fieldset> 
			  <div id="saved"></div
			  <input type="hidden" id="newtemp" name="newtemp" value="0" />
			  <fieldset><input type="button" id="submitKey" class="btn btn-primary center" onclick="SubmitForm();" data-dismiss="modal" value="Save" /></fieldset>
			</form>  
			</div>
        </div>
    </div>
</div>
<script>
var modal = document.getElementById('fullCalModal');
var span = document.getElementsByClassName("close")[0];
span.onclick = function(){
	modal.modal("close");
}
window.onclick = function(event) {
    if (event.target == modal) {
        modal.modal("close");
    }
}
</script>
<script>
		$(document).ready(function() {
			$.ajax({
			url: '<?php echo base_url(); ?>index.php/main/getKeyList',
			type: 'POST', // Send post data
			data: 'type=fetch',
			async: false,
			success: function(s){
				json_events = s;
			},
			error: function(e){		  
				console.log('a');
				revertFunc();
				alert('Error processing your request: '+e.responseText);
			}
			});
			var dataSet = JSON.parse(json_events);
			
			var table = $('#example').DataTable( {
				"ajax": {
					"url": "<?php echo base_url(); ?>index.php/main/getKeyList",
					error: function (xhr, error, thrown) {
					window.top.location.reload();
					},
					"dataSrc": ""
				},
				"columns": [
					{ "data": "edit", "width": "10%", "className": "dt-body-center" },
					{ "data": "keywords", "className": "dt-head-center dt-body-center" },
					{ "data": "assignment_group", "className": "dt-head-center dt-body-center" },
					{ "data": "group_name", "className": "dt-head-center dt-body-center" },
					{ "data": "target", "className": "dt-head-center dt-body-center" },
				]
			} );
			setInterval( function () {
				table.ajax.reload( null, false ); // user paging is not reset on reload
			}, 5000 );
			
			dataTables();
			
		} );
		
		function dataTables(){
			
		}
		</script>
		
		<script>
		function addKey(){
			$('#title').html('Add Keywords');
			$("#Keyform").trigger('reset');
			$('#keyID').val('0');
			document.getElementById('submitKey').value = 'SAVE';
			console.log($('#submitKey').val());
			$("#fullCalModal").modal();
			//$('#fullCalModal').css('display','block');
		}
		
		function updateKey(id){
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/getKey/'+id,
				type: 'POST', // Send post data
				data: 'nothing=null',
				async: false,
				success: function(s){
					entry = s;
				},
				error: function(e){		  
					console.log('a');
					revertFunc();
					alert('Error processing your request: '+e.responseText);
				}
			});
			$('#title').html('Edit Keywords');
			$('#keyID').val(id);
			entry = entry.split('*');
			assignment_group = entry[0];
			$('#AG').val(assignment_group);
			group_name = entry[1];
			$("#GN").val(group_name);
			keywords = entry[2];
			$("#keywordnew").val(keywords);
			target = entry[3];
			$("#target").val(target);
			
			document.getElementById('submitKey').value = 'UPDATE';
			console.log($('#submitKey').val());
			
			$("#fullCalModal").modal();
			//Override model's auto-generated div container as it always uses 0 width
		}
		
		function deleteKey(id){
			var con = confirm('Are you sure to delete this event permanently?');
		    	if(con == true) {
					$.ajax({
						url: '<?php echo base_url(); ?>index.php/main/deleteKey',
						type: 'POST', // Send post data
						data: 'id='+id,
						async: false,
						success: function(s){
							$(function(){
							    new PNotify({
							        title: 'Successfully Deleted',
							        text: 'Assignment Group with Keywords has been deleted.',
							        type: 'success'
							    });
							});
						},
						error: function(e){		  
							console.log('a');
							revertFunc();
							alert('Error processing your request: '+e.responseText);
						}
					});
				}
		}
		
		function SubmitForm(){
			var id = $('#keyID').val();
			var assignment_group = $('#AG').val();
			var group_name = $('#GN').val();
			var keyword = $('#keywordnew').val();
			var target = $('#target').val();
			var type = $('#submitKey').val();
			
			if(id != ''){
				$.post("<?php echo base_url(); ?>index.php/main/updateKey", { assignment_group: assignment_group, group_name: group_name, keyword: keyword, type:type, id:id, target:target},
				function(data) {
					//change to notif modal
					console.log(data);
					if(data == 'SAVE'){
						$(function(){
						    new PNotify({
						        title: 'Successfully Added',
						        text: 'Assignment Group with Keywords has been added.',
						        type: 'success'
						    });
						});
					}
					else{
						$(function(){
						    new PNotify({
						        title: 'Successfully Updated',
						        text: 'Assignment Group details has been updated.',
						        type: 'success'
						    });
						});
					}
					

					 // $('#saved').html(data);
					});
					
			}
			else{
					//change to notif modal
					$(function(){
					    new PNotify({
					        title: 'Failed to Add Keyword mapping',
					        text: 'Error encountered adding/updating keyword mapping.',
					        type: 'error'
					    });
					});
			}
			
		}
</script>