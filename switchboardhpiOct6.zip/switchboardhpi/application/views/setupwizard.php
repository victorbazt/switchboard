<div class="half-container">

	<div class="jumbotron">
		<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
					<img class="img-responsive" src="<?php echo base_url();?>assets/images/bigRobot.png"/>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">

					<p>Hi <?php echo $this->session->userdata('wholename'); ?>.</p>
					<p>I'm Otto, your Switchboard Operator. I will be assigning your Service Manager tickets to your team.</p>
					<p>I see that you have not setup your Switchboard settings yet. Would you like to start now?</p>
					<a href="<?php echo base_url() ?>index.php/main/userSetup"><button type="submit" class="btn btn-primary center">Setup Wizard</button></a>
				</div>
				</div>
		</div>
	</div>

</div>
