<div class="container">
	<p class="pull-right"><input type="button" class="btn btn-primary center" id="sendHandover" onclick="sendHandover();" value="SEND HANDOVER REPORT" /></p>
	<div class="tables">
		<div class="bs-example widget-shadow row autopad" data-example-id="hoverable-table"> 
			
			<table id="example" class="table row-border myTable text-left" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th></th>
					<th>TICKET #</th>
					<!-- <th>TITLE</th> -->
					<th>CI</th>
					<th>AG</th>
					<th>ASSIGNED TO</th>
					<th>PRIORITY</th>
					<th>TYPE</th>
					<th>DATE ASSIGNED</th>
				</tr>
			</thead>
			</table>
				
		</div>
	
	</div>
						
</div>		
	
<script>
		// $(document).ready(function(){
		// 	$('.myTable').DataTable({
		// 		"aLengthMenu": [[5, 10, 25, -1], [5, 10, 25, "All"]],
		// 		"iDisplayLength": 15
		// 	});
		// });

var table = $('#example').DataTable( {
	"ajax": {
		"url": "<?php echo base_url(); ?>index.php/main/getAllTickets",
		error: function (xhr, error, thrown) {
		window.top.location.reload();
		},
		"dataSrc": ""
	},
	"columns": [
		{ "data": "delete", "width": "10%", "className": "dt-body-center" },
		{ "data": "tnum"},
		// { "data": "title"},
		{ "data": "affectedCI"},
		{ "data": "assignmentgroup"},
		{ "data": "specialist" },
		{ "data": "priority" },
		{ "data": "type" },
		{ "data": "date"}
	]
} );
setInterval( function () {
	table.ajax.reload( null, false ); // user paging is not reset on reload
}, 10000 );

function deleteTicket(ticketid){
	var con = confirm('Are you sure to delete this event permanently?');
    	if(con == true) {
			$.ajax({
				url: '<?php echo base_url(); ?>index.php/main/deleteTicket/',
				type: 'POST', // Send post data
				data: 'ticketid='+ticketid,
				async: false,
				success: function(s){
					$(function(){
					    new PNotify({
					        title: 'Successfully Deleted',
					        text: 'Ticket has been deleted.',
					        type: 'success'
					    });
					});
				},
				error: function(e){		  
					console.log('a');
					revertFunc();
					alert('Error processing your request: '+e.responseText);
				}
			});
		}
}

function sendHandover(){
	$.post("<?php echo base_url(); ?>index.php/main/handover", { },
	function(data) {
		$(function(){
		    new PNotify({
		        title: 'Successfully Sent',
		        text: 'HandOver Report has been sent via Email.',
		        type: 'success'
		    });
	});

	 // $('#saved').html(data);
	});
}

</script>