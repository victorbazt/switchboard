<?php
class smtracker_model extends CI_Model {
	
	public function __construct(){
			parent::__construct();
			date_default_timezone_set("Asia/Singapore");
			$this->load->database();
	 }
	
	function getUserProfile($email, $column){
			$this->db->select($column);
			$this->db->from('userprofile');
			$this->db->where('email', $email);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$result = $query->row()->$column;
				return $result;
			}else{
				return NULL;
			}
		}
		
		function getDM($team, $region = ' '){
			$this->db->select('*');
			$this->db->from('specialist');
			if($region != ' ')
				$this->db->where('region', $region);
			$this->db->where('team', $team);
			$this->db->where('status', 'Available');
			$this->db->where('role !=', '');
			// $this->db->or_where('role', '1');
			// $this->db->or_where('role', '2');
			// $this->db->or_where('role', '3');
			// $this->db->or_where('role', '4');
			// $this->db->or_where('role', '5');
			// $this->db->order_by('region', 'asc');
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return NULL;
			}
		}
		
		function getRegions($team){
			$this->db->select('region, start, end');
			$this->db->from('region');
			$this->db->where('team', $team);
			$this->db->order_by('region', 'asc');
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return NULL;
			}
		}
		
		function getCalendar($team, $status){
			$currenttime = time();
			$this->db->select('c.status as `cstatus`, s.wholename, c.sdate, c.edate, s.region, s.team, s.email');
			$this->db->from('calendar as c');
			$this->db->join('specialist as s', 'c.email = s.email');
			if($status == 'ooo'){
				$this->db->where('s.team', $team);
				$this->db->where('c.edate >', date("Y-m-d H:i:s"));
				// $this->db->where('c.sdate <', date("Y-m-d H:i:s"));
				$this->db->where('c.status', 'VL');
				$this->db->or_where('c.status', 'SL');
				$this->db->or_where('c.status', 'TRAINING');
				$this->db->or_where('c.status', 'EL');
			}
			else if($status == 'shift'){
				// $this->db->where('c.status', 'DM');
				$this->db->where('s.team', $team);
				$this->db->like('c.status', 'DM');
				// $this->db->or_where('c.status', 'DM2');
				// $this->db->or_where('c.status', 'DM3');
				// $this->db->or_where('c.status', 'DM4');
				// $this->db->or_where('c.status', 'DM5');
			}
			
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->result_array();
			}
			else{
				return NULL;
			}
			
		}
		
		function updateUserProfile($email, $column){
			$this->db->select($column);
			$this->db->from('userprofile');
			$this->db->where('email', $email);
			
			$data = array(
			'ftuser' => "0"
			);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('email', $email);
				$this->db->update('userprofile', $data);
				// echo 'Successfully Saved.';
				redirect("main/Dashboard");
			}else{
				return NULL;
			}
		}
		
		function addSpecialist($email, $team, $region, $email, $wholename, $row, $type, $role){
			$data = array(
			'email' => $email,
			'team' => $team,
			'region' => $region,
			'email' => $email,
			'wholename' => $wholename,
			'row' => $row,
			'type' => $type,
			'role' => $role
			);
			
			$this->db->select('email');
			$this->db->from('specialist');
			$this->db->where('email', $email);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				echo 'Specialist already exist.';
			}
			else{
				$this->db->insert('specialist', $data);
				echo 'Successfully Added.';
			}
		}
		
		function addTickets($tnum, $team, $CI, $assignmentgroup, $category, $title, $priority, $specialist, $targetdate, $status, $type, $tto){
			$data = array(
			'tnum' => $tnum,
			'team' => $team,
			'assignmentgroup' => $assignmentgroup,
			'category' => $category,
			'title' => $title,
			'affectedCI' => $CI,
			'priority' => $priority,
			'date' => date('Y-m-d H:i:s'),
			'specialist' => $specialist,
			'targetdate' => $targetdate,
			'status' => $status,
			'type' => $type,
			'tto' => $tto
			);

			$this->db->insert('tickets', $data);
			// echo 'Successfully Added.';
			return true;
		}
		
		function updateSettings($team, $timeout, $titlesearch, $regionsearch, $noregionassignee){
			$data = array(
			'timeout' => $timeout,
			'titlesearch' => $titlesearch,
			'regionsearch' => $regionsearch,
			'noregionassignee' => $noregionassignee
			);
			
			$this->db->select('team');
			$this->db->from('settings');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->update('settings', $data);
				// echo 'Successfully Saved.';
				$this->updateUserProfile($this->session->userdata('email'), 'ftuser');
			}
			else{
				echo 'Team does not exist.';
			}
		}
		
		function getSettings($team, $column){
			$this->db->select($column);
			$this->db->from('settings');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$result = $query->row()->$column;
				return $result;
			}
			else{
				return FALSE;
			}
		}
		
		function getTicketCount($team, $category, $priority){
			$this->db->select('priority, sum(tkt_count) as total, date');
			$this->db->from('ticket_per_priority_vw');
			$this->db->where('team', $team);
			$this->db->where('category', $category);
			$this->db->where('priority', $priority);
			$this->db->where('date =', date("Y-m-d"));
			$this->db->order_by('date', 'asc');
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getTicketCountSpecialist($team){
			$this->db->select('count(tnum) as tkt_count, specialist, team');
			$this->db->from('tickets');
			$this->db->where('team', $team);
			$this->db->group_by('specialist');
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getAllSpecialist($team){
			$this->db->select('*');
			$this->db->from('specialist');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		function getAllTickets($team){
			$this->db->select('*');
			$this->db->from('tickets');
			$this->db->where('team', $team);
			$query = $this->db->get();
			if($query->num_rows() > 0)
				return $query->result_array();
		}
		
		
		function Send_Mail($recepient,$subject,$body){
			$this->load->library('email');
			$this->load->model('pgldap_model');

			$body = $body."<br/><br/><br/><br/><p style='font-size:10px;font-family:Arial'>Disclaimer: The information transmitted is intended solely for the individual or entity to which it is addressed and may contain Hewlett Packard Company confidential and/or privileged material. Any review, retransmission, dissemination or other use of or taking action in reliance upon this information by persons or entities other than the intended recipient is prohibited. If you have received this email in error please contact the sender and delete the material from any computer.</p>";
			
			if(ENVIRONMENT != 'development'){ //If Dev: We use HP SMTP
				$config['protocol'] = 'smtp';
				$config['mailpath'] = '/usr/sbin/sendmail';
				$config['smtp_host'] = 'smtp3.hpe.com';
				$config['smtp_port'] = 25;
				$config['charset'] = 'iso-8859-1';
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				
				$sender = 'noreply-switchboard@hpe.com';
			}
			else{                                                                                                      // IF Prod: We use P&G SMTP
				$config['protocol'] = 'smtp';
				$config['mailpath'] = '/usr/sbin/sendmail';
				$config['smtp_host'] = 'smtpgw.pg.com';
				$config['charset'] = 'iso-8859-1';
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				
				$sender = 'noreply-switchboard@pg.com';
			}
			$this->email->from($sender, 'SWITCHBOARD');
			$this->email->to($recepient);
			$this->email->subject($subject);
			$this->email->message($body);
			
			$this->email->send();

			echo $this->email->print_debugger();


		}
		
		
		function emailtemplate($email, $tnum, $category, $title, $priority, $targetdate, $status, $description){
			
			

			$emailtemplate = $email.$tnum.$category.$title.$priority.$targetdate.$status.$description;
			
			return $emailtemplate;
		}
		
		function getWorkgroup($team){
	
		$this->db->select("workgroup");
		$this->db->from("teams");
		$this->db->where("name", $team);
		$query = $this->db->get();
		
		if($query->num_rows() > 0 )
			return $query->row()->workgroup;
		else
			return FALSE;
	}
	
	function setting($option, $team){
		
		$this->db->select($option);
		$this->db->from("settings");
		$this->db->where("team", $team);
		$query = $this->db->get();
		
		if($query->num_rows() > 0 )
			return $query->row()->$option;
		else{
			echo "Invalid Team Name.";
			return FALSE;
			
		}
		
	}
	
	function saveLogs($log, $workgroup){
		$data = array(
				'log' => $log,
				'workgroup' => $workgroup
				);
		
		if($this->db->insert("logs", $data)){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function startAssign($team){
		$data = array(
			'start' => '1',
			'stop' => '0'
			);
		$this->db->select('*');
		$this->db->from('settings');
		$this->db->where('team', $team);
		$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->update('settings', $data);
				// echo 'Successfully Saved.';
			}
			else{
				echo 'Cannot Start, Team does not exist.';
			}
		
	}
	//Checker so that 1 member of the team can only run the dispatcher at a time
	function startRun($email){
		$data = array(
			'startrun' => '1'
			);
		$this->db->from('userprofile');
		$this->db->where('email', $email);
		$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('email', $email);
				$this->db->update('userprofile', $data);
				// echo 'Successfully Saved.';
			}
			else{
				echo 'Cannot Start, Specialist dont exist.';
			}
		
	}
	
	function stopRun($email){
		$data = array(
			'startrun' => '0'
			);
		$this->db->from('userprofile');
		$this->db->where('email', $email);
		$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('email', $email);
				$this->db->update('userprofile', $data);
				// echo 'Successfully Saved.';
			}
			else{
				echo 'Cannot Start, Specialist dont exist.';
			}
		
	}
	//end checker

	function stopAssign($team){
		$data = array(
			'start' => '0',
			'stop' => '0'
			);
		$this->db->select('*');
		$this->db->from('settings');
		$this->db->where('team', $team);
		$query = $this->db->get();
			if($query->num_rows() > 0){
				$this->db->where('team', $team);
				$this->db->update('settings', $data);
				// echo 'Successfully Saved.';
			}
			else{
				echo 'Cannot Stop, Team does not exist.';
			}
		
	}
	
	function RegionSelector($team){
		$this->db->select('region');
		$this->db->from('region');
		$this->db->where('team', $team);
		$this->db->where('start <=', date('H:i:s'));
		$this->db->where('end >=', date('H:i:s'));
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$result = $query->row()->region;
			return $result;
		}
		return FALSE;
		
	}
	
	function CheckDMAvailability($team, $region){
		$this->db->select('email');
		$this->db->from('specialist');
		$this->db->where('team', $team);
		$this->db->where('region', $region);
		$this->db->where('role !=', '');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function getRowApp($team){
		$this->db->select('rows');
		$this->db->from('rowapp');
		$this->db->where('team', $team);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result_array();
		}
		else{
			return FALSE;
		}
		
	}
	
	function minCriticalTicket($team, $rowapp = ' '){
		$rowapp = strtoupper("[".$rowapp."]");
		$this->db->select('sum(tkt_count) as tkt_count, email, team, region');
		$this->db->from('all_specialist_critical_view');
		if($rowapp != '[]')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		$this->db->group_by('email', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->email;
		}
		else{
			return FALSE;
		}
		
	}
	
	function minIMTicket($assignmentgroup, $region = ' '){
		$this->db->select('sum(tkt_count) as tkt_count, specialist, team, region, row');
		$this->db->from('all_specialist_imticket_view');
		if($region != ' ')
			$this->db->where('region', $region);
		$this->db->like('assignmentgroup', $assignmentgroup);
		$this->db->group_by('specialist', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->specialist;
		}
		else{
			return FALSE;
		}
		
	}
	
	function minFRTicket($team, $rowapp, $region = ' '){
		$rowapp = strtoupper("[".$rowapp."]");
		$this->db->select('sum(tkt_count) as tkt_count, shortname, team, region');
		$this->db->from('all_specialist_frticket_view');
		if($rowapp != '[]')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		if($region != ' ')
			$this->db->where('region', $region);
		$this->db->group_by('shortname', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->shortname;
		}
		else{
			return FALSE;
		}
		
	}
	
	function minRogueTicket($team, $rowapp, $region = ' '){
		$rowapp = strtoupper("[".$rowapp."]");
		$this->db->select('sum(tkt_count) as tkt_count, shortname, team, region');
		$this->db->from('all_specialist_ticket_view');
		if($rowapp != '[]')
			$this->db->like('row', $rowapp);
		$this->db->where('team', $team);
		if($region != ' ')
			$this->db->where('region', $region);
		$this->db->group_by('shortname', 'asc');
		$this->db->order_by('tkt_count', 'asc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			// var_dump($query->result_array());
			return $query->row()->shortname;
		}
		else{
			return FALSE;
		}
		
	}
	
	function savePassword($shortname, $password){
		$data = array (
			'shortname' => $shortname,
			'password' => $password
		);
		
		$this->db->select('shortname');
		$this->db->from('userprofile');
		$this->db->where('shortname', $shortname);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$this->db->update('userprofile', $data);
		}
	}
	
	function updateDM($team){
		$dmshift = $this->getCalendar($team, 'shift');
		$role =  array(
				'role' => ''
		);
		
		$this->db->from('specialist');
		$this->db->where('team',$team);
		$this->db->update('specialist', $role);
		foreach($dmshift as $dm){
			if($dm['sdate'] <= date("Y-m-d H:i:s") && $dm['edate'] >= date("Y-m-d H:i:s")){
				$shift = array(
					'email' => $dm['email'],
					// 'role' => filter_var($dm['cstatus'], FILTER_SANITIZE_NUMBER_INT)		if calendar status is DM1,DM2 etc
					'role' => '1'
				);
				// $this->db->select('email');
				$this->db->from('specialist');
				$this->db->where('team', $team);
				$this->db->where('email', $dm['email']);
				$this->db->update('specialist', $shift);
				// unset($data);
				
			}
		}
		return TRUE;
	}

	function getAssignmentGroup($CI, $column){
		$this->db->from('ci');
		$this->db->like('ci', $CI);
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->row()->$column;
		}
		else
			return FALSE;

	}

	function getAllAG($target){
		$this->db->from('keyword_ag');
		$this->db->where('target', $target);
		$this->db->order_by('id', 'asc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function getAssigneeShift(){
		$this->db->from('calendar');
		// $this->db->where('status !=', 'DM');
		// $this->db->where('status !=', 'Leave');
		$this->db->where('sdate <=', date("Y-m-d"));
		$this->db->where('edate >=', date("Y-m-d"));
		$query = $this->db->get();
		if($query->num_rows() >0){
			return $query->result_array();
		}
		else
			return FALSE;
	}

	function updateAssigneeShift($team){
		$resetstatus = array(
				'role' => '',
				'status' => 'Unavailable'
			);
		$this->db->from('specialist');
		$this->db->where('team', $team);
		$this->db->update('specialist', $resetstatus);
		$assigneeshift = $this->getAssigneeShift();
		foreach($assigneeshift as $assignee){
			// if($assignee['sdate'] <= date("Y-m-d H:i:s") && $assignee['edate'] >= date("Y-m-d H:i:s")){ if time will be implemented
			if($assignee['sdate'] <= date("Y-m-d") && $assignee['edate'] >= date("Y-m-d")){
				if($assignee['status'] == 'DM'){
					$data = array(
						'role' => '1',
						'status' => 'Available'
					);	
				}
				else if($assignee['status'] == 'Leave'){
					$data = array(
						'status' => 'Unavailable'
					);	
				}
				else{
					$data = array(
						'status' => 'Available'
					);	
				}
				// $this->db->select('email');
				$this->db->from('specialist');
				$this->db->where('team', $team);
				$this->db->where('email', $assignee['email']);
				$this->db->update('specialist', $data);
				
			}
		}
	}

	// function getAllTitleKeyword(){
	// 	$this->db->select('keywords, assignment_group, group_name');
	// 	$this->db->from('titlekeyword');
	// 	$query = $this->db->get();
	// 	return $query->result_array();
	// }
	
	
}
?>